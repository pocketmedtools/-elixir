var e=[{id:`src-papers-2022-2025`,title:`DNB Family Medicine — question papers 2022 to 2025`,fileName:`DNB_FM_PYQ_2022-2025.pdf`,originalPath:`source/DNB_FM_PYQ_2022-2025.pdf`,note:`The papers as sat, June 2022 through June 2025, transcribed from the source PDF.`,text:`

[Page 1]
DNB Family Medicine
Previous Year’s Question Paper
2022- 2025

[Page 2]
Table of contents
2
Table of contents
Paper 1 (General Medicine and allied) ....................................................................................................3
2022 June Paper 1 ...............................................................................................................................3
2022 December Paper 1 ......................................................................................................................4
2023 April Paper 1 ...............................................................................................................................6
2023 October Paper 1..........................................................................................................................9
2024 May paper 1..............................................................................................................................11
2024 October Paper 1........................................................................................................................14
2025 June paper 1 .............................................................................................................................16
Paper 2 (General Surgery and allied) .....................................................................................................19
2022 June Paper 2 .............................................................................................................................19
2022 December Paper 2 ....................................................................................................................20
2023 April Paper 2 .............................................................................................................................22
2023 October Paper 2........................................................................................................................24
2024 May Paper 2 ..............................................................................................................................26
2024 October Paper 2........................................................................................................................28
2025 June Paper 2 .............................................................................................................................31
Paper 3 (OBG and Paediatrics) ...............................................................................................................33
2022 June Paper 3 .............................................................................................................................33
2022 December Paper 3 ....................................................................................................................34
2023 April Paper 3 .............................................................................................................................35
2023 October Paper 3........................................................................................................................37
2024 May Paper 3 ..............................................................................................................................40
2024 October Paper 3........................................................................................................................42
2025 June Paper 3 .............................................................................................................................43
Paper 4 (FaM and Community medicine) ..............................................................................................46
2022 June Paper 4 .............................................................................................................................46
2022 December Paper 4 ....................................................................................................................46
2023 April Paper 4 .............................................................................................................................48
2023 October Paper 4........................................................................................................................49
2024 May Paper 4 ..............................................................................................................................51
2024 October Paper 4........................................................................................................................52
2025 June Paper 4 .............................................................................................................................53

[Page 3]
2022 June Paper 1
3
Paper 1 (General Medicine and allied)
2022 June Paper 1
1. Describe briefly on Vit.D metabolism, clinical features and management of Vit.D
deficiency? [5+3+2]
2. A 30-year-old lady came to you with fever of 3 days, decreased food intake and nausea.
Clinically jaundice was present. There were similar cases in the family. What is the clinical
diagnosis? What are the differential diagnoses? How will you proceed to evaluate? How do
you prevent the condition. [2+2+3+3]
3. Mention the causes for chronic aches and pains. How do you differentiate that from
inflammatory arthritis? How do you evaluate a patient with chronic aches and pains?
Describe briefly regarding management of chronic pain? [2+2+2+4]
4. Enumerate the causes of falls in the elderly. How would you assess the risks of fall in
elderly? How can we prevent falls in elderly? [4+3+3]
5. A 45-year-old overweight man came to you with recent onset tiredness, dryness of
mouth, weight loss and nocturia. What is your clinical diagnosis? How will you manage him
after diagnosis? [10]
6. Describe the condition and causes of gastroesophageal reflux diseases (GERD), give
anatomical basis of GERD? Write briefly on the management of GERD from a family
medicine perspective? [4+3+3]
7. Enumerate skin, mucosal, and systemic manifestations of protein calorie malnutrition.
[4+3+3]
8. What is delirium? How is it different from dementia? Enumerate the causes, differential
diagnosis and management of delirium? [1+1+3+3+2]
9. Write briefly on reasons for chemical poisonings. Enumerate clinical features,
management, and complications of organophosphorus poisoning? [3+3+2+2]
10. A 50 year old male known to have diabetes and hypertension for 15 years. He had
history of acute coronary syndrome a year ago. Now comes to you with fatigue, decreased
food intake and dyspnea on exertion. Clinically pedal edema, elevated JVP and on bilateral
auscultation of the lung bases, he had fine crepitations. What clinical possibilities will you
entertain? How do you proceed to evaluate this patient? As a family physician, how will you
manage this case? [2+4+4]

[Page 4]
2022 December Paper 1
4
2022 December Paper 1
1. A 38-year-old Mr. Ravi was brought to the casualty with the history of first episode of
seizures lasting for one minute. There was up rolling of eyes and drooling of saliva with loss
of consciousness, regained consciousness after 2 minutes. There was no post ictal phase.
The entire episode lasted for 5 min. Wife of Mr. Ravi gives history of alcohol intake by him of
180ml for past 20 years. His last drink was 3 days back – since he didn’t have work and didn’t
have money. His BP is 130/80, PR- 92/min, SpO2- 100 %, GRBS- 110, He is oriented to time,
place, person.
a) What is your differential diagnosis? [2]
b) What is your approach for above mentioned scenario? [5]
c) If GRBS- 50mg%. How will you treat immediately? [1]
d) How will you manage Alcohol related complications? [2]
2. Mrs. Pratibha 73-years-old, staying with her spouse presents to Outpatient department
with history of fall 2 days back in her home. Six months ago also, she had a similar complaint
and she sustained a Colle’s fracture of the right hand. Her first fall was one year ago when
she sustained minor abrasions.
a) What is the pathophysiology of Falls? [2]
b) What are the risk factors? [2]
c) How will you do the OPD assessment of falls? [4]
d) How are you going to prevent further falls in Mrs. Pratibha? [2]
3. A 23-year-old man was admitted to emergency room of primary care hospital for vomiting
and upper abdominal pain. His random blood sugar was found to be 586mg/dl. He is
hemodynamically stable. His urine ketones were +++
a) Mention the immediate life-threatening condition this patient can have. [1]
b) Mention the investigations you would want to do, substantiate you answer. [3]
c) What are the complications of this condition? [2]
d) Discuss the management of this condition in detail up to discharge. [4]
4. A 67-year-old lady was brought to the emergency room with h/o dizziness but no loss of
consciousness. She is a known diabetic and hypertensive, occasionally noncompliant with
her medications. Her BP is 130/86mmHg, PR- 86/min - irregularly irregular, GRBS- 186mg%.
a) What immediate office investigation would you do? [1]
b) What may be the most probable diagnosis? [1]
c) What other investigations you would want to do? [2]

[Page 5]
2022 December Paper 1
5
d) What are the complications of this condition? [2]
e) How will you assess this patient for stroke risk? [2]
f) How will you manage this patient? [2]
5. A 40-year-old lady presented to outpatient department with multiple joint pain, hair loss,
oral ulcers, malar rash, breathlessness, and history of passing blood in urine.
a) How will you evaluate the history and physical finding to come to a woking diagnosis in an
adult patient with multiple inflammatory arthritis? [4]
b) What are your differential diagnosis? [2]
c) What investigations you would want to do? [2]
d) What are the complications of the most probable diagnosis? [2]
6. A 48-year-old lady, known case of diabetes, hypertension, dyslipidemia, presented to
outpatient department with skin lesions over her elbows, knee, which has increased over
past 3 weeks. Earlier she had small lesion for which she used moisturizer which didn’t bother
her much. These lesions are well defined, erythematous plaques, with irregular borders and
silvery scales.
a) What is the most probable final diagnosis? And how will you confirm your diagnosis? [2]
b) How will you manage this condition? [4]
c) What are the complications of this condition? [3]
d) When will you refer this patient to a specialist? [1]
7. A 48-year-old Mrs.Lata has been diagnosed with end stage Breast cancer and her
oncologist told her that there is no further treatment. She wants to discuss with you about
her feelings and about the events which may follow:
a) End of life care. [5]
b) Advanced directives.in the light of indian laws and guidelines. [5]
8. A 42-year-old Ravi was working in fields when he suddenly had snake bite. Before he or
his fellow workers could identify, the snake had escaped.
a) Which are the common snake bites in India? [1]
b) From the clinical features of the patient, how would you identify the type of snake bite?
[2]
c) What investigations will you do (bed side and Lab)? [2]
d) What are the complications of snake bite? [2]
e) How will you treat Snake envenomation? [3]

[Page 6]
2023 April Paper 1
6
9. A 48-year-old Krishnan presented to OPD with history of Abdominal distension over past 3
weeks, gradually increasing, His wife gives history that he was diagnosed as a case of
cirrhosis of liver 6 months ago:
a) What are the common causes of cirrhosis? [2]
b) What are the clinical manifestations - symptoms and signs of cirrhosis? [2]
c) What are the complications of cirrhosis? [2]
d) How will you manage (INV+Treatment) this patient? [2]
e) How will you assess the severity of cirrhosis? [2]
10. A 45-year-old woman - P3L3 - is accompanied by her daughter for episodes of fear and
palpitations. She is a known hypertensive and is on telmisartan - thiazide 40/12.5mg OD.
Since January, following a marital conflict, she has experienced multiple episodes of sudden
onset of palpitations, sweating and dizziness. She is fearful of similar recurrence of such
episodes. Her multiple visits to hospitals during those episodes showed a BP- 220/120
mmHg with negative cardiology work-up. Her vital signs now - BP- 160/90 mmHg, P-90/min,
no elevated JVP or pedal oedema.
a) Describe the diagnostic criteria of panic attacks. [3]
b) List the possible medical conditions that may mimic a panic attack. [2]
c) Describe the options of pharmacotherapy for this patient. [3]
d) What are the non-pharmacological treatment options for this patient? [2]
2023 April Paper 1
1. Mr. A, is a 35 year old asthmatic on inhalers and regular follow up. He had no acute
asthma attacks for the last 8 months. He developed sudden onset of breathlessness and was
rushed to the hospital.
a) How do you clinically assess him for severe asthma? [2]
b) How will you manage acute asthma attack? [2]
c) How will you prevent asthma exacerbation? [2]
d) On examination, patient is found to have trachea deviated to the right side and absent air
entry on the left side of the chest. What is the likely diagnosis and what are the other clinical
features for this? [2]
e) How will you manage this condition? [2]
2. Mrs. S had fever for 2 days. 5 days later, she developed severe pain in both the hands,
fingers and toes. She has stiffness of hands and fingers in the mornings for about 45
minutes. She consults you after 1 week for her symptoms.

[Page 7]
2023 April Paper 1
7
a) What diagnosis will you entertain and what treatment will you provide? [2]
Patient continues to have symptoms and there is no improvement even after 8 months.
During the period, she has loss of hair and mouth ulcers.
b) What differential diagnosis will you consider? [2]
c) What investigations will you order? [3]
d) Patient has been seen by a rheumatologist and started on Prednisolone and
Methotrexate. He has asked you to monitor the patient. How will you do it? [3]
3. A 45-year-old man who has been drinking 3-4 pegs of whisky for few years, comes with
complaints of yellowish discolouration of the eyes and loss of appetite along with abdomen
pain. His last drink was 12 hrs ago. The family is worried and asks you to evaluate him and
manage.
a) What are the possible causes for his jaundice? [1]
b) What tool can be used to screen for alcohol abuse? [2]
c) What laboratory tests will confirm your diagnosis? [3]
d) The patient is not willing to go to the hospital immediately and wants to wait for 2 to 3
days. What treatment will you provide before the patient decides to go to hospital? [2]
e) Patient has been discharged from the hospital, how will you prevent a relapse of his
alcohol problem? [2]
4. A patient who was diagnosed to be infected with HIV, has been started on cotrimoxazole
as prophylaxis. Two days later, he develops ulcers in the mouth and diffuse rash all over the
body.
a) What is the differential diagnosis? [2]
b) How will you treat this condition? [5]
c) What are the infections he is at risk for? [3]
5. Mr. M is an obese individual. He was diagnosed as having diabetes and started on Tab.
Glibenclamide 5mg two times a day. Three days after starting the treatment, his wife found
that he was unresponsive and called you to see the patient.
a) What is the likely diagnosis? [1]
b) What treatment will you institute at home? [2]
c) He is shifted to your nursing home. What treatment will you provide in the hospital? [3]
d) What medication and advice will you provide on discharge? [4]
6. A 20-year-old lady presents with fever, headache and vomiting for the past 3 days.
a) What is your differential diagnosis? [2]

[Page 8]
2023 April Paper 1
8
b) What clinical features will you elicit to assess her? [2]
c) Outline the investigations and management of bacterial and tuberculous meningitis. [6]
7. Mr A. is a 70-year-old man who runs a small store. Recently his family has noticed that he
has been very forgetful. His accounts in the shop has been going wrong. He has also started
neglecting his personal grooming. At nights he shouts and says that he is seeing relatives
who have died and are calling him. Sometimes he is incontinent of urine.
a) What is the likely diagnosis? Outline the causes for it. [3]
b) Discuss investigations that will help you assess for this conditon. [4]
c) Discuss how you will help the patient and the family as their family doctor. [3]
8. A 70-year-old lady presents with pain of the left shoulder for the 2 weeks. She is a diabetic
and a hypertensive.
a) List the differential diagnosis. [2]
b) You suspect that she could be having coronary heart disease. How will you investigate to
confirm this? [3]
c) Outline the management of effort angina and unstable angina. [5]
9. A 45-year-old Mrs D presents with the problem of gaining weight. She has also become
lethargic, along with decreased appetite and constipation. She has also found that she is
very intolerant to cold weather. Her sleep has also been affected and she wakes up in the
middle of the night. She has also been feeling sad and keeps thinking that her life is
worthless. On physical examination, patient is obese and no other physical abnormalities
present except for some dryness of her skin.
a) What diagnosis or conditions would you consider? [2]
b) What tests will help you in management of this patient? [3]
c) How will you treat the patient? [3]
d) What advice will you give to the family? [2]
10. Mr. C is a 36-year-old businessman from Mysore. After returning from a recent travel to
Odisha, West Bengal and Manipur, he has developed high grade fever with chills and rigors.
He consults you after 10 days of fever. On examination, he has a spleen that is palpable 5
cms below the costal margin in the midclavicular line. It is soft and non tender. Other
systems are normal.
a) List the differential diagnosis for this condition. [2]
b) What investigations will you do to arrive at a diagnosis? [2]
c) Briefly outline the treatment for each possible cause. [5]

[Page 9]
2023 October Paper 1
9
d) What preventive measures will you advise the patient when he has to visit the areas
again? [1]
2023 October Paper 1
1. Mrs. Shakila, 30-year-old female, works as a clerk in Government office. She presented to
your OPD with complaints of recurrent headache for the past 2 years, 3-4 episodes per
month, associated with nausea and occasional vomiting,
a) What could be the cause of her headache? How do you evaluate her? [3]
b) How do you classify headaches? What are the common causes? [3]
c) Mention 2 drugs that cause headache. [1]
d) What are the red flags in history and physical examination of headaches? [3]
2. A 68-year-old male was brought to you with history of sudden onset headache and
difficulty in using left upper and lower limbs since past 40 min. He was stuporous and BP-
was190//120mmHg, Power in Left UL and LL was 2/5.
a) What is your clinical diagnosis in this patient? Mention the causes of cerebrovascular
accidents. [2]
b) How do you clinically differentiate between thrombotic and hemorrhagic strokes? [3]
c) What are the findings on CT for a hemorrhagic stroke? [2]
d) What are the indications of thrombolysis and what are the guidelines for administration
of r-tPA? [3]
3. A 58-years-old female presented to you with history of feeling hopelessness, tiredness for
3 months and has put on 5 kg weight, feels fatigued and drowsy:
a) Which are the medical conditions that can mimic depression? [3]
b) What are the criteria for a depressive episode? [3]
c) What is the tool used as a diagnostic aid in primary care? [2]
d) When do you refer a patient of depression to a specialist? [2]
4. A 56-year-old male presented to OPD with complaints of swelling of feet and breathing
difficulty which has been increasing over the past 8 weeks. He is a diabetic and hypertensive:
a) What are the precipitating causes of cardiac failure? [2]
b) What are the signs of left and right heart failure? [2]
c) What investigations you would want to perform? [2]
d) What are the nonpharmacological and pharmacological managements? [4]

[Page 10]
2023 October Paper 1
10
5. A 45-year-old male daily wage labourer has presented to you with recurrent episodes of
breathlessness, cough and sputum production. He has given history of smoking since he was
15 years old, till recently he had been smoking 1 pack per day:
a) How do you differentiate between bronchial asthma and COPD? [2]
b) Write the differences on physical examination and chest X-ray, between obstructive and
restrictive lung disease. [3]
c) What are the complications of COPD? [2]
d) Write briefly the management of COPD. [3]
6. Miss Renuka had eaten prawn fry brought from outside. Suddenly she started feeling
itching all over body. She developed urticarial rashes. Her PR- 122, BP- 80/45mmHg and
SpO2- 90%:
a) What is the condition? How will you assess the patient? [3]
b) What are the causes of her condition? [1]
c) How will you manage her? [4]
d) What advice will you give her to prevent it? [2]
7. A 74-year-old woman presents for her annual physical examination and notes increasing
fatigue over the past 3 months. Her history is notable for longstanding systolic hypertension.
A physical examination now demonstrates a blood pressure of 120/70 mmHg and an
irregular pulse of approximately 120 bpm at rest. The patient’s body mass index is 22. An
electrocardiogram confirms atrial fibrillation with a ventricular response of 120 bpm and
ECG suggestive of left ventricular hypertrophy. An echocardiogram done a year earlier to
evaluate left ventricular hypertrophy was notable only for mild, global left ventricular
dysfunction with a left ventricular ejection fraction of 40% and mild mitral regurgitation. The
patient’s chronic medical regimen includes lisinopril 20 mg, metoprolol XL 25 mg and 75 mg
aspirin daily. A repeat echocardiogram performed in the office demonstrates an ejection
fraction of 20% with global hypokinesis.
a) What medications should be chosen to control the rate acutely? [2]
b) What further work up is required for new onset AF? [2]
c) Should one restore sinus rhythm or choose a strategy of rate control? [2]
d) What are the anticoagulation requirements for this patient? [2]
e) If the decision is made to maintain sinus rhythm after the cardioversion, what are the best
medical or procedural options? [2]
8. A 29-year-old male has come with history of painless ulcer for the past 2 weeks over the
penis. On examination, there is a single nontender indurated ulcer on the penis. Inguinal
lymph nodes are enlarged:

[Page 11]
2024 May paper 1
11
a) List the conditions which can cause genital ulcers. [2]
b) What serological tests should be done? [2]
c) How will you manage this patient? [2]
2 months later, he presents with urethral discharge.
d) What organisms cause urethral discharge? [2]
e) How will you manage him in this visit? [2]
9. A 30-year-old male presented to you with complaints of groin itching, which you
diagnosed as fungal infection and you wanted to rule out diabetes and the GRBS- 297mg%:
a) How do you confirm the diagnosis of diabetes mellitus? [1]
b) What is the pathophysiology in type 1 and type 2 diabetes? [2]
c) How do you manage an overweight recently diagnosed diabetic? [3]
d) List two indications to start insulin in a diabetic? [2]
e) How do you treat hypoglycemia in adults and neonate in a hospital setting? [2]
10. A 28-year-old returned from Chennai when he presented with high grade fever, with
chills and rigors:
a) What are the differential diagnosis of fever with chills and rigors? [2]
b) What is severe complicated malaria? [3]
c) Write briefly about management of acute uncomplicated malaria and severe falciparum
malaria. [3]
d) Mention drug schedule for Chemoprophylaxis in chloroquine sensitive and resistant areas.
[2]
2024 May paper 1
1. A 52-year-old male presented to you with complaints of progressive dyspnea on exertion
for the past 2 months. He has never consulted a doctor so far in the past two months. He
reports bleeding per rectum in the past two months for which he took native treatment
from traditional healers. On examination, his face is puffy and significant pallor is present.
There is bilateral pitting pedal edema and Jugular Venous Pulse is elevated. His pulse rate is
110 per minute and regular in rhythm. His blood pressure is 210/100 mmHg in the right
upper limb. His BMI is 35 Kg/m2.
a) Write a problem list and provisional diagnosis for this patient. [2]
b) What are the possible etiological factors contributing to the clinical picture? [2]

[Page 12]
2024 May paper 1
12
c) What are expected abnormalities in hemogram and other routinely done blood
examinations? [2]
d) As a family doctor, how will you manage this patient in your practice? Mention two
indications for referral to the specialist. [4]
2. A 62-year-old housewife, post-menopausal for 10 years, reports that an hour ago, she had
sudden onset of weakness of her right upper and lower limbs associated with difficulty in
speech, which lasted for only 10 minutes but recovered completely. She had headache,
sweating and palpitation associated with this condition. She is a diabetic and hypertensive
on treatment from you and her blood pressure is 200/110 mmHg and pulse rate is 80 /
minute and regular. Her BMI is 25 Kg/m2. Now, she is oriented, conscious and her
neurological examination is normal.
a) What are the four possible differential diagnosis you consider in this patient? [2]
b) What are the possible risk factors leading to this problem? [2]
c) How will you calculate the risk of stroke and prevent an stroke in the coming 4 weeks [2]
d) Investigation and management in family medicine. [4]
3. A 21-year-old girl, a college student is consulting you for recurrent headaches for the past
6 months. Headache comes once in 3 to 4 days, mostly in the evening hours, unilateral,
severe pulsating quality associated with flashing of lights in the eyes. There is nausea and
sometimes vomiting associated with the headache. This headache is more frequent near the
exams and she is well in between the headache episodes.
a) Mention four common types of chronic recurrent headache. [2]
b) Explain management of acute migraine attack and prevention of migraine. [4]
c) Mention any six red flags in headache. [2]
d) Explain a tool you will use to manage a patient with recurrent benign presentation in
family medicine. [2]
4. An 80-year-old female presents with forgetfullness and has not switched off the gas stove
on 2 occasions as noticed by her daughter who lives nearby:
a) What are the clinical features of dementia? [3]
b) What are the reversible causes of dementia? [3]
c) How will you manage an 80-year-old female with dementia and living alone? [4]
5. A 25-year-old unmarried IT professional presented with multiple well defined
erythematous plaques with silvery scales over the extensor aspect of lower limbs, upper
limbs and back which is symmetrically distributed.
a) What is your clinical diagnosis? Give two triggering factors. [3]
b) Write the etiopathogenesis & classification. [3]

[Page 13]
2024 May paper 1
13
c) How will you manage this patient? [2]
d) How will you counsel this patient to prevent further worsening of this condition? [2]
6. A 56-year-old man is brought to you with history of snake bite over left foot:
a) What are the clinical features of envenomation you will look for? [3]
b) How will you manage this patient if he has features of envenomation? [5]
c) How will you educate the public regarding the first aid after a snake bite? [2]
7. In your family practice, you encounter many adult males having cigarette smoking as a
habit and few patients are presenting with complications related to smoking. You are
planning to implement a smoking cessation strategy in your practice.
a) Briefly describe the 5 A technique in smoking cessation. [2]
b) What are the six stages in the Transtheoretical model in any behaviour change? [3]
c) Explain the pharmacological and non-pharmacological methods available for smoking
cessation. [5]
8. A 45-year-old businessman presented with fatigue and daytime sleepiness. Wife gave
history of snoring. He is a type 2 diabetic, hypertensive on regular treatment. His BMI is 35
Kg/m2. His neck circumference is 44 cms.
a) Give one most probable cause and two other possible causes for his symptoms. [2]
b) Mention about a clinical score you will use to calculate his risk for the most probable
cause. [2]
c) Briefly describe the pharmacological and non-pharmacological methods of weight
reduction in this patient. [4]
d) Enumerate eight complications of obesity. [2]
9. Mrs. Kamala 58 years, has an incurable cancer of the breast with a large fungating tumor.
She has been attending hospital for dressings but can no longer afford the journey or the
materials needed for dressing. Her daughter is willing to learn the techniques of caring her
mother, but the smell is very bad, and Kamala is in pain most of the time.
a) What are the main issues faced by Kamala? [2]
b) How can we help in pain relief? [2]
c) How can we help them avoid the bad smell? [2]
d) How can we support her daughter? [4]
10. A 30-year-old male, a shop keeper, has come to the family doctor for cough and sputum
production for six months. His sputum testing for acid fast bacilli is positive. You are planning
to start anti-tuberculosis chemotherapy. Now he reveals that he has already completed two
months of TB treatment elsewhere three months ago and discontinued.

[Page 14]
2024 October Paper 1
14
a) Define Multi-drug resistant Tuberculosis. [2]
b) What are the factors contributing to Multi-drug resistant Tuberculosis in India? [2]
c) How will you rule out Multi-drug resistant Tuberculosis in this shop keeper? [2]
d) What is the treatment regimen recommended for this patient under National Tuberculosis
Elimination Program? [4]
2024 October Paper 1
1. A 40-year-old gentleman Mr. X presents to the family physician for routine check-up. On
examination, his blood pressure was found to be 180/100 mmHg. He is reporting headache
in the evenings for the past 1 month. He smokes 20 cigarettes per day for past 20 years. He
consumes alcohol 180 ml per day for the past 5 years. His own brother had heart attack and
angioplasty at the age of 40 years and he is worried whether he needs to take medications
to prevent heart attack.
a) What are the precautions you will take to avoid error in the measurement of blood
pressure in your clinic? [1]
b) How will you manage Mr. X? [4]
c) Mention any three important anti-hypertensive drug classes recommended for Mr. X and
mention their side effects. [3]
d) What is hypertensive urgency and hypertensive emergency? [2]
2. A 35-year-old male presents with complaints of vomiting blood for the past 2 days. On
examination, he is pale with pulse rate of 110/minute and blood pressure of 90/50 mmHg.
a) What is the immediate management recommended? [4]
b) What are the possible differential diagnosis causing blood vomiting? [1]
c) What are the types of blood and blood products available for transfusion? [2]
d) What are the reactions caused by blood transfusion and how will you manage the
transfusion reaction? [3]
3. A 20-year-old male, a college dropout, presents to the casualty with alleged history of
taking a large number of Tab. Paracetamol less than an hour ago with the intention of
deliberate self-harm. He is conscious and oriented with normal vitals.
a) Mention the principles in the immediate management a patient with any drug overdose.
[4]
b) How will you manage this person in the hospital and after discharge? [6]
4. A 40 year old obese lady with diabetes on your follow-up has presented with high grade
fever and chills associated with vomiting and loin pain on right loin for past 1 day. On

[Page 15]
2024 October Paper 1
15
examination, she is febrile, toxic, dehydrated and has right renal angle tenderness. Her
investigations showed urine WBC - 250 cells/cumm.
a) How will you manage her in the first two days? [5]
b) If the urine culture shows E.coli significant growth > 105 colonies grown, resistant to
Cephalosporin and Penicillin group antibiotic, what is the preferred antibiotic of choice and
justify your choice. [3]
c) How will you manage this lady if this condition is recurring again? [2]
5. A 20-year-old lady, a college student, presents with the complains of multiple painful
papules with central blackish keratotic material and surrounding erythema, present in her
face, neck, chest and upper back. These lesions started two months back and recently some
lesions are painful. She is very much worried and disturbed.
a) What is the probable diagnosis? [2]
b) What is the etiology and pathogenesis of this condition? [3]
c) How will you manage this skin lesions? [3]
d) What is the prognosis and when will you refer this lady to the specialist? [2]
6. A 45-year-old gentleman, a known case of hypertension on Tab. Amlodipine 10 mg once
daily has come for follow-up. He is on regular medications and his blood pressure is 160/90
mm Hg. His BMI is 29 kg/ m2. His annual blood check-up shows Total Cholesterol - 280
mg/dl, Triglycerides - 155 mg/dl, HDL - 33 mg/dl and LDL cholesterol - 182 mg/dl. HbA1c -
7.8 %. His creatinine is 0.9 mg% and his urinary microalbumin excretion is 900 mg in 24
hours.
a) Describe the pharmacological and non-pharmacological management needed for this
patient. [5]
b) Describe briefly the different oral anti-diabetic medications available – classification,
mechanism of action and their side effects. [5]
7. A 65-year-old gentleman on treatment for hypertension with tab. Hydrochlorothiazide 25
mg once daily, presents to the casualty with altered sensorium. There was no h/o fever /
vomiting / diarrhea. The blood work-up showed Random Blood sugar of 210 mg, Creatinine
of 0.9 mg and Serum Sodium of 115 mEq/L and Potassium of 4 mEq/L
a) What is the likely cause for his altered sensorium? [2]
b) How will you manage this patient? [4]
c) How will you prevent this happening in the future? [2]
d) What are the indications for referral to the specialist? [2]

[Page 16]
2025 June paper 1
16
8. A 45-year-old businessman comes to see you in the OPD with complaints of increasing
abdominal distension. He consumes alcohol 180 to 360 ml daily for the past 10 years. On
examination, you demonstrate fluid in the abdomen.
a) What are the causes for ascites? [2]
b) What are the other clinical features you will look for in this patient? [2]
c) How will you further evaluate this person with ascites? [2]
d) What are the complications of ascites? [2]
e) How will you manage and follow up this person? [2]
9. A group of 4 people presented with multiple episodes of loose stools and vomiting after
having food in a fast food restaurant. After assessing them, you decide to admit to correct
dehydration and for further evaluation.
a) What are the different causes of gastroenteritis? [2]
b) What are the clinical features you would look for in these people? [2]
c) How will you further evaluate and manage? [4]
d) What are the complications of severe AGE and when will you refer? [2]
10. A 45-year-old man is on treatment for Parkinsonism and has come to see you for follow
up.
a) What is the aetiology for Parkinsonism? [2]
b) What are the clinical features in Parkinsonism? [2]
c) What are the differential diagnoses? [2]
d) How will you treat and when would you refer? [4]
2025 June paper 1
1. A 24-year-old young man sustained RTA on a bike. He was taken to the trauma care center
immediately. His pulse rate is 140 beats per minute with feeble thready pulse and blood
pressure was 60 mmHg systolic:
a) What is the pathophysiology of shock in this patient? [2]
b) Classification of shock - explain each one of them with an example. [4]
c) How will you provide initial management in each type of shock? [4]
2. A 52-year-old gentleman was brought to the OPD with chest discomfort since this
morning. He has no comorbidities.
a) What initial assessment will you perform? [2]

[Page 17]
2025 June paper 1
17
b) Write the findings in ECG consistent with ST Elevation Myocardial Infarction (STEMI). [3]
c) What is the initial management you provide for STEMI? [2]
d) Mention the definitive management in STEMI and Non STEMI. [3]
3. A 18-year-old girl, a college student, has come with multiple black spots, papules, pustules
with nodules and old scars in the face and neck:
a) What is the probable diagnosis and differential diagnosis? [3]
b) How will you manage this condition? [5]
c) What are the indications for systemic therapy? [2]
4. A 20-year-old college student is brought to OPD with history of talking to herself, smiling
to herself, and having auditory hallucinations:
a) What is the probable diagnosis? [2]
b) What are the factors differentiating organic versus functional condition? [3]
c) What is the initial and long term management for this patient? [5]
5. A 35-year-old lady with a BMI of 30 kg/m2 presented to you with irregular cycles:
a) What is the criteria to define metabolic syndrome? [3]
b) What are the investigations needed for this lady? [3]
c) Discuss the management along with the goals and rationale of therapy. [4]
6. A 53-year-old lady with diabetes presented to you with complaints of left loin pain,
vomiting and fever for the past 4 days. She is febrile (103°F), toxic and dehydrated. She has
left renal angle tenderness:
a) What is the likely diagnosis? How will you do initial assessment and management in the
given case scenario? [5]
b) What are the indications for referral to higher center? [3]
c) What are the indications for dialysis in acute renal failure? [2]
7. A 72-year-old man is brought by the relatives to your clinic. They informed that he was
well a week ago and now he is disoriented to time and place. He is not able to identify even
the close relatives and he is agitated at home. He is running a low-grade fever for the past
one week. He vomited occasionally and has reduced appetite.
a) What are the differential diagnosis you consider? [2]
b) What is the focused clinical examination and investigation required? [4]
c) How will you manage this elderly gentleman in your practice? [4]

[Page 18]
2025 June paper 1
18
8. A 33-year-old software engineer had a binge of alcohol last night, following which this
early morning, he developed acute onset of persistent, severe epigastric pain radiating to
the back. Examination shows tenderness and guarding in the epigastrium.
a) What is your diagnosis and differentials? [3]
b) How will you manage this person? [4]
c) What score do you use to assess the severity and prognosis? [3]
9. A 23-year-old lady presents to you with bilateral leg swelling, frothy urine, malar rash and
arthralgia; you suspect an autoimmune disorder:
a) Discuss the initial assessment of this lady. [4]
b) What is your differential diagnosis? [2]
c) What are the major clinical features and organ involvement in the condition mentioned
above? [4]
10. A 40-year-old driver, married for past 10 years with two children, presents with 10% loss
of weight over past 2 months and cough for the past one month. It is a dry cough with
scanty sputum
production. He reports breathing difficulty for the past one week. He has loss of appetite
and passing watery frequent loose stools for the past one month. He gives history of high-
risk sexual behavior. On examination, he has oral candidiasis. He has tachypnoea, respiratory
rate of 40 per minute and auscultation revealed occasional crackles bilaterally:
a) What is the probable diagnosis? [2]
b) How will you manage this patient and his family? [8]

[Page 19]
2022 June Paper 2
19
Paper 2 (General Surgery and allied)
2022 June Paper 2
1. A-78-year old lady with right sided hemiplegia is being discharged from hospital. Relatives
are taking her to her home at a remote village. She is bedridden and is on indwelling
catheter and Ryle’s tube feeding:
a) What are the problems that you can anticipate in this patient? [2]
b) What advice will you give to prevent bed sores in this patient? [3]
c) How will you classify bedsores? [3]
d) Family physician’s role in managing bed sores. [2]
2. A 40 year old lady came with dilated and tortuous veins over lower portion of her left leg.
Discuss the following:
a) Anatomy of venous system of lower limb. [3]
b) Clinical features of varicose vein. [3]
c) Prevention and management of varicose vein. [4]
3. Describe the anatomy, clinical features and management of plantar fasciitis. How can
plantar fasciitis be prevented? [(3+3)+4]
4. What is the pathogenesis of osteo-arthritis (OA)? What are the common joints involved,
their symptoms, clinical features of osteo-arthritis? Outline the relevant investigations and
management of OA. [2+4+4]
5. A 10-year-old girl presented with purulent right ear discharge for last 3 days. She had
similar complaints in the past on the same side. Describe in detail about clinical features,
examination findings, investigations, treatment and complications of this condition.
[2+2+2+2+2]
6. Describe briefly the clinical anatomy, indications, contra-indications and complications of
ankle block. How will you do the procedure? [8+2]
7. Describe the possible ophthalmic complications of diabetes. Explain about stages of
diabetic retinopathy and its management options available to the ophthalmologist. [5+(3+2)]
8. A 70 years old female, diabetic, strict vegetarian who is a mother of 5 children presented
with history of dribbling of urine:
a) Mention the types of urinary incontinence. [3]
b) What are the possible aetiological factors in the case scenario given above? [3]

[Page 20]
2022 December Paper 2
20
c) As a family physician, how will you manage this case. [4]
9. A 30 years old male presented with severe epigastric pain since one day. His PR-110 bpm,
BP-100/60 mm hg, RR-25/min. Write 4 diagnostic possibilities you would consider in this
patient. Describe in detail about clinical features, investigations and management of each.
[4+6]
10. A 40 years old lady came with a 3 cm size lump in the left breast. Enumerate differential
diagnosis and management of each. [4+6]
2022 December Paper 2
1. A 23-year-old Mrs. Renuka is being posted for emergency section for failed induction.
a) Explain the clinical anatomy for spinal anesthesia with a diagram. [3]
b) Discuss the pharmacological features of Bupivacaine used for spinal anesthesia. [3]
c) What are the indications, contraindications, and complications of spinal anesthesia? [4]
2. A 35-year-old lady accidentally suffered burns over the upper thighs upto the knee joints
on both sides and below the umbilicus on the anterior surface of the abdomen.
a) How will you assess burns in an adult? [2]
b) How will you monitor the patient for complications? [3]
c) Discuss the burns management of this lady. [5]
3. A 51-year-old female presents with palpable swelling in her left breast of 3 months
duration. She is post-menopausal for three years. She has no medical comorbidities.
Menarche was at 11 years of age. She has 2 children with her first pregnancy at 29 years of
age.
a) How will you investigate this patient? [2]
b) What are the current recommendations for screening for breast cancer? [3]
c) Discuss the possible risk factors associated with malignancy of breast. [2]
d) Outline the long term management of this patient by you as her family doctor. [3]
4. Mrs. Varalakshmi had a fall in the bathroom and is unable to move her right leg and not
able to bear weight. She has tenderness over the right leg anterior aspect.
a) Describe the principles in management of fractures with a special mention about fracture
of the lower limbs. [6]
b) What are the early and late complications? [4]

[Page 21]
2022 December Paper 2
21
5. Mrs. Satya aged 40 years, presented to outpatient department with history of tiredness
and fatigue, she gives history of heavy menstrual bleeding for 5 days, and on examination
she is pale.
a) What are the indications of blood transfusion? [2]
b) What are the risks and complications of blood transfusion? [3]
c) What tests will you do on the donor blood before transfusion? [2]
d) What measures will you take before, during and after the transfusion in the ward? [3]
6. A 18-year-old married lady, presents with pain in the right side of the abdomen for the
past one day. On examination, she has tenderness in the right iliac fossa.
a) What is your differential diagnosis? [3]
b) What relevant history and examination will you perform? [3]
c) How will you manage this condition if the patient is in shock? [4]
7. A 15-year-old Sridhar presented to your OPD with history of profuse right ear discharge
for 6 weeks?
a) What is your diagnosis? What are the salient features? [2]
b) What are the risk factors? Mention four common pathogens causing this condition? [3]
c) What are the complications of this condition? [3]
d) How will you manage this condition? [2]
8. A 35-year-old Devi, an agricultural worker, mother of two children, has come to the out-
patient clinic with history of pain and discharge from Right eye associated with blurring of
vision since she returned from the field. The right eye is red, and the cornea has haziness.
a) List any THREE possible differential diagnosis. [3]
b) How will you manage Mrs. Devi, if she refuses referral to eye doctor in the next town, as
she need to take care of the two children? [7]
9. A 23-year-old Sweta presented to your Outpatient department with history of lowback
ache, and more recently with right leg pain, this is her fourth visit in last 8 weeks.
a) What is the etiopathology of lumbosacral radiculopathy? [2]
b) What are your differential diagnosis and patients with what diagnosis need urgent
diagnostic evaluation? [3]
c) What is the clinical presentation according to level of nerve root involvement? [2]
d) What will be your approach to the management of this patient? [3]
10. A 48-year-old Mr. Raman has Type II DM for 2 years, He is on a routine follow up visit to
you. You are counselling him with regards to DM.

[Page 22]
2023 April Paper 2
22
a) What are the macrovascular complications of diabetes? [2]
b) What are the risk factors to develop Diabetic foot? [2]
c) What relevant foot examination should be performed? [2]
d) How will you manage diabetic foot ulcers? [2]
e) How will you prevent foot complications in a diabetic patient? [2]
2023 April Paper 2
1. A 56-year-old postman comes with pain in the legs for the last 3 years. Pain occurs in both
the thighs and legs after walking for 15 min. It is relieved by rest. Since last two months, he
has pain when he walks a short distance. He has been smoking about 6 to 8 cigarettes per
day for the past 20 years. He also hurt his right leg over the lateral aspect few weeks ago and
the wound is not healing:
a) What is the probable diagnosis and differential diagnosis? [1]
b) What clinical features would you look for? [2]
c) How will you investigate this patient? [2]
d) What treatment will you offer for the condition as well as the ulcer? [2]
e) How will you help him to stop smoking? [3]
2. A 66-year-old lady presented with painful swelling of the lower eyelid near the bridge of
the nose:
a) Enumerate the differential diagnosis. [3]
b) Discuss the management. [7]
3. You are called to see a lady who was injured by a stove burst:
a) What first aid will you provide? [2]
b) How will you assess the severity of different injuries that the patient may suffer? [5]
c) How will you manage this patient after discharge from the hospital? [3]
4. A 35-year-old labourer has come with low back which started suddenly after he lifted a
heavy object:
a) List the red flags in a patient presenting with low backache. [2]
b) Discuss the history and clinical features of lumbosacral intervertebral disc prolapse,
including a note on the dermatomes of the lower limb. [4]
c) How will you assess if a patient with lumbosacral disc prolapse needs urgent referral? [2]

[Page 23]
2023 April Paper 2
23
d) Outline conservative management of lumbosacral disc prolapse. [2]
5. A 14-year-old old boy presents with fever and sore throat:
a) Write the differential diagnosis. [5]
b) Discuss rational use of antibiotics for treating patients with sore throat. [5]
6. A 24-year-old lady presents with a swelling in the right breast. Swelling is freely mobile
and on palpation of the left breast, the physician detects two small swellings. Her
grandmother died of carcinoma of breast and her mother is being treated for the same.
Patient is worried about her conditon:
a) What is the probable diagnosis? [1]
b) What investigations will you do? [2]
c) When will you refer the patient to a surgeon? [2]
d) She wants to undergo special investigations she read about in the internet to screen for
cancer. What will you advise her? [2]
e) She has a 1-year-old child and wanted to discuss about contraception. What would you
advise her? [3]
7. A 48-year-old farmer who has been a diabetic for the last 15 years and on oral anti-
diabetic drugs and insulin presents with an ulcer on the plantar aspect of the left foot:
a) Describe physical examination findings that can help you in the assessment and
management of the ulcer. [3]
b) How wiill you manage the ulcer in family practice? [3]
c) Discuss indications for referral to a surgeon. [2]
d) Write a note on prevention of diabetic foot ulcer. [2]
8. A 28-year-old married lady presents to a remote community health centre with fever and
acute abdominal pain for the past 3 days. Pain is localised to the right illiac fossa. She has
missed her periods by 5 days. On examination, she has tenderness in the right iliac fossa
with no guarding or rigidity:
a) What is the differential diagnosis for this presentation and the most probable cause? [2]
b) How will you investigate her? [3]
c) Can this patient be treated in a community health centre? If so, what is the treatment that
you will recommend? [3]
d) What are the indications for referral to a higher centre? [2]
9. A labourer comes with severe pain in the right hand with a high fever. On examination,
the right palm is swollen with tenderness over the mid palmar area:

[Page 24]
2023 October Paper 2
24
a) What are the risk factors for formation of this abscess? [2]
b) What organisms are likely to cause this infection? [2]
c) How will you medically manage this conditon? [3]
d) How will you surgically manage this patient? [3]
10. A male patient who has sex with men comes with severe pain and bleeding form the anal
region:
a) What is the differential diagnosis? [3]
b) What investigations will you order? Give the reasons for the same. [4]
c) What treatment will you provide for infective causes for this presentation? [3]
2023 October Paper 2
1. A 42-year-old man has been diagnosed with diabetes for the last 5 years. He has been
coming to you for regular follow up:
a) How will you perform his foot examination? [2]
b) What advice will you give him with regards to foot care? [2]
c) What are the complications of diabetic foot? [2]
d) What are the other causes of non-healing leg ulcer? [2]
e) What are the principles of management of diabetic ulcer? [2]
2. A 40-year-old presented with the complaint of feeling dizzy:
a) What are the conditions that you will enteratin in a patient presenting with dizziness? [2]
b) Mention the causes of vertigo. [2]
c) Which are the medications that can cause dizziness? [2]
d) When do you refer a patient with dizziness? [2]
e) What test you perform for BPPV, how will you manage BPPV? [2]
3. A 28-year-old female came for antenatal checkup, she was found to be Hbs Ag positive.
Her husband was also checked and found to be HBsAg positive:
a) Who are the groups of people at increased risk for transmission? [2]
b) Which are the acute phase and chronic phase serological markers? [2]
c) What will be the course of disease? [2]
d) Write briefly on management of chronic Hepatitis B. [2]

[Page 25]
2023 October Paper 2
25
e) If her husband was tested negative, what advice you would have given? [2]
4. A 32-year-old male presented to you with palpable swelling in the left groin which he
noticed a few days ago, he has mild pain while walking or on lifting weight:
a) What are the differential diagnosis? [2]
b) What are the common causes of inguinal and scrotal swelling? [2]
c) How will you evaluate a patient with groin swelling? [2]
d) What are the red flags of inguino scrotal swelling? [2]
e) Write briefly on inguinal hernia. [2]
5. A 23-year-old female presented to you with redness of left eye, which she noticed this
morning, she also mentioned there was a sticky discharge:
a) What are the common causes of red eye in primary care? [2]
b) Mention at least 4 systemic conditions that can cause red eye. [2]
c) Mention at least 6 must know points in the history. [3]
d) What are the red flags in history of a patient with red eye? [1]
e) Mention 4 conditions of the eyelid with which patients present to primary care. [2]
6. A 58-year-old female a poorly controlled diabetic presented to you with ulcer and foul
smelling discharge from left foot 2nd toe. X-ray showed osteomyelitis changes of the
phalanges and toe amputation is planned:
a) Mention at least three regional anesthesia given, and local anesthetic agents used. [2]
b) What are the complications of regional anesthesia and how do we manage them? [2]
c) What sedatives are used in primary care? [2]
d) What are the injectable anesthetics? [2]
e) What analgesics are used while performing minor procedures? [2]
7. A 32-year-old female presented to you with hot sambhar spilt all over her as she was
getting it down the stove:
a) What are scalds? What is the characteristic of scalds? [2]
b) What is the upper limit of percentage of burns you will treat in primary care? [2]
c) List pathophysiological changes in any 2 of these organs -
skin/kidney/immunity/hematological. [3]
d) Estimation of burn size in adult-using Rule of 9, depict it in the diagram. [3]
8. A 65-year-old man presents with history of tiredness, frequent stools and decreased sleep
for the past 3 months. She is a known diabetic on Metformin 1gm BD. She also reports to

[Page 26]
2024 May Paper 2
26
have a recent loss weight of 3 Kgs. On examination, extremities are warm to touch, pulse-
110/min, BP-140/70mmHg, cardiac auscultation S1S2 present and a soft systolic murmur
over apex and aortic area, chest is clear.
a) What are the functions of thyroid hormones in a normal human? [2]
b) What are the common symptoms and signs of hyperthyroidism? [3]
c) What are the common symptoms and signs of hypothyroidism? [3]
d) What complications do you expect in her if she is left untreated? [2]
9. A 65-year-old male presented with recent history, nausea and loss of appetite and dark
coloured stools, he was pale and his haemoglobin was 6.5gm%:
a) What clinical diagnosis you would offer as the cause of his anemia? [2]
b) What all points you will elicit in history to find out the possible causes of anemia? [2]
c) How do you classify hypovolemic shock? [2]
d) What medications can cause anaemia? [2]
e) What are the indications of blood transfusion in anemia?[2]
10. A 24-year-old female has comes to you with history of swelling and tenderness of right
breast for 2 days. She has mild fever and she is feeding her 3-month-old baby:
a) Mention and briefly write about at least 4 breast conditions a patient present to Family
practitioner. [3]
b) Write the various types of nipple discharges and give one condition for each. [3]
c) Write in detail how will you manage her? [4]
2024 May Paper 2
1. A 48 year old man working in a petrol pump, has a problem of recurrent leg ulceration on
his right leg just above medial malleolus. It is associated with dull ache and vague discomfort
and associated edema towards evening. On examination there is a 2×3 cm shallow ulcer
with serous discharge and pigmentation of surrounding skin present.
a) What is your most probable diagnosis for his leg ulcer? [1]
b) What are the examination findings you will look for in this patient and how will you treat
this condition? [4]
c) Mention ANY SIX factors that affect wound healing that may lead to non-healing ulcers. [3]
d) What advice will you give to prevent recurrence? [2]

[Page 27]
2024 May Paper 2
27
2. A 10-year-old boy was brought to you complaining of impaired hearing and sensation of
blocked ear. His teacher was complaining of decreased academic performance. On
examination impacted wax is present in both external auditory meatus.
a) What are the modalities of treatment? [2]
b) Explain the procedure, contraindication & complication of syringing. [4]
c) Indications for referral. [2]
d) Red flags in hearing loss. [2]
3. A 40-year-old man has come to you with severe pain and swelling in the left index finger.
After examination, you diagnose paronychia and advise drainage of the pus. You want to
drain it without causing much pain.
a) Describe the procedure of the drainage of the paronychia in this patient. [3]
b) Discuss local anaesthetic agents used in general practice. [7]
4. A 22-year-old college student has come to the family doctor with pain and swelling in the
right testis since morning. He also has dysuria, fever and vomiting for 1 day. He gives no
history of trauma.
a) What is the most probable diagnosis and differential diagnosis in this patient? [3]
b) How will you resolve the differential diagnosis? [3]
c) Describe the management of the testicular pain in this patient. [4]
5. Thirty-year-old female came with numbness of her right palm on waking up in the
mornings for the last six months, and it is steadily worsening. She gave history of weight
gain, day time sleepiness and constipation. Her BMI was 26 kg/m2
a) What would be the most probable clinical diagnosis for her symptoms? [2]
b) Name the common entrapment neuropathies. What are their symptoms? [3]
c) What are the predisposing causes of entrapment at wrist? [1]
d) Discuss the management of this patient. [4]
6. Thirty-year-old male, agricultural worker, came with pain, redness and photophobia in the
right eye.
a) Mention any three clinical possibilities for this problem and how will you diagnose each in
family practice? [6]
b) How will you manage this patient with red-eye in Family Practice? [2]
c) Mention two indications for referral to the specialist. [2]

[Page 28]
2024 October Paper 2
28
7. Fifty-year-old diabetic and hypertensive male came with severe pain in right shoulder for
past one week. His shoulder abduction movement is restricted to 90 degree. There was no
history of any obvious trauma.
a) Mention the possible causes of shoulder pain. [3]
b) Discuss clinical examinations and special clinical tests that will help in your diagnosis. [4]
c) Management of shoulder pain in this patient [3]
8. You are called for a house visit to see an 80-year-old lady who is bedridden following right
sided hemiplegia for the past 8 years. Caregivers are worried about an ulcer they noticed
recently over the sacral area.
a) What are the Stages of Pressure Sore? [2]
b) What parts of your body do bedsores affect? What are the complications of bedsores? [3]
c) What are the nonsurgical and surgical treatment for bedsores? [3]
d) How can you prevent bedsores? [2]
9. An 82-year-old lady had a fall in bathroom. She has been brought to you with right lower
limb externally rotated. Her vitals being stable.
a) What is your provisional diagnosis and the plan for management? [3]
b) The relatives prefer to take her to a traditional bone setter for further treatment. How will
you counsel the relatives regarding the complications? [3]
c) What would you do to minimize trauma fractures in post-menopausal women? [4]
10. A 45-year-old female presented to you with a painless lump in the left breast upper
outer quadrant for past one month. It is firm in consistency, 3 x 3 cm in size and not freely
mobile. There is no local warmth or tenderness over the lump.
a) What are the differential diagnoses? [2]
b) How will you approach and investigate a breast lump in family medicine? [4]
c) What are the cancer screening tests you offer to a female patient and from which age till
which age? [4]
2024 October Paper 2
1. A 50-year-old lady with type 2 diabetes mellitus is referred to you for control of diabetes.
During screening, she was found to have diabetic retinopathy.
a) What are the types of diabetic retinopathy? [2]
b) How will you screen for diabetic retinopathy in family practice? [1]

[Page 29]
2024 October Paper 2
29
c) What are the treatment options available for each type of diabetic retinopathy? [4]
d) What is the role of Family physician in preventing diabetic retinopathy? [3]
2. A 15-year-old girl is brought by her parents with complaints of right ear foul smelling
profuse discharge for the past two months.
a) Define chronic suppurative otitis media. [2]
b) What are the types of chronic suppurative otitis media and how will you make the
differential diagnosis? [3]
c) How will you manage this girl? [3]
d) What are the complications you expect and what are the indications of referral to a
specialist? [2]
3. A 65-year-old post-menopausal lady with a BMI of 19, has been brought to the community
health center with history of fall with outstretched hand while lifting weight at home an
hour ago. She has severe pain and swelling in the left wrist. On examination, there is severe
tenderness in the left wrist associated with swelling and deformity.
a) What are the components of Colle's fracture? [3]
b) How will you treat Colle's fracture if you are posted in the community health center if
referral to specialist is not possible? [4]
c) How will you prevent fracture in this lady in the future? [3]
4. An 18-year-old girl has come with swelling in front of the neck for the past three months.
a) List the differential diagnosis. How will you differentiate thyroid swelling from other
swellings? [3]
b) Mention any four features of thyrotoxicosis you will look for in this patient. [2]
c) What are the initial investigations and management in family practice? [4]
d) List any two indications for surgical treatment? [1]
5. A 45-year-old man is awaiting for inguinal hernia surgery. He is on treatment for type 2
diabetes and hypertension. He is a smoker and consumes alcohol. He is referred by a
surgeon to optimize him for hernia surgery planned under regional anesthesia.
a) Describe briefly the components of Pre-Anesthesia Check-up. [5]
b) How will you optimize this person before hernia surgery? [5]
6. A 78-year-old man was brought to the casualty with complaints of altered sensorium since
morning. He has no comorbidities; he had sustained a trivial head injury few weeks ago. His
Computerized Tomography of the brain showed a large subdural hematoma with midline
shift.

[Page 30]
2024 October Paper 2
30
a) What is Glasgow Coma Scale? How will it help you in managing a patient with head
injury? [5]
b) What are the initial management recommended to stabilize this elderly man before
referral? [3]
c) What are the definitive treatment modalities recommended for this person? [2]
7. A 30-year-old lady at 20 weeks of gestational age comes to see you with complains of
difficulty in passing stools which is associated with pain. She is passing hard stools once in
two days that occasionally is streaked with blood.
a) What is the most probable diagnosis and how will you confirm the diagnosis? [4]
b) How will you manage this lady in family practice? [4]
c) What are the indications for referral to the specialist? [2]
8. A 24-year-old unmarried lady presents to the family physician with the painless lump felt
in her left breast for the past two months. On examination, she has a single 2x3 cm size,
mobile firm swelling in the left upper outer quadrant which is non-tender.
a) What are the differential diagnosis? [2]
b) Describe the investigations recommended for evaluation of the lump. [4]
c) What is BI-RADS scoring system and how will you manage the lump based on the BI-
RADS? [4]
9. A 30-year-old laborer, weighing 60 kg, presents to casualty with an injury to the right hand
with a metal instrument while working. An X-ray shows a metal foreign body in his hand.
a) Describe the steps of wrist block. [4]
b) What is the dose and type of local anesthetic drug recommended for this man? [3]
c) What are the anticipated complications when giving anesthesia for him and how will you
manage them? [3]
10. A 35-year-old lady has presented to the Community Health Centre with alleged history of
self-inflicted burns 30 minutes ago. On examination, she is conscious and oriented. She has
superficial burns over the front of the chest, anterior abdomen and right thigh. She is in
severe pain. Her pulse - 100 / min and Blood pressure is 130 /90 mm Hg.
a) What are the immediate treatment needed in the first 48 hours? [4]
b) How will you prevent hospital acquired infections in this patient? [4]
c) What are the indications of referral to the specialist? [2]

[Page 31]
2025 June Paper 2
31
2025 June Paper 2
1. A 53-year-old lady has come for a follow-up of her diabetes and hypertension; you send
her for an annual eye checkup.
a) Classification of diabetic retinopathy with diagrams. [3]
b) How will you prevent the progression? [3]
c) What are the ocular effects of hypertension? [4]
2. A 43-year-old businessman arrived after a long air travel; the next day, he came to your
OPD with complaints of pain in the calf of his right leg associated with swelling.
a) Initial assessment and differential diagnosis of the presentation. [2+2]
b) Management of the above condition outlining the criteria for outpatient therapy. [4]
c) Long-term management of this businessman. [2]
3. a) Management of recurrent epistaxis in a 5-year-old child. [5]
b) A 70-year-old man has come with nasal bleeding for the past 1 hour. His blood pressure is
200/120 mmHg. How will you manage him? [5]
4. A 55-year-old farmer who is a diabetic has come to you with unilateral red eye associated
with severe pain.
a) What are the differential diagnosis of unilateral red eye? [2]
b) What are the additional history and examination required? [3]
c) How will you manage this condition if there is history of trauma with a stick in the
agricultural field? [5]
5. A 33-year-old woman presented to the OPD with a history of back pain that radiated to
the lateral aspect of the leg for 2 days:
a) What are your differential diagnoses? [3]
b) Discuss an algorithmic approach to the above mentioned condition. [4]
c) Indications for imaging in a person presenting with low back ache. [3]
6. Discuss the spinal anesthesia under the following headings:
a) Choice of spinal drugs and baricity of drugs. [3]
b) What complications do you anticipate and how will you manage? [3]
c) Management after giving spinal anesthesia – (Hemodynamic management, level of block,
sedation during spinal). [4]
7. A 75-year-old post-menopausal woman has presented with fracture of both bones right
lower limb after a trivial fall while on a regular walk.

[Page 32]
2025 June Paper 2
32
a) How will you assess this woman? [3]
b) How will you manage this woman? [4]
c) How will you prevent fracture in future for this woman? [3]
8. A 44-year-old laborer presented with fever, abdominal pain dull aching in the right upper
quadrant for the past 4 days. You also elicited the history of loose stools for past two weeks.
He gives history of unsafe alcohol consumption for the past 10 years. On examination, he is
febrile and toxic with soft abdomen with tender hepatomegaly and intercostal tenderness in
the right hypochondrium.
a) What is the probable diagnosis and differentials? [2]
b) What workup will you do? [3]
c) What medical treatment you will start? [3]
d) When will you refer for surgical management? [2]
9. A 21-year-old college student presented to you with right iliac fossa pain and vomiting.
The pain initially started from the umbilicus and shifted to right iliac fossa.
a) What scoring system will you use for the above condition and how will you interpret the
score? [4]
b) How will you manage the above condition? [4]
c) What are the indications for referral for surgery? [2]
10. A 17-year-old girl presented to you with a swelling in front of her neck, which moves
with deglutition. On examination, her pulse rate is 130 per minute and she has fine tremors.
a) What relevant history will you elicit and what will you look for in the examination? [3]
b) Describe the thyroid Image reporting and data scoring system. [3]
c) Describe the management of this 17-year-old girl. [4]

[Page 33]
2022 June Paper 3
33
Paper 3 (OBG and Paediatrics)
2022 June Paper 3
1. What is pre-conceptional counseling? How will you advice a couple married an year ago,
now planning for pregnancy? [2+8]
2. A 35-year old sexually active lady presents to you with vaginal discharge.
a) Briefly describe the differential diagnosis with their clinical features. [5]
b) WHO syndromic approach to sexually acquired infections. [5]
3. A 22-year old primigravida presented to you with bilateral pedal edema. On examination,
her BP was 150/90 mm Hg:
a) How will you manage this patient? [5]
b) What are the complications you expect in this patient? [5]
4. Enumerate prevention and screening for cervical cancer. [10]
5. Define puerperium. What are the common problems of puerperium? [2+8]
6. a) Define Severe Acute Malnutrition (SAM). [2]
b) How will you manage a child with uncomplicated SAM? [3]
c) What are the serious complications faced by children with SAM and how will you manage
them? [5]
7. What are the benefits of breast feeding? Mother of a one-month-old baby came to you
with complaint of decreased breast milk. How can this issue be addressed? [5+5]
8. Mother of a one-year-old girl child brought the child with history of fever, breathing
difficulty and stridor of one day duration.
a) Outline the differential diagnosis of stridor and fever in this baby. [5]
b) Management of each of these conditions. [5]
9. A one-year-old girl child was brought to you with history of convulsions. She had history of
fever since one day:
a) What are the differential diagnosis? [2]
b) How will you manage? [4]
c) How will you advice the parents regarding prevention and management of further
episodes? [4]
10. a) Describe the national immunisation schedule. [4]

[Page 34]
2022 December Paper 3
34
b) A 4 year old boy is brought to you for a wound in the lower limb after a fall. He is
unimmunised till now. How will you plan the immunisation in this boy? [6]
2022 December Paper 3
1. Define low birth weight. Mention the causes of low birth weight. What are the various
ways in which you can prevent low birth weight? [2+3+5]
2. Baby born 17 hours ago, was found to be icteric on examination. Baby is feeding well:
a) Explain the bilirubin metabolism. [3]
b) Write briefly on pathophysiology of neonatal hyperbilirubinemia. [3]
c) How will you manage this baby? [4]
3. Mrs. Rajani, primigravida, 38 weeks of gestation, admitted in the labor room of secondary
care setting. She was induced for high blood pressure. Her BP at admission was recorded to
be 164/112, Urine Albumin ++:
a) Define preeclampsia and severe preeclampsia. [4]
b) Discuss the management of this patient. [6]
4. A multigravida delivered half an hour back. She was found to have a heavy gush of vaginal
bleed:
a) Define PPH. [2]
b) What are the risk factors for PPH? [3]
c) How will you manage this patient? [5]
5. Pregnancy is one of the risk factors for UTI:
a) Explain why a pregnant lady is at risk for UTI. [4]
b) How would you manage a pregnant lady with UTI at various stages of pregnancy? [6]
6. 45-year-old Mrs. Geetha presented to outpatient department with history of heavy
menstrual bleed for past 3 months during her cycles, occasionally she gave history of
intermenstrual bleeding also:
a) What are the causes of abnormal uterine bleeding? [2]
b) What other history will you take and examination will you perform in Mrs. Geetha? [2]
c) How will you manage Abnormal uterine bleed (Investigation and treatment)? [4]
d) When will you refer her to a specialist? [2]
7. 9-months-old baby of Esther has presented in the OPD with history of 5 episodes of loose
stools, associated with vomiting for one day. The child is weighing 6 kg, with the birth weight

[Page 35]
2023 April Paper 3
35
of 3.2 kg. Child is lethargic, with sunken eyes and low skin turgor. There was no urine output
since today morning:
a) What is the diagnosis? [3]
b) How will you manage Baby of Esther? [4]
c) What advise you will give to the mother at the time of discharge about the long-term plan
of managing this child? [3]
8. a) The pathogenesis of Acute Rheumatic Fever. [2]
b) The Criteria used for the diagnosis of Rheumatic Fever. [3]
c) How will you treat a 13-year-old School going girl Lakshmi, who presented with Acute
Rheumatic fever? [3]
d) How will you prevent the recurrence of this conditon? [2]
9. Mrs. Rubina G3P2L1IUD presented at 24 weeks of gestational age for follow up. Her
Glucose tolerance test results were as follows: 106, 194 and 176mg% at fasting, 1 hour and 2
hours respectively. She gives history of having gestational diabetes toward the later part in
previous pregnancy and was on medical nutrition therapy:
a) What is a high risk pregnancy? [2]
b) What other relevant history and risk factors you will explore? [3]
c) How will you follow up and manage this lady? [5]
10. A 5-year-old child was brought by his mother with cough, and mild fever for past 2
weeks. His weight is 13 kg (Birth wt-2.9kg). His father was treated for pulmonary TB 3
months back:
a) Discuss diagnosis of TB in this child. [2]
b) Discuss the treatment of pediatric TB as per National TB elimination program. [4]
c) What measures could have prevented the child from being infected by his father? [2]
d) What advice will you give to the anganwadi that the child is attendng? [2]
2023 April Paper 3
1. A lady who underwent Caesarean section recently comes to you with her husband for
temporary contraception advice.
a) List all the temporary methods of contraception that this couple can use. [3]
b) Discuss the advantages and disadvantages. [3+2]
c) What is your advice for the couple? [2]

[Page 36]
2023 April Paper 3
36
2. Mr. B, an HIV positive patient, with supressed viral load gets married. The wife knows his
condition and the couple is practising safe sex. Mr. B gives a frantic call saying that the
condom ruptured during intercourse.
a) What advice will you provide to the couple? [5]
b) After 2 years of marriage, they decide to conceive a child. What advice and precautions
will you give? [5]
3. A 54-year-old post menopausal lady comes with history of white discharge per vagina
(WDPV).
a) What is the differential diagnosis? [4]
b) What investigations will help you to decide the cause of WDPV? [3]
c) How can this be managed in a community health centre? [2]
d) What are the indications for referral? [1]
4. A 24-year-old primi gravida comes to you for antenatal check up in the 3rd month.
a) What tests will you do? [2]
b) What advice will you provide for good pregnancy outcome? [3]
At 30th week, she presented with pedal odema and her BP is 140/90 mmHg.
c) What is your likely diagnosis? [1]
d) What investigations will you order? [2]
e) What are the danger signs that you will elicit to refer the patient to an obstetrician? [2]
5. A 60-year-old lady comes with a mass that protrudes from the vagina when she voids. She
is also upset that she sometimes "leaks urine".
a) What is the likely diagnosis? [1]
b) Discuss the clinical examinaion to assess her. [2]
c) How will you manage her in the family practice setting? [4]
d) When will you refer the patient for surgery and how will you prepare the patient for
surgery? [3]
6. A 7-year-old child has been advised to undergo dental extraction. The patient has
Tetralogy of Fallot. What advice will you give the parents and the dentist? [10]
7. A 4-year-old-girl is brought to you by her parents as she has been crying continuously and
rubbing her left ear.
a) What are the likely causes? [2]

[Page 37]
2023 October Paper 3
37
b) What physical signs will be seen in different conditions and how will you manage each
one of them? [4+4]
8. An 8-year-old girl comes with history of passing high coloured urine and headache. 3
weeks ago she was treated for scabies.
a) What is the likely diagnosis? [2]
b) What laboratory tests will confirm the diagnosis? [3]
c) What treatment can be given to manage her in a communtiy health centre? [3]
d) When should the child be referred to a major centre? [2]
9. A 2nd standard student is brought by his mother to the hospital with fever and running
nose for the past 5 days. He has received all his immunisations from the local PHC. He has a
vescicular rash all over the body for the past 2 days which first started on his chest and
spread out .
a) What is the likely diagnosis? [2]
b) How will you manage this patient? [4]
c) How will you prevent the infection from spreading in the community as well as in the
family? [4]
10. A 3-year-old boy had high grade fever and developed generalised seizures. He recovered
rapidly and is otherwise well now.
a) What is the likely diagnosis? What are the clinical features of this condition? [3]
b) What treatment will you administer? [1]
c) What is the controversy in the treatment of this condition? [1]
d) What advice will you provide the parents for prevention of this conditon? [3]
e) The parents are worried about the future of the child. What advice will you give its
prognosis? [2]
2023 October Paper 3
1. A 35-year-old female high school teacher, who is overweight, consults you at 12 weeks of
gestation. Her both parents are diabetic:
a) How will you proceed? [2]
b) What all investigations you will advise throughout her ANC? [3]
c) What are the recommended minimum number of visits for low-risk pregnancy and at
what gestation age? [2]

[Page 38]
2023 October Paper 3
38
d) What all conditions will lead to high-risk pregnancy? [3]
2. Mrs Sabina has brought her 5-month-old baby with complaints of mild nasal discharge,
otherwise baby is well. So far baby has been on only breast feed. She asks you about
initiation of solid food:
a) What is weaning? [2]
b) Why and when should you wean the babies? [3]
c) How and what type of foods will you advise? [3]
d) How much complementary feeds should be weaning foods to contribute along with
breast milk up to 24 months of age? [2]
3. A 52-year-old female has not had periods for past 24 months. She comes to you with hot
flushes and vaginal dryness:
a) What is menopause and perimenopause? [2]
b) What are the various clinical problems a lady goes through during menopause? [2]
c) Write about the management of at least 4 clinical problems during menopause. [3]
d) What are the benefits and harms of Hormone Replacement Therapy? [3]
4. A 11-month-old male baby has been brought with complaints of upper respiratory
infection. His weight now is 6.3Kg. His Birth weight was 3.3Kg.
a) What is the grade of PEM as per IAP? [2]
b) What are the common social factors that might have contributed? [3]
c) What are the indications of admission for a patient with PEM? [2]
d) What food regime in the initial phase would you advise and how will be the increase in
calorie and protein intake? [3]
5. A 22-year-old primigravida at 35+3 weeks of GA presented with PPROM, delivered a 2.2 kg
baby boy.
a) What are the factors which increase the risk of low birth weight? [2]
b) How do you grade and classify low birth weight babies? [2]
c) What are the complications of low birth weight and how do you manage those
complications? [2]
d) How do you manage low birth weight babies? [2]
e) How do you prevent the occurance of low birth weight in babies? [2]
6. A 32-year-old female, P2L2 sterilized, has presented to you with history of heavy
menstrual bleed (HMBL) for past 5 days. Her earlier periods were regular and lasted for 3

[Page 39]
2023 October Paper 3
39
days. She had similar episode in last cycle, but since she noticed relatively excess bleeding
this month, she came to consult you.
a) What is Abnormal Uterine Bleeding (AUB)? [2]
b) What is the etiology of AUB according to FIGO Classification? [3]
c) How will you manage AUB in adolescents, perimenopausal, nonpregnant reproductive age
group, and in post-menopausal women? [5]
7. A 28-year-old female presented to you with complaints of vaginal white discharge. Its
curdy, yellowish and foul smelling:
a) What are the causes of white discharge per vaginum? [2]
b) What are the various types of discharge you see on vaginal examination? [3]
c) How will you manage this patient? [2]
d) Write briefly on the management of sexually transmitted infections. [3]
8. A five-day-old neonate is brought to you with history of poor feeding and yellowish
discolouration of skin over the past two days.
a) Describe the differential diagnoses and the pathophysiology of neonatal jaundice. [3]
b) Describe the risk factors for neonatal hyperbilirubinemia. [2]
c) How would you assess the severity of neonatal hyperbilirubinemia? [2]
d) Describe the indications and treatment options for neonatal jaundice. [3]
9. A 28-year-old female G3P2L2 delivered a baby boy weighing 3.5 kg. Her earlier both
babies were 3.7 and 3.8 kg. She was augmented with Pitocin for 8 hours, placenta was
delivered completely. She was given Inj Pitocin 10 units IM at the delivery of anterior
shoulder. After 15 minutes of delivery, she started having increased PV bleeding.
a) What is postpartum haemorrhage and how do you classify? [3]
b) What are the risk factors of PPH? [2]
c) How much bleeding is excessive bleeding? [2]
d) How will you manage her? [3]
10. A 43-year-old lady presented with complaints of post coital bleeding and intermenstrual
bleeding since last 4 weeks:
a) What is the aetiology/risk factors, clinical features of carcinoma cervix? [4]
b) Which are the methods of screening for cervical cancer? [3]
c) How do you diagnose and manage cervical intraepithelial neoplasia? [3]

[Page 40]
2024 May Paper 3
40
2024 May Paper 3
1. A 32-year-old pregnant lady PRIMI gravida at 37+2 weeks of gestation presents to you
with headache and pedal edema. On examination her BP is 160/90mm on two recordings.
She has puffy face and her urine albumin is 2+.
a) What is your diagnosis? [1]
b) How do you evaluate and manage her pregnancy and delivery? [6]
c) What are the maternal and fetal complications you anticipate? [3]
2. A 21-year-old primigravida at 40+5 weeks of gestational age, with no risk factors, had
regular antenatal checkup in your primary health centre. She is admitted and induced with
misoprostol and was augmented with pitocin this morning.
a) Draw a partogram with the following findings and Discuss the uses of Partogram in
monitoring the labour in a Primary Health Centre. [6]
At 6am: The cervix is 4cm dilated and < 0.5cm thickness, soft, station is "-3", artificial rupture
of membranes was done, liquor was clear, she has mild tightening. The FHR and mother's
vitals are stable, over a period of next 4 hrs pitocin drip was increased to reach contraction
of 3/10 each lasting for 40-45 seconds, throughout the FHR and liquor was normal.
At 10 am :
Cervix is 6cm
Liquor is clear
FHR is in normal range
Contraction 3/10 each lasting for 40 seconds
b) When will you repeat the next Per-vaginal examination and What action would you take if
cervical dilatation is 7cm and all other parameters are within normal range? [1+3]
3. Two year child, weighing 7 kg, is brought to you with history of loose stools, fever and
vomiting of two days duration. There was no blood in stools. On examination, the child is
irritable and demanding for water. The eyes are sunken. The child is actively drinking when
provided with water.
a) What is your diagnosis? [1]
b) How will you assess the dehydration level in this child? [2]
c) How will you manage this diarrhoeal episode? [4]
d) What is the nutritional management in this child? [3]
4. a) Describe the developmental milestones to be attained by a 3 year old child. [4]

[Page 41]
2024 May Paper 3
41
b) What are the common causes of delay in developmental milestones of a 3-year-old child,
who had reached all his milestones till 18 months of age. [3]
c) What are the clinical features of a child with autism? [3]
5. What are the components of breast milk for a mother of a term baby? Describe the
advantages of breast feeding upto the two years of age? Write about baby friendly hospital
initiative. [3+4+3]
6. A 21-year-old primigravida of 11 week gestation presented to you with history of spotting
per vaginum. On examination vitals are stable and cervical os is closed with mild spotting.
a) Define Abortion. [1]
b) How do you classify abortion? [2]
c) What kind of abortion is described in the above patient and how will you manage her? [3]
d) Write briefly on medical termination of pregnancy Act. [4]
7. a) What is pre-conceptional counselling? [2]
b) What are the goals of preconceptional counselling? [2]
c) What are the benefits of preconceptional counselling? [3]
d) How do you implement it in your practice? [3]
8. What are the hormonal contraceptives available? Describe the mechanisms of action and
their side effect profile. Write a brief note on emergency contraception. [4+3+3]
9. a) Mention five common causes of infant death under five years of age in India. [3]
b) Which guideline was issued by the Indian government to decrease morbidity and
mortality in under five's [2]
c) Classify and manage a child with diarrhoea according to the guidelines. [5]
10. You are running an immunization clinic in your primary health centre. The mothers are
very reluctant to come forward for immunization as they are afraid of the Adverse Event
Following Immunization.
a) What is the basic concept of Adverse Event Following Immunisation (AEFI)? [2]
b) How do you classify AEFI? [2]
c) How will you manage AEFI? [2]
d) As a team leader how will you investigate an AEFI? [4]

[Page 42]
2024 October Paper 3
42
2024 October Paper 3
1. A recently married young lady has missed her periods. Her pregnancy is confirmed with
urine pregnancy test. She is 8 weeks pregnant and has come to see you with complaints of
incessant vomiting. She is dehydrated.
a) What are the differential diagnosis for the vomiting. [2]
b) How will you manage excessive vomiting in the first trimester of pregnancy? [4]
c) What are the conditions that need to be ruled out in this patient with excessive vomiting
in the first trimester of pregnancy? [2]
d) What are the indications for admission and referral? [2]
2. A 25-year-old lady, married for one year, has come to see you after she missed her regular
periods; Her pregnancy was confirmed with urine pregnancy test and she was prescribed
folic acid. Today, she reports two months amenorrhea and having bleeding PV since one
hour ago.
a) What are the causes of bleeding PV in the first trimester of pregnancy? [4]
b) Draw an algorithm for management of bleeding PV in the first trimester of pregnancy. [6]
3. A 25-year-old PRIMI at 40+4 weeks of GA is admitted for safe confinement. She is in the
second stage of labour and she looks exhausted. You would like to cut short second stage of
labour.
a) What are the indications for cutting short of second stage of labour? [3]
b) What are the instruments used to cut short the second stage of labour? [4]
c) What are the complications anticipated and how will you manage them? [3]
4. A 30-year-old pregnant lady G5P4L4 at 32 weeks of pregnancy has come for routine
antenatal visit to the community health center. Her hemoglobin is 8 gm%,
a) List the factors contributing to the anemia in pregnancy. [2]
b) How will you manage anemia in this pregnancy? [4]
c) What are the precautions need to be taken during the delivery and puerperium? [4]
5. A young couple married for 4 years and living together and anxious to conceive. They have
come to the family physician for the infertility evaluation.
a) Define primary infertility. [2]
b) How will you evaluate a couple for infertility in primary care? [4]
c) What are the simple treatment measures that can be tried in the family practice before
we refer to the specialist? [4]
6. You are taking care of new born babies in a community health center.

[Page 43]
2025 June Paper 3
43
a) Describe briefly the components of "Essential neonatal care" recommended by World
Health Organization? How will you implement "Essential neonatal care" in your community
health center? [5]
b) How will you provide feeding for the newborn in special situations like twin gestation and
pre-term infant? [5]
7. A 5-year-old child is brought to you with complaints of cold, cough and fever since 3 days.
Child has poor feeding and lethargy. On examination, the Respiratory rate was 38 per
minute.
a) How will you assess a child according to IMNCI for pneumonia? [5]
b) How will you manage this child? [5]
8. A 3-year-old boy, weighing 12 kg, is brought to the OPD with complaints of recurrent loose
stools since morning. Child is thirsty and demanding water. Eyes look sunken and skin turgor
is lost.
a) How will you assess for dehydration in this child? [5]
b) According to IMNCI how will you manage the child? [5]
9. A 15-year-old boy is brought to you by his mother complaining of poor scholastic
performance.
a) What are the problems of adolescence? [5]
b) Role of family physician in improving adolescent health in the community. [5]
10. Eleven year old child staying in a hostel is brought by the warden complaining of
behavioral changes with poor scholastic performance which is of recent onset. On exploring
further you suspect child sexual abuse.
a) What is POCSO Act? [5]
b) What is the role of family physician in this scenario of suspected child sex abuse? [5]
2025 June Paper 3
1. A 2-year-old boy was brought by his mother with complaints of fever, headache associated
with vomiting for past 2 days. He is drowsy since this morning. On examination, he is febrile
(103°F), conscious, lethargic and there was neck stiffness. There was no weakness in the
extremities.
a) What are your diagnosis and differential diagnoses? [2]
b) What are the common organisms which cause the above condition? How will you manage
this child in family practice? [5]

[Page 44]
2025 June Paper 3
44
c) What are the complications during the treatment that would need referral to the higher
center? [3]
2. a) What are the temporary methods of contraception available for a 23-year-old lady who
had delivered the first child two weeks ago? How will you counsel the woman with different
methods of
contraception? [5]
b) Relevance of Medical Termination of Pregnancy Act for the Family Physicians. [5]
3. A newborn baby of a diabetic mother was being observed in the nursery. The nurse
noticed lip-smacking movements in the baby and informed you.
a) What are the common causes and classification of neonatal seizures? [5]
b) How will you evaluate and manage neonatal seizures? [5]
4. A 23-year-old G3P1L1 SB1 at 36 weeks of gestational age with previous spontaneous
preterm birth at 34 weeks with previous small for gestational age has come for ANC follow-
up.
a) What are the risk factors for preterm birth? [3]
b) Which are the factors classify a pregnancy as a high-risk pregnancy? [3]
c) What are the routine investigations and recommended visits included in antenatal care in
a low-risk and high-risk pregnancy? [4]
5. An 8-year-old child was brought with complaints of periorbital swelling noticed by the
mother in the early mornings for past one week. The urine routine showed Albumin 4+ and
no WBC or RBC.
a) How will you evaluate this child? [3]
b) How will you diagnose and manage Nephrotic syndrome? [5]
c) What are the indications for referral to the specialist? [2]
6. A 23-year-old primigravida at 24 weeks of gestation has come for antenatal care. You find
her to be pale, and her Hb is 7.5 gm%; she is not able to tolerate oral iron supplements:
a) How will you administer parenteral iron therapy–dose, dilution, duration and frequency?
[3]
b) What are the complications of anemia in pregnancy and in labor? [3]
c) How will you manage the labor in a woman with anemia complicating pregnancy? [4]
7. A 26-year-old G3P1L1A1 at 29+3 weeks of gestational age with a history of pre-eclampsia
in previous pregnancy, is currently on Tab Labetalol 100 mg once daily presented with
bleeding PV and
leaking. Abdomen exam shows tense and tender uterus.

[Page 45]
2025 June Paper 3
45
a) What are the causes of bleeding PV after 20 weeks of gestational age? [3]
b) What are the differential diagnosis for the patient in the above case scenario? [3]
c) What are the investigation and management needed for this patient? [4]
8. An 9-month-old boy was brought by his mother for fever, cough and lethargy for two days,
Baby’s present weight is 6 kg. His birth weight was 3 kg. On examination, the child is febrile
(100°F), lethargic, respiratory rate is 54 per minute and heart rate is 130 per minute.
Auscultation reveals bilateral crackles in the chest.
a) How do you classify malnutrition according to classification by Indian Association of
Pediatrics? [2]
b) What are the possible causes for malnutrition below one year of age? [2]
c) Write in detail the immediate management, rehabilitation plan including diet and
supplements and follow-up for this child. [6]
9. A 22-year-old lady underwent emergency caesarean section for fetal distress with thick
meconium stained liquor. You are called for neonatal resuscitation.
a) What neonatal resuscitation supplies and equipment will you be ready with? [2]
b) The nurse is informing you that the baby is not establishing spontaneous breathing and
heart rate is 80 beats per minute. How will you proceed with resuscitating this new-born?
[4]
c) Even after bag and mask ventilation for one minute, the heart rate is 60 per minute. What
corrective steps will you do? [4]
10. A 6-year-old child is getting recurrent cough and wheeze for past two years. The
symptoms are frequent during winters, almost one episode every month interfering with his
scholastic performance. Since past two days, child is getting nocturnal cough associated with
breathlessness. Since today morning, he is having dyspnea at rest. Examination reveal that
he is anxious, respiratory rate is 28 per minute, able to speak sentences. He is afebrile, SpO2
is 94% and chest indrawing is present. Auscultation reveals bilateral polyphonic wheeze.
a) What are the possible differential diagnoses? [2]
b) How will you manage this episode? [5]
c) How will you prevent similar episodes happening in the future? [3]

[Page 46]
2022 June Paper 4
46
Paper 4 (FaM and Community medicine)
2022 June Paper 4
1. What is meant by health and well-being? What all are essential for healthy living? How
will you measure the quality of life? What are the social determinants of health? [2+2+2+4]
2. You have diagnosed 15 cases of Dengue fever infection in your area. How will you
investigate and control this epidemic? [5+5]
3. A 50 year old man presented to you with a non-healing ulcer on his right foot. How will
you assess him according to three stage assessment model? [10]
4. What is disaster cycle? How will you prepare the people in your CHC area for an
anticipated flood? What is disaster mitigation? [2+6+2]
5. What is the difference between 'referral of a patient' to a specialist and 'consultation by a
specialist' when you send your patients for a second opinion? What are the legal implication
for family practitioner when he sends a patient for consultation or referral? Discuss the
referral system available in the public health institutions in our country. [3+2+5]
6. Discuss the various types of pneumococal vaccines that are available for immunisation in
our country. Discuss the indications for this vaccine in adults. What is the schedule of the
vaccination in children? [4+3+3]
7. What are the aims and objectives of Revised National TB Control Programme of India
(elimination program 2020)? How does this programme help to achieve elimination of TB
from India? With regard to HIV infection, what are the recommendations by the program?
[3+5+2]
8. Define urban health. What are the major health issues seen in urban areas of India? How
does National Urban Health Mission of India address these issues? [1+4+5]
9. Discuss briefly regarding problems of adolescence. What are the government schemes for
adolescents? [6+4]
10. A 48 year old man came to see you to get advice regarding a trip to USA for 3 months. He
is diabetic on insulin and OHA, and is having bronchial asthma controlled with inhalers. He is
under your follow up. What immunisation will you advice? What medical documents will
you provide for the patient? He wants to carry his medications for the trip. What advice will
you provide? [3+3+4]
2022 December Paper 4
1. There has been a cholera outbreak in the locality where you practice. You have been
asked by the local administration to investigate this. How will you proceed to ascertain the

[Page 47]
2022 December Paper 4
47
existing situation of outbreak? Briefly describe the study design, objective, methodology and
associated factors. [4+6]
2. A family practitioner wants to establish a relationship between arreca nut chewing and
oral cancer:
a) What tests of association must he apply to identify the association? [5]
b) How will confidence interval help to interpret the results? [5]
3. Infant mortality rate:
a) Define infant mortality rate. [2]
b) What are the determinants of infant mortality in India? [3]
c) How will you prevent infant mortality in your community? [5]
4. a) Discuss the criteria for screening. [5]
b) Describe the different methods of screening for cervical cancer. [5]
5. Discuss the importance of:
a) Air pollution on health of the individual. [5]
b) Biomedical waste seggregation in family practice. [5]
6. Discuss the principles of Family medicine. Write briefly on three stage assessment. [6+4]
7. a) The beneficiaries and benefits of Ayushman Bharat yojana. [5]
b) Discuss Janani suraksha yogana (JSY) of the Government. [5]
8. The cesarean section rate in your hospital is 25%:
a) How will you conduct an audit of the caserean sections being conduced in your hospital?
[4]
b) What are the principles of evidence based medicine that will help you to identify good
practices? [4]
c) How will you remedy the situation in your hospital? [2]
9. a) Various methods of temporary contraception. [5]
b) Emergency contraception. [5]
10. a) Adult vaccination. [5]
b) Steps in de-adiciton of alcohol. [5]

[Page 48]
2023 April Paper 4
48
2023 April Paper 4
1. Discuss herd immunity and its place in the control of the Covid-19 pandemic. [10]
2. A famliy of four members went to a restaurant for dinner. 2 hours later, two of them
developed vomiting and by 4 hours all of the members developed vomiting and had loose
stools.
a) What is the likely diagnosis? [1]
b) How will you manage the family? [4]
c) What is the role of the physician in informing the health authorities? [1]
One of them had not passed any urine for the last 10 hours.
d) How will you manage? [3]
e) How could this complication be prevented? [1]
3. Discuss the advantages and disadvantages of telemedicine in family practice? [5+5]
4. As a part of family practice, a drug company wants to conduct a drug trial in your practice.
a) What ethical issues have to be followed? [6]
b) What are the various permissions that an individual doctor has to obtain before
conducting the research? [2]
c) Who will be ultimately responsible for adverse reactions financially, legally and ethically?
[2]
5. a) What is Ayushman Bharat? [1]
b) What are the advantages of Ayushman Bharat? [4]
c) What are the disadvantages of Ayushman Bharat? [2]
d) How can family medicine practioners be a part of this program? [3]
6. In a community survey, it is found that 41% of pre-school children are suffering from
anaemia.
a) What community measures can be undertaken to reduce the prevelance of anemia? [6]
b) What individual measures can be taken to reduce the incidence of anaemia? [4]
7. Describe various statistical parameters used to assess the usefulness of a laboratory
investigation. As a Family practitioner, how do these measures help you to choose a test for
a particular condition? [5+5]
8. A 45-year-old man comes to you with a depigmented patch on the back. You examine and
find that the patch is anaesthetic.
a) What is your likely diagnosis? [2]

[Page 49]
2023 October Paper 4
49
b) What investigation will you do? [2]
c) What treatment will you advise as recommended in the national program? [4]
d) What will you do for the family? [2]
9. Discuss the problems faced by the elderly in the community. What measures can be taken
to mitigate their conditon? [5+5]
10. Discuss the precautions in administering Covid-19 vaccines and possible side effects.
[5+5]
2023 October Paper 4
1. Mrs. Geetha presented to your OPD with two days’ history of cold, cough and throat pain.
OPD sister recorded a BP of 160/110mmHg which she was unaware earlier. Re-examination
by you also confirmed that she has hypertension.
a) What is screening? Write the difference between screening and diagnostic tests. [2]
b) What are the aims of screening? [2]
c) What are the types of screening - write briefly about each? [2+2]
d) What is the role of Family Physician in disease prevention? [2]
2. A 43-year-old presented with a hypopigmented patch over the face which she noticed for
past 6 weeks. She also says she has mild decreased sensation over the area:
a) How will you evaluate her? [2]
b) How do you classify Hansen’s disease? [2]
c) What treatment regimens are recommended? [3]
d) Write briefly on Fernandez and Mitsuda reaction. [3]
3. A 34-year-old, mother of two children came to your OPD for generalised aches and pains,
her weight is 96 Kg, and height is 154 cm.
a) What will be her BMI? [1]
b) How will you classify obesity as per WHO classification? [2]
c) Write briefly on Epidemiology and etiopathogenesis of obesity. [3]
d) What are the hazards of obesity? [2]
e) How can you prevent obesity in the community - what level of prevention will it be? [2]
4. You have been posted in a rural community health centre. You have noted that there were
32% of low-birth-weight infants among newborn children during the first quarter of 2021.
You plan to determine the risk factors of low birth weight.

[Page 50]
2023 October Paper 4
50
a) What is the type of study design you would need to use if it has to be completed within a
year of your posting and mention reasons? [3]
b) State the objective of the study. [2]
c) Mention the methodology of the study. [3]
d) How will you analyse the data? [2]
5. Ms.Shivani, an engineering student, comes to you with history of unprotected sex the
previous day:
a) What are the various methods of temporary contraception? [3]
b) What are the contraindications of oral contraceptive pills? [2]
c) Write briefly about Emergency Contraception. [3]
d) What are the other conditions for which we use OCP? [2]
6. You have been serving a certain geographical area, 10% of your daily OPD are diabetics,
you want to evaluate how your care is for the diabetics:
a) Describe an audit cycle and its components. [5]
b) If you were to do an audit of diabetic control of the patients in your practice, what would
you do? [5]
7. There has been an outbreak of diarrheal disease in a village near the PHC that you work:
a) Discuss how you will investigate this outbreak. [5]
b) Describe briefly on management of acute diarrhoea according to the IMNCI guidelines. [5]
8. A 28-year-old man has presented to your health centre with fever and body pain for past
four days. There was no obvious focus of infection. Clinical examination reveals an
erythematous rash over the chest, trunk and extremities. Pulse rate of 120 / minute. Blood
pressure was 78/60 mmHg in right upper limb. There are patients with similar presentation
for the past two weeks. His investigations revealed leukopenia and thrombocytopenia; WBC
count of 2800/cumm and platelet count of 63,000/cumm.
a) What are the possible differential diagnosis? How will you manage him? [5]
You heard that there are similar fever patients in the locality from the community workers.
b) How will you investigate and control this epidemic? [5]
9. A 28-year-old was found to be HIV positive during her ANC:
a) Discuss vertical transmission of HIV infection. [3]
b) What are the various modalities for prevention of vertical transmission of HIV under
National AIDS Control Programme? [3]
c) Discuss the post exposure prophylaxis in HIV. [4]

[Page 51]
2024 May Paper 4
51
10. A 35-year-old, a daily wage labourer presented with weight loss, cough and
expectoration for past 3 weeks, with evening rise of fever:
a) What are the objectives of Revised National Tuberculosis Control Programme? [2]
b) How is the diagnosis, categorization of Tuberculosis done under RNTCP? [2+2]
c) Write about the treatment regimens of Tuberculosis according to RNTCP? [4]
2024 May Paper 4
1. a) Define health. [2]
b) What are the different levels of prevention that can be provided by Family Physicians? [4]
c) Explain each level with an example. [4]
2. You have diagnosed 17 cases of malaria in a village of population of 1000 in the last one
month. There was only one or two cases diagnosed in the previous months.
a) Which are the vectors that transmit Dengue fever, Malarial fever and Chikungunya? [2]
b) How will you investigate this outbreak? [4]
c) How will you apply integrated vector control measures in the village? [4]
3. A 17-year-old boy in class 12 has been having headache for past 2 months almost every
day which is progressively worsening. He has anorexia and lost weight from 52 to 45 kilos in
one month. He is also reporting evening rise of temperature on and off for the past one
month. His parents are professionals working abroad and he is studying in a hostel. His elder
sister is studying in IIT Mumbai. He does not have any bad habits. He has depressed mood
on and off. He says the life is not worth living anymore. His grand father had been treated for
Pulmonary Tuberculosis when this boy was 5 years old.
a) What are the various types of consultation models? [2]
b) Explain the "Three Stage Assessment Model of Consultation". [3]
c) Write the "Three stage assessment" of this boy and suggest a management plan for each
problem. [5]
4. a) What are the various stages of disaster management cycle? [5]
b) You are working as the Family Physician in a Primary Health Centre in a rural part of India.
You are receiving an alert about a possibility of earthquake in your area in the next one hour.
How will you prepare the villagers for an anticipated earthquake? [3]
c) How will you mitigate the disaster caused by earthquake? [2]
5. a) What are the types of referrals. [3]
b) Describe an ideal referral pathway in any health care system. [3]

[Page 52]
2024 October Paper 4
52
c) What are the components of a "Referral Letter" written by a Family Physician while
referring the patient to the Specialist? [4]
6. Write about adult vaccination schedule and list of adverse reactions you would warn the
patients. [6+4]
7. a) Mention the objectives of the recent National Tuberculosis Programme. [2]
b) Write briefly about the following as per the National Tuberculosis Programme:
i) Diagnosis of Tuberculosis. [2]
ii) Categorization. [3] iii) Treatment of Tuberculosis. [3]
8. Describe the current delivery of primary healthcare in India. What are the challenges for
the current system of primary healthcare in India? Give your suggestions to improve primary
healthcare in India. [3+4+3]
9. a) What are the health problems of adolescent girls in India? [4]
b) Briefly describe the government schemes for adolescent girls in India. [3]
c) What are the interventions a family physician would do to improve the health of
adolescent girls during the School Health visits? [3]
10. You conduct a school health screen for 10th graders and identify 30% of the students are
overweight:
a) What are the causes for more students being overweight in the past decade? [3]
b) What are the future health risks for children with overweight and obesity? [3]
c) What is your role in health promotion and prevention as family practitioner for this group
of students? [4]
2024 October Paper 4
1. A 45-year-old man comes to see you for follow up his lymph node biopsy report. The
biopsy is reported as Non-Hodgkin's lymphoma. Describe in detail the steps in breaking the
bad news? [10]
2. A 40-year-old man, chronic smoker comes to see you seeking help to quit smoking. How
will you help him in Smoking Cessation? [10]
3. A 12-year-old boy is brought by his mother with complaints of poor scholastic
performance and behavioral problems.
a) What are the causes of poor scholastic performance? [4]
b) How will you evaluate this boy? [3]

[Page 53]
2025 June Paper 4
53
c) What are the interventions that could help him to improve the scholastic performance?
[3]
4. Discuss "Adult Immunization" for a 50-year-old businessman who travels abroad
frequently. [10]
5. A couple is planning to retire at 60 years of age. They have come to the family physician
for a health check-up and seeking the advice on retirement planning.
a) What are the common health problems which you anticipate at retirement age? [5]
b) What are the health promotion recommended by the family physician for during
retirement. [5]
6. a) Describe briefly about observational studies. [5]
b) How do you calculate sample size in observational studies? [5]
7. a) What are the "red flags" and "yellow flags" in family practice? [5]
b) How are they going to help you in patient management in the family practice? [5]
8. Describe in detail the steps of "Calgary Cambridge Consultation Skills". How will you apply
these steps in Indian context with large number of patients coming to our outpatient clinic?
[6+4]
9. You had unusually large number of patients in your clinic on a Saturday. There was delay in
finishing the clinic as you had few sick patients as well. Meantime, you noticed that one of
the patient got angry and fighting with nurses because of the delay. Describe the steps to
address the "angry patient" in family practice? [10]
10. You are working as a medical officer in the community health center. You noticed
increase in the number of patients with diarrheal illness in your area in the past one week.
Few of the patients were admitted with hypotension and shock. There is no death reported
so far. How will you manage this outbreak of diarrhea in your community? [10]
2025 June Paper 4
1. Mrs. I is a 35-year-old house-wife and mother of four girl children. She has come to your
family practice for aches and pains. She has mild anemia and depression. For the past two
years, she is going to mason work as her husband is not supporting the family. Her husband
is going to laborer work but spends all the money in alcohol consumption. He consumes
alcohol daily and he beat Mrs. I causing physical injuries. Her first child is 14 years old and a
school drop out. First child is helping the mother in the household works and taking care of
the other siblings. 11 year old and 7 year old children are going to school. Last child is 5 year
old and still not started schooling. All the four children are malnourished, anemic and the
elder daughter is depressed.
a) Draw a family genogram. [2]

[Page 54]
2025 June Paper 4
54
b) How will you assess the "functional status of the family" using family APGAR? [4]
c) How will you provide family therapy for this family? [4]
2. A 30-year-old Mr. A, is working as an IT professional and he is coming to you for health
check-up. You find that he is smoking 10 cigarettes per day for the past 5 years.
a) What are the stages of behavior change? [5]
b) How will you help Mr. A to stop smoking by non-pharmacological and pharmacological
methods? [5]
3. You are working as a medical officer in a community health centre. There are two
secondary schools in your community. You have been requested to provide school health
service from 6th standard to 11th standard children.
a) What are the health problems of school children from 10 years to 16 years of age? [4]
b) How will you implement "school health service" from 6th standard to 11th standard
children. Describe briefly the components, implementation and evaluation of this program?
[6]
4. You are having many patients with hypertension taking treatment in your family practice.
Only 50% of them are controlled with medications. Rest of them are uncontrolled even after
taking regular medications. You want to study whether drug A or drug B is effective for
hypertension in your population.
a) What are the factors affecting the control of hypertension in an adult with primary
hypertension? [4]
b) How will you plan and execute a Randomized Controlled Clinical Trial (RCT) in your
population? [4]
c) What are the factors that affect the quality of an RCT? [2]
5. a) What are the components, uses and sources of health information systems? [3+2+3]
b) What is the difference between data and information? [2]
6. A 55-year-old post-menopausal woman, married for 28 years with two children, has come
to you for management of uncontrolled diabetes. Her height is 152 cm, and her weight is 88
kg. She is a housewife with sedentary lifestyle.
a) How will you classify obesity and what class she fits in? [2]
b) What is the daily calories and proteins requirement to maintain her health? [2]
c) Write a diet sheet for the patient mentioned above to control her diabetes as well as for
weight loss. [3]
d) What health promotions and preventions you suggest for her as her personal physician?
[3]

[Page 55]
2025 June Paper 4
55
7. a) Write briefly about cold chain equipment used for the universal immunization program.
[3]
b) How do you store vaccines at district and subdistrict levels? [3]
c) Write briefly about vaccine vial monitors. [2]
d) Write about appropriate storage and use of diluents used for vaccines. [2]
8. a) Mention any two commonly used scales to assess the socioeconomic status of
patients/study participants in health care. [2]
b) Describe briefly any one scale to assess the socioeconomic status. [3]
c) What are the are the ways a family physician could use the socio-economic assessment to
provide cost-effective health care? [5]
9. a) What are the various occupational health hazards for healthcare workers? [5]
b) How can you safeguard the health, safety, and well-being of healthcare workers? [5]
10. You have been appointed as a medical officer in-charge of a community health centre in
a district with high incidence of malaria (both P. Vivax and P. Falciparum).
a) How will you treat an adult with fever and blood smear positive for malaria? [5]
b) How will you implement "malaria control" in the community served by your health center
according to the national framework for malaria elimination in India? [5]`},{id:`src-topicwise-2011-2022`,title:`DNB Family Medicine — topic-wise previous questions 2011 to 2022`,fileName:`DNB_FM_PYQ_topicwise_2011-2022.docx`,originalPath:`source/DNB_FM_PYQ_topicwise_2011-2022.docx`,note:`Compiled by Dr Vishnu B S, Family Medicine Specialist, Trivandrum. Questions grouped by subject and topic.`,text:`







DNB FAMILY MEDICINE

PREVIOUS YEAR TOPICWISE QUESTIONS

Compiled by Dr.VISHNU B S

Family Medicine Specialist

Trivandrum

















2011 -

2022







INDEX



Sl No

Subject

Page Number

1

Medicine

3 - 42



A.Cardiology

4



B.Hematology

8



C.Pulmonology

9



D.Endocrinology

13



E.GIT

16



H.Nephrology

20



I.Neurology

22



J.Rheumatology

26



K.Infections

28



L. Toxicology

32



M. Metabolic diseases

33



N. General Topics

35



O. Critical Care

39



P.Geriatrics

40







2

Dermatology

43

3

Psychiatry

47

4

Surgery

51

5

Orthopaedics

67

6

ENT

73

7

Ophthalmology

79

8

Anaesthesia

83

9

Obstetrics & Gynecology

87

10

Paediatrics

101

11

Family Medicine and Community Medicine

115





















MEDICINE



























Cardiology







High yield areas based on previous year questions

Myocardial infarction

Hypertension

Hypotension

Heart failure

Pulmonary embolism

Pulmonary Edema

Dilated Cardiomyopathy

Angina

Palpitation

Ventricular arrhythmias



Hypertension

June 2021

A 40-year-old man who came to your clinic for a health check up, was found to have a blood pressure of 210/120. He is not a known hypertensive.

Write briefly on the history and physical examination to assess the causes and complications of his hypertension. [3]

What investigations will you order? [2]

Outline the non-pharmacological and pharmacological management of hypertension. [5]

December 2019

A 30-year-old presents to the OPD and is incidentally detected to have a blood pressure of 170/110mmHg. What will be your diagnostic approach to this patient in terms of

history, examination and investigations? How will you treat such a patient?

June 2019

A 50-year-old patient comes to you with shortness of breath for the past 5 days. He is a diabetic and a hypertensive but has not been regular in his visits to the doctor. He has a history of smoking for the past 25 years and has been coughing on and off for the past 2 months.

What are the possible causes of his shortness of breath?

The clinical approach to this patient including history and physical examination.

Investigations to assess this patient with justification for each.

Describe the pharmacological management of each of the causes of symptoms you have listed.

June 2019

A 55-year-old lady who has been a diabetic for the past 8 years, complaints of burning and pricking sensation of her feet. Her standing systolic blood pressure is 30 mm Hg lower than when she is sitting.

What specific physical examination points will establish the likely diagnosis?

Discuss the mechanism of low standing blood pressure.

List other abnormalities she is likely to have in the light of the blood pressure abnormality.

June 2014

Define hypertension. Enumerate test factors, complications and principles of its

management.

June 2012

Write down the classifications of antihypertensive drugs.

Describe the clinical presentation, diagnosis and treatment of hypertensive encephalopathy.





Hypotension

April 2016

A 30 year housewife, mother of 2 kids gives a history of recurrent hospitalization (5 times in last 1 year) with severe diarrhea, vomiting & collapse. Each time she got better with intravenous fluids.

What relevant history would you ask for?

What clinical findings would you specially look for?

What investigations would you order?

What advise would you give to her family members?	2.5x4

Angina

June 2015

Define stable angina.

Prevention and management of stable angina.	1+(4+5)

December 2014

A 55 years old businessman comes to you with history of left sided chest pain which he gets on climbing stairs:

What clinical features of pain will indicate heart disease?

List the risk factors for heart disease that you will elicit in history .

What investigations will you advise? 2

How will you treat if cardiac ischemia is a possibility?

Myocardial infarction

December 2021

A 50-year-old male, smoker with type 2 diabetes for past 5 years, presented to the emergency department with sudden onset left sided chest pain for past 1 hour with associated autonomic symptoms. His pulse rate is 120 per minute and blood pressure is 190/110 mmHg. His oxygen saturation is 99%.

What is your diagnosis and how will you confirm the diagnosis? [3]

How will you manage this man today in the emergency department? [3]

What are the causes of chest pain and how will you clinically evaluate any patient with chest pain? [4]

December 2021

A 65-year-old man with type 2 diabetes mellitus with past history of acute myocardial infarction 5 years ago, presented to you with dyspnoea on exertion, fatigue, swelling legs and decreased urine output for 5 days duration. He is finding it difficult to sleep at night and wakes up due to breathing difficulty and gets relief after sitting up for sometime.

What is your probable diagnosis for the presenting symptoms? Explain the clinical features and pathophysiology? [4]

How will you manage this patient? [4]

What is the role of family physician in prevention of this condition? [2]

December 2019

A 50-year-old man who is a known diabetic and hypertensive presents with severe chest pain, breathlessness and diaphoresis while climbing a flight of stairs. What is your likely diagnosis? Write briefly how you would assess and manage this patient. As a family

physician, what steps can you take for primary prevention of this condition?

December 2018

A 45-year-old smoker develops central chest pain. An ECG shows the following possible traces. Give the diagnosis in each case and the initial management.

ST elevation in leads 1, AVL, V4, V5.

ST segment depression of 2 mV in leads III and AVF.

Normal ECG.

Symmetrical T wave inversions in Lead I, AVL and V4, V5,V6.

December 2011

Describe briefly the clinical features,diagnostic evaluation and management of a patient presenting with acute myocardial infarction.	3+3+4





Pulmonary Edema

December 2022

A 50 year old male known to have diabetes and hypertension for 15 years. He had history of acute coronary syndrome a year ago. Now comes to you with fatigue, decreased food intake and dyspnea on exertion. Clinically pedal edema, elevated JVP and on bilateral asculation of the lung bases, he had fine crepitations.

What clinical possibilities will you entertain? How do you proceed to evaluate this patient?

As a family physician, how will you manage this case? [2+4+4]

Palpitation

December 2016

Rani is a 50 year old lady who has been getting episodes of palpitation.

List the differential diagnosis for this symptom in her.

Write the relevant history and physical examination features you would elicit. List the investigations you would ask for with justification for each.

Medical management of Grave’s disease.

2+4+4

Heart failure

December 2017

Mrs. Meera, a 60-year-old woman, comes with complaints of bilateral, swelling of feet.

Mention two clinical signs you will look for that will suggest it is congestive cardiac failure.

List three essential groups of drugs, with an example that is used in management of congestive cardiac failure with reasons.

Two weeks later, she comes back with worsening of symptoms in spite of medical management. List probable causes of refractory cardiac failure.

December 2016

A 75 year old man with chronic heart failure recently worsens, despite compliance with medications.

List 5 possible reasons for this and how they can be corrected?

State the roles of spironolactone & beta blockers in heart failure management.	5+(2+3)

April 2016

A 65 year old ex-smoker has shortness of breath, pedal oedema and cough for last 1 year. Investigation reveals an EF of 37%, a creatinine of 2.7 mg %, and hyperinflated lungs, and an HbA1c of 8%.

How would you start his treatment?

What investigations would you do keeping in view of his future requirement possibilities?

What prophylactic measures must be taken?	4+4+2

Pulmonary embolism

December 2017

Mention the risk factors for pulmonary embolism (PE).

List the investigatory work-up for PE with reasons.

How will you treat PE?

Dilated Cardiomyopathy

April 2016

What are the common causes of dilated cardiomyopathy? Briefly outline management in an elderly patient with dilated cardiomyopathy.	5+5

Ventricular arrhythmias

December 2012

What are ventricular arrhythmias ?

How you going to diagnose ventricular premature complexes (VPCs) on ECG. Please state finding.

How do you differentiate it from atrial ectopic?

What is the treatment?









Thalassemia

April 2016

A young lady is recently diagnosed with moderate anaemia with detection of thalassemia trait in her HPLC. How would you proceed further with respect to the index patient and her family?

What advice would you give the patient with regard to her marriage & motherhood in future?6+4

Anemia

December 2019

A 75-year-old man presents to you with significant loss of weight over the past 2 months and he was found to be anaemic. Classify anemias. List the possible causes for his anaemia and how you would assess him for the cause and severity of anaemia.

June 2018

Rani is a 45 -year -old lady presents with tiredness and fatigue. She has not attained menopause. On examination , you find that she is pale.

What are the causes for anaemia you would consider in this patient?

What all specific points you would elicit in history and physical examination in this patient to get a clinical diagnosis?

What are the useful findings in h aemogram in iron deficiency anaemia and B12 deficiency?

How will you manage iron deficiency anaemia? 2 + 4 + 2 + 2

December 2015

Causes, clinical features, investigations and management of iron deficiency

anaemia.	2+2+3+3

December 2011

Describe briefly the causes, diagnosis and treatment of iron deficiency anemia 3+3+4







Pulmonology







High yield areas based on previous year questions

Bronchial Asthma

Bronchiectasis

Tuberculosis

Pneumothorax

Pleural Effusion

COPD

ARDS

Pulmonoary eosinophilia / Miliary shadows

Pneumonia











Bronchial Asthma

June 2021

A 30-year-old clerk in a warehouse presents to you with history of episodes of cough and shortness of breath for the past few months. He has no history of fever or loss of weight or appetite. On examination, his vitals are stable and systemic examination is unremarkable except for bilateral rhonchi in the chest. You suspect that he has asthma.

What is the pathophysiology of bronchial asthma? [2]

How will you confirm the diagnosis? [2]

How will you manage him? [2]

How will you explain the role of a preventor and a reliever in using Metered Dose Inhalers (MDIs) for this treatment? [2]

List the steps in the use of an MDI with a spacer. [2]

December 2019

A 25-year-old known asthmatic presents to your community health centre with severe breathing difficulty just after Diwali. Describe the evaluation and step wise management of this patient. As a family physician, how will you prevent recurrence

of such episodes in the future?

June 2012

Enumerate the differentiating features of bronchial asthma and cardiac asthma. Briefly describe the pathophysiology, diagnosis and treatment of

cardiac asthma.

Bronchiectasis

December 2020

A 55-year-old man presents with history of hemoptysis for the past few days.

Write briefly on the common causes of hemoptysis in family practice.

How will you assess this man with appropriate history,physical examination and investigations?

Diagnosis and management of bronchiectasis. 3+3+4

June 2020

A 55-year-old man presents with history of haemoptysis for the past few days.

Write briefly on the common causes of haemoptysis in family practice

How will you assess this man with appropriate history, physical examination and investigations?

Discuss briefly diagnosis and management of bronchiectasis 3+3+4





COPD

December 2020

You have a 45-year-old patient whose spirometry showed features of COPD.

Discuss how you will help him to quit smoking.

June 2020

You have a 45-year-old patient whose spirometry showed features of COPD:

What are the difference in obstructive and restrictive spirometry features?

How will you clinically approach to this patient including history and examination? c) How will you clinically manage this case? 2+4+4

December 2017

Mr. Raju is a 45-year-old male, who is a chronic smoker for the past 30 years. He has come with history of worsening breathlessness and frequent episodes of cough for the past six months.

What are the specific clinical features and investigatory findings for Chronic Obstructive Pulmonary Disease (COPD)?

What is the role of the family physician in all levels of prevention in COPD-Primordial, primary, secondary and tertiary?

Tuberculosis

June 2018

Sandeep is a 24 -year -old farmer whom you have diagnosed to have pulmonary TB. He is sputum positive for AFB and stays with his wife and 2 children aged 7 and 5 in a thatched house.

As his Family Physician, what would be your concerns and role as a Family Physician in the management of Sandeep?

b ) Outline the common side effects of anti -tuberculous drugs and how you would manage them

c ) What is the role of nutrition in the management and prevention of Tuberculosis? 4 + 3 + 3

JUNE

2017

Xpert MTB/RIF assay to diagnose tuberculosis.	10

December 2015

Screening, diagnosis and management of pulmonary tuberculosis in Family

Practice within the framework of the Revised National Tuberculosis Control Programme (RNTCP).	3+3+4

June 2013

Briefly describe the epidemiology of tuberculosis in our country. What is RNTCP?

How does it differ from earlier programme on TB? Discuss briefly about DOTS-Plus.

Pneumonia

December 2019

A 70-year-old lady is brought to you with fever, cough and breathlessness for the past 2 days. Write briefly on the CURB 65 criteria to assess community acquired pneumonia. Describe the complications and management of community acquired

pneumonia.

December 2017

What are the risk factors for Community Acquired Pneumonia (CAP)?

What is the investigating work-up for CAP? Mention reasons.

How will you prognosticate CAP? Mention criteria used.

List the treatment options for CAP.

December 2011

Describe briefly the etiology, clinical features, diagnostic evaluation and

treatment of a patient presenting with community acquired pneumonia. 1+3+3+3

Pneumothorax

June 2014

What is pneumothorax? Describe mechanisms of development of various

types of pneumothorax. Describe clinical features and management of Tension Pneumothorax





Pleural Effusion

December 2020

An 18-year-old woman, presents with left sided massive pleural effusion. What are your differential diagnosis? What specific tests would you need to confirm your diagnosis? She turns out to be HIV positive. How would you

explain to her and her widowed mother? 3+5+2

ARDS

June 2014

Define Acute Respiratory Distress Syndrome. What are the associated disorders? Write the principles of management of Acute Respiratory

Distress Syndrome.

Pulmonoary eosinophilia / Miliary shadows

June 2012

Write short note on Pulmonary Eosinophilia.

Discuss the differential diagnosis of multiple miliary shadows on chest X ray.













High yield areas based on previous year questions

Hypothyroidism

Diabetes mellitus

Diabetic Ketoacidosis DKA



Hypothyroidism

June 2015

Clinical features, physical examination findings, investigations and

management of hypothyroidism.  2+3+2+3

Diabetes mellitus

June 2022

A 45-year-old overweight man came to you with recent onset tiredness, dryness of mouth, weight loss and nocturia.

What is your clinical diagnosis?

How will you manage him after diagnosis? [10]

December

2019

Describe the long term complications and treatment of type 2 diabetes mellitus

June 2019

A 40-year-old businessman with a busy work schedule visits you as he has a family history of diabetes mellitus, heart disease and high cholesterol and is concerned about his health. He has a BMI of 35.

Comment on the significance of BMI and how reducing it will affect other co-morbidities.

Discuss the various methods of weight reduction you will advise.

December 2018

A 50-year man has been diabetic for 15 years and has an HbA1c of 12%. He is taking Metformin+ glimepiride in full doses. He refuses insulin.

What are the other oral hypoglycemic agents he can be given and explain the actions?

If he agrees to take insulin, what are the various regimens of insulin he can be prescribed?

What is an insulin analogue?

Name 1 rapid-acting acting and one intermediate-acting insulin analogue.

December 2016

A 55 year old diabetic of 8 years duration has an HbA1c of 9.0% on Metformin 2gm/day & Glimeperide 4mg/day.

List 3 management stragegies which can be taken using oral drug in step-wise manner to improve glycemic control.

How will you start insulin, if above are not successful? What advice will you give to this patient if started on insulin?

If HbA1c is 8% with all above treatments, what further can a diabetologist offer?	4+4+2

December 2015

Mr. Ravi is a diabetic for the past 20 years and is on metformin 1 gm bd and glipizide 10 mg bd. He has come with a complaint of swelling of his feet.

He has no shortness of breath and his urine output is normal plus BP is 128/80mmHg.

Which chronic complication of diabetes does he have?

Which diagnostic steps will confirm it?

Primary and secondary prevention principle of this complication.





Diabetes mellitus

December 2014

A 55 year old truck driver was diagnosed to have diabetes mellitus recently

. His BMI is 31. His BP reading were 154 /94mmHg on repeated occasions:

List the investigations you would ask for this patient.

What advice will you give him, about diet and lifestyle?

What medications will you start him on?

List the complications of diabetes mellitus.

Diabetic Ketoacidosis DKA

June 2021

A 23-year-old man was admitted to emergency room of primary care hospital for vomiting and upper abdominal pain. His random blood sugar was found to be 586mg/dl. He is hemodynamically stable. His urine ketones were +++

Mention the immediate life-threatening condition this patient can have. [1]

Mention the investigations you want to do, substantiate you answer. [3]

What are the complications of this condition? [2]

Discuss the management of this condition in detail up to discharge. [4]

December 2020

A 60-year-old lady, known diabetic since a few years, did not take her medicines a few months and presents with abdominal pain, vomiting and fever in your primary care clinic.

Write 4 differential diagnosis?

What investigation would you like to do, with reasons for each?

How would you manage each condition? 2+3+5

JUNE

2017

History, physical examination findings, investigations and management of

diabetic ketoacidosis.2+2+3+3

April 2016

A 15 year girl is diagnosed to have high blood sugar. There is no history suggestive of keto-acidosis. She has a long history of recurrent pain abdomen not requiring hospitalization over many years.

What investigations are needed for her further evaluation?

How would you start her therapy?  5+5





















Gastrointestinal System







High yield areas based on previous year questions

Acute pancreatitis

Irritable bowel Syndrome

Alcoholic Liver disease

Jaundice

GERD

Dyspepsia

Inflammatory Bowel disease

Hepatitis

Hemetemesis

Chronic diarrhoea







GERD

June 2022

Describe the condition and causes of gastroesophageal reflux diseases (GERD), give anatomical basis of GERD?

Write briefly on the management of GERD from a family medicine perspective? [4+3+3]

December 2020

A 30-year-old salesman has come to you with heartburn and reflux for the past 2 months. He travels extensively and eats out all the time. He has gained weight recently due to the junk food that he has been eating. He admits to smoking and drinking to deal with the stress of work. On examination, his BMI is 34 and he has no abnormalities except for mild epigastric tenderness.

What are the red flags in the history that you would ask for?

What is the most probable diagnosis and what drugs will you start him on?

What life style changes would you advise him? 2+3+5

June 2020

A 30-year-old salesman has come to you with heartburn and reflux for the past 2 months. He travels extensively and eats out all the time. He has gained weight recently due to the junk food that he has been eating. He admits to smoking and drinking to deal with the stress of work. On examination, he is found to be hypertensive and he has no abnormalities except for mild epigastric tenderness.

What are the red flags in the history that you would ask for?

How you can classify hypertension?

What drugs will you start him on for his various problems?

What lifestyle changes would you advise him? 2+3+3+2

June 2015

Clinical features and management of gastro-esophageal reflux disease.

5+5

Dyspepsia

December 2014

Discuss the differential diagnosis and investigations for a 60 , year old man presenting with dyspepsia,

What is the management of each?





Acute pancreatitis

December 2017

A 30-year-old male presents to emergency department with sudden onset of abdominal pain.

List the clinical signs and symptoms of acute pancreatitis.

What are the diagnostic features of acute pancreatitis in laboratory investigation?

List steps of management of acute pancreatitis.

List long term complications of acute pancreatitis.

Irritable bowel Syndrome

June 2018

Ashok is a 27 -year -old salesman who comes to you with the complaint that he has increased frequency of defecation for the past one month.

List the differential diagnoses.

Outline history, physical examination findings, investigations which will be of help to differentiate between common causes of increased frequency of bowel movement of recent onset.

When will you entertain the diagnostic possibility of Irritable Bowel syndrome? How do you manage it?	2 + 4 + 4

December 2016

A 40 year old man with chronic diarrhea for 5 years labeled as irritable bowel syndrome presents with increase in diarrhea.

What points in the history will suggest three other possible diagnoses?

How will you attempt to establish these diagnoses?	5+5

Hepatitis

December 2021

A 28-year-old male who is working in a factory and regularly taking food from a mess, presented to you with history of anorexia, nausea, fatigue and myalgia of four days duration and fever for one day. He also noticed high coloured urine and yellow discoloration of the eyes. There is similar illness in some of his colleagues taking food from the same place.

What is your diagnosis? Describe the etiopathogenesis of the present condition. [3]

Mention the differential diagnosis and complications that you expect in this patient. [2]

How will you manage this patient and what are the red flag signs? [3]

What control measures you will take as a medical officer working in a PHC when such clustering of cases occur. [2]

June 2014

Enumerate etiological agents of viral hepatitis. Write mode of transmission,

diagnosis, complications and .treatment of Hepatitis C.

June 2013

Enumerate the causes of acute viral hepatitis. Briefly describe biochemical and serological tests for it. How will you manage acute viral hepatitis? What

measures should be taken for its prevention?

Jaundice

June 2022

A 30-year-old lady came to you with fever of 3 days, decreased food intake and nausea. Clinically jaundice was present. There were similar cases in the family. What is the clinical diagnosis? What are the differential diagnoses? How will you

proceed to evaluate? How do you prevent the condition. [2+2+3+3]



December 2016

Mr.Pratap is a 75 year old man who has come with a history of yellow discolouration of his eyes. You notice that he is jaundiced.

What is the differential diagnosis for the cause of his jaundice?

How will you proceed with history and physical examination to assess him?

Investigations you would ask for with justification for each.

What are the characteristics of liver function tests in hepatocellular and obstructive jaundice? 2+3+3+2





Jaundice

June 2015

A 45 year old hospital worker complains of tiredness, right upper quadrant pain and dark urine. Examination reveals jaundice.

List the additional points to be looked for in the history and examination.

List the differential diagnosis.

List the relevant laboratory tests in each diagnosis listed in (b).

Relevant preventive measures pertaining to points in (b). 2+4+2+2

Alcoholic Liver disease

June 2018

Ramesh is a 30-year-old truck driver who has come with his wife to discuss about his drinking habit.

Outline the CAGE questionnaire and it’s use.

What treatment is given if he requires admission for alcohol de -addiction?

What investigations will you order for his assessment?

What is your role as a Family Physician to help Ramesh stay sober? 2 + 3 + 3 + 2

Inflammatory Bowel disease

June 2014

Write etiology, clinical features, diagnosis, complications and management of inflammatory bowel disease.

Hemetemesis

December 2012

What is hematemesis?

What are the common causes of hematemesis?

How will you confirm its cause?

How you will approach to a patient with hematemesis ? Mention suggested algorithm.

Chronic diarrhoea

December 2011

Enumerate causes of chronic diarrhea. 4+3+3

Describe diagnostic evaluation and therapeutic approach to a patient suffering from chronic diarrhea.

Cirrhosis Liver

December 2022

A 48-year-old Krishnan presented to OPD with history of Abdominal distension over past 3 weeks, gradually increasing, His wife gives history that he was diagnsed as a case of cirhosis of liver 6 months ago:

What are the common causes of cirrhosis? [2]

What are the clinical manifestations - symptoms and signs of cirrhosis? [2]

What are the complications of cirrhosis? [2]

How will you manage (Investigations + Treatment) this patient? [2]

How will you assess the severity of cirrhosis? [2]









Nephrology







High yield areas based on previous year questions

PSGN

Nephritic syndrome

Nephrotic syndrome

Chronic kidney disease

Proteinuria

ESRD







Chronic kidney disease

December 2021

A 60-year-old male diabetic and hypertensive of twenty years duration, comes with fatigue, tiredness, and pallor.

What diagnostic possibilities will you consider? [2]

How will you make a diagnosis of chronic kidney disease (CKD)? [2]

Mention the causes for CKD and mention the relevant investigations for diagnosis. [2]

What is the role of family physician in prevention and management of chronic kidney disease? [4]

PSGN

June 2019

Etiology, clinical features, investigations and management of post streptococcal glomerulonephritis.

Nephritic syndrome

April 2016

A 44 year old man gives a history of hypertension detected few years ago and is in treatment. He gives history of haematuria recently and also 1 year ago. There is a history of vague flank pain for the last few years. There is a family history of hypertension in his siblings.

How would you investigate this patient?

What relevant histories would you enquire for?

What is the implication of the family history for the future generation?

How would you manage the whole problem?	2+2+3+3

Proteinuria

June 2014

Discuss in brief various types of proteinuria. Define nephrotic syndrome. Enumerate causes of nephrotic syndrome. Outline treatment of minimal

change glomerulonephritis.

ESRD

June 2013

What is ESRD (End stage renal disease)? How you will grade ESRD?

Discuss the health education programme to prevent chronic renal disease.

Nephrotic syndrome

June 2012

Enumerate causes of generalized anasarca.

Describe the clinical presentation, diagnostic evaluation and management of an adult presenting with nephrotic syndrome.







Neurology







High yield areas based on previous year questions

Headache

Seizures

Unconscious patient

Syncope

Stroke

Vertigo

LMN Palsy

Dementia

Parkinsonism

Neuropathy

Guillian Barre syndrome

Dizziness

Ring enhancing lesion











Headache

June 2021

A 21-year-old student presents with headache for the past few months.

Write briefly on the history that you will elicit and the significance of each aspect of the history. [2]

What clinical features will you examine for? [2]

List the indications for imaging in a patient presenting with acute headache. [2]

What is the treatment of acute migraine attack? [2]

Write briefly on drug prophylaxis for migraine. [2]

June 2019

A 25-year-old lady presents to you with history of hemi-cranial headache for the past 2 days. She has been having similar symptoms since the age of 15 years.

List the common causes of headache in family practice.

What clinical features will you look for in this patient to arrive at a diagnosis?

How will you manage the current symptoms?

How will you counsel her to prevent further attacks?

December 2016

A 25 year old lady has episodes of pain unilateral face and temporal region lasting 12 to 24 hours for last 3 months.

List 3 possible diagnoses, giving differentiating clinical features.

Management principles of each in brief.

December 2014

List the common types of primary headache.

Outline the management of acute attacks and prophylaxis.

December 2011

Enumerate common causes of headache. 3+2+2+3

Briefly describe clinical features, diagnostic criteria and treatment of migraine.





Seizures

December 2018

A 45-year-old man is brought by his family with complaints of loss of consciousness and jerky limb movements 2 days prior for the first time.

What will you do if he has repeated episodes, and remains unconscious for 30 minutes, while you are examining him?

If he has a history of heavy alcohol intake, what is the pathogenesis and management?

List the diseases which can be shown up in a CT scan.

June 2014

How do you classify seizure?

Describe principles of management of epilepsy.

Enumerate merits and demerits of newer anti-epileptic drugs

Vertigo

December 2018

A 35-year-old previously healthy man develops sudden severe spinning sensation of the head, and vomiting lasting 2 days.

What are the clinical findings, differential diagnosis, and how is it managed?

After recovery, the man develops episodes of vertigo lasting a day or two. State the diagnosis and management.

Name 2 drugs which cause unsteadiness and/or vertigo.

LMN Palsy

JUNE 2017

A 25 year old lady has come to you with drooping of one side of the face from morning. She has clinical features of a right sided lower motor neuron (LMN) nerve palsy.

List the causes of LMN 7th nerve palsy.

How will you assess her further with history, physical examination and investigations?

Management of Bell’s palsy.

Dementia

December 2021

Describe briefly the etiopathogenesis and clinical features of dementia in elderly and mention the treatable causes of it.

As a family doctor, what is your role in management of an elderly with dementia? [5+5]

April 2016

What are the causes of reversible dementia? What investigations are

relevant for diagnosis?	4+6

June 2013

What is dementia?

What are the common causes of dementia? What are the clinical presentations of dementia?

What are the management strategies to prevent and treat it?

Parkinsonism

April 2016

What are the clinical features and investigation findings in a patient suffering from vascular Parkinsonism?

What features will distinguish the patient from idiopathic Parkinson’s disease?	(4+4)+2

Neuropathy

June 2021

Aetiology,	clinical	features	and	investigations	in	assessment	of

polyneuropathy. [4+3+3]

June 2015

Clinical features and physical examination findings of diabetic peripheral neuropathy.	4+6





Syncope

December 2014

Discuss differential diagnosis of recurrent syncope in a 65 year old diabetic lady

Stroke

June 2013

Describe the risk factors, lab investigations, differential diagnosis and management of stroke.

Briefly describe stroke control programme.

Ring enhancing lesion

December 2012

Discuss the ring enhancing lesions on MRI brain?

What are the common causes?

How you will treat neurocysticercosis?

Guillian Barre syndrome

December 2012

What is the Guillian Barre syndrome (GBS)?

What are the symptoms of GBS?

How you will diagnose it?

What is the treatment of GBS?

What are the complications of GBS?

Unconscious patient

December 2011

Enumerate causes of unconsciousness. 5+5

Describe diagnostic approach to an unconscious patient.

December 2020

A 60-year-old man is brought to you with history of brief episodes of loss of consciousness over the past week.

List the differential diagnosis for this presentation.?

What history and physical examination would you elicit?

How will you investigate this patient? 4+3+3

June 2020

A 60-year-old man is brought to you with history of brief episodes of loss of consciousness over the past week.

List the differential diagnosis for this presentation

What history and physical examination would you elicit?

How will you investigate this patient? 4+3+3

Dizziness

December 2022

A 67-year-old lady was brought to the emergency room with h/o dizziness but no loss of consciousness. She is a known diabetic and hypertensive, occasionally noncompliant with her medications. Her BP is 130/86mmHg, PR- 86/min - irregularly irregular, GRBS- 186mg%.

What immediate office investigation would you do? [1]

What may be the most probable diagnosis? [1]

What other investigations you would want to do? [2]

What are the complications of this condition? [2]

How will you assess this patient for stroke risk? [2]

How will you manage this patient? [2]







Rheumatology







High yield areas based on previous year questions

Rheumatoid Arthritis

Gout

Crystal arthritis

Chronic fatigue syndrome

Chronic Pain

SLE











Rheumatoid Arthritis

December 2018

List the criteria and scoring system for making a diagnosis of rheumatoid arthritis (2010, ARA criteria).

List and describe the hand deformities in rheumatoid arthritis.

What does the diagnosis of “reactive arthritis” mean?

December 2015

Clinical features, investigations and management of rheumatoid arthritis.

3+3+4

December 2011

Enumerate causes of arthritis 2+3+5

Describe the diagnostic criteria and management of rheumatoid arthritis

Gout

June 2021

Clinical features, diagnosis and management of gout. [3+2+5]

June 2015

Aetiology, clinical features, investigations and management of gout.

1+2+3+4

Crystal arthritis

June 2014

Enumerate musculoskeletal manifestations of crystal induced arthritis.

Describe risk factor, clinical features and management of acute gouty arthritis.

Chronic fatigue syndrome

December 2012

Describe chronic fatigue syndrome.

What is the pathogenesis, manifestation and Centers for Disease Control and Prevention (CDC) criteria for diagnosis?

Mention its treatment?

Chronic Pain

June 2022

Mention the causes for chronic aches and pains.

How do you differentiate that from inflammatory arthritis? How do you evaluate a patient with chronic aches and pains?

Describe briefly regarding management of chronic pain? [2+2+2+4]

SLE

December 2022

A 40-year-old lady presented to outpatient department with multiple joint pain, hair loss, oral ulcers, malar rash, breathlessness, and history of passing blood in urine.

How will you evaluate the history and physical finding to come to a woking diagnosis in an adult patient with multiple inflammatory arthritis? [4]

What are your differential diagnosis? [2]

What investigations you would want to do? [2]

What are the complications of the most probable diagnosis? [2]







Infection







High yield areas based on previous year questions

Rabies

Food poisoning

UTI

Hemorrhagic fever

AFI

Common cold

EBV

Fever with Rashes

Fever with Cough

HIV

Covid 19











UTI

December 2021

A 42-year-old woman, mother of three children presented to you with history of dysuria and high grade fever with chills for past 3 days. There was associated lower abdominal pain and increased frequency of urination. She has been having stress incontinence since delivery. She has come to you with similar complaints in the past.

What is your probable diagnosis in this patient? [2]

What are the factors predisposing recurrence of this problem? [2]

How will you confirm your diagnosis and manage this patient today? [4]

What is the role of the family physician in prevention of this condition recurring again? [2]

December 2017

What are the various forms of urinary tract infection (UTI)?

Mention the etiological agents and their risk factors. A 30-year-lady presents with cystitis.

Mention the management plan for treating and preventing UTI in her.

December 2015

A 23-year old non-pregnant lady comes with complaints of dysuria, increased frequency of urine, and lower abdominal pain.	1+2+4+3

Enumerate the two most likely causes in order of priority.

List 4 risk factors for these causes.

Outline diagnosis and management of this episode.

What is the approach if she gets repeated episodes of the above?

December 2012

What are the symptoms of urinary tract infection (UTI)?

How will you diagnose it?

What are the organisms responsible for it?

What is the treatment of UTI?

What are the common complications of UTI?

Rabies

June 2013

Describe the clinical picture, diagnosis and treatment of rabies in man.

How human rabies can be prevented?





Food poisoning

June 2013

What is food poisoning?

Describe briefly various types of food poisoning. Discuss its differential diagnosis.

How will you investigate food poisoning?

Hemorrhagic fever

June 2012

Enumerate briefly the causes of hemorrhagic fever.

Describe the etiopathogenesis, diagnosis and treatment of dengue fever.

AFI

December 2019

A 30-year-old farmer presents with an acute febrile illness of 7 days duration. List the common causes of an acute undifferentiated febrile illness.

Describe your approach to this patient in terms of history, examination, investigations and management in a clinic.

List indications for referral for admission

Common cold

April 2016

What is common cold?

Describe how ‘cold’ weather is related to increased susceptibility to viral infections.

How will your treatment attitude differ within a family with adults, children & elderly persons?	1+3+6

EBV

April 2016

A 14 year old girl has fever for 2 weeks with painful red spots on her skin. She also has a few cervical enlarged lymph nodes.

How would you proceed to investigate her further? What advice would you give to the family? 7+3

Fever with Rashes

December 2015

A 20 year old man is brought to you with history of 5 days of fever and severe body ache with rashes.

Outline the clinical approach to this patient in Family Practice.

List the investigations for this patient with justification for each.

Public health implications if large numbers of patients are affected. 4+3+3

Fever with Cough

December 2020

A 24-year young man, presents with fever and dry cough since 3 days with no localizing symptoms.

List the common differentials. How would you manage?

When would you decide to investigate this patient? When would you advise admission? 3+3+2+2

HIV

December 2012

How you will confirm the diagnosis of HIV?

What are the common symptoms for the patients suffering from HIV/AIDS?

What are the NACO guidelines for initiation of ART?

Which ART drug must be avoided in pregnancy?

Covid 19

December 2021

Explain post covid syndrome?

How will you manage it at a primary health care level? [5+5]

June 2021

Respiratory and non-respiratory symptoms of COVID-19 infection. [5]

Outline home based care for a patient with mild COVID-19 infection. [5]







June 2020

A 65-year-old patient is having fever and dry cough for last three days, and difficulty in breathing for last two days. He is a known diabetic and hypertensive patient.

What are your differential diagnosis with clinical justification?

What are the current treatment guidelines for Covid-19 patients? 5+5







Toxicology





Snake bite

December 2018

A 20-year-old village man dwelling in a hut, is woken up from sleep early morning from a painful snake-bite on his arm, and is unable to open his eyes after a few hours.

Explain the most likely type of snake and pathogenesis of his symptom.

What will you look for in the bitten area, giving the inference of the signs detected?

If he developed hematuria what is the likely snake and pathogenesis of symptom?

Chemical Poisonings

June 2022

Write briefly on reasons for chemical poisonings.

Enumerate	clinical	features,	management,	and	complications	of organophosphorus poisoning? [3+3+2+2]

Snake Bite

December 2022

A 42-year-old Ravi was working in fields when he suddenly had snake bite. Before he or his fellow workers could identify, the snake had escaped.

Which are the common snake bites in India? [1]

From the clinical features of the patient, how would you identify the type of snake bite? [2]

What investigations will you do (bed side and Lab)? [2]

What are the complications of snake bite? [2]

How will you treat Snake envenomation? [3]









Metabolic & Nutritional diseases





Hyponatremia

December 2017

List the causes of hyponatremia.

Mention the investigating work up for a 60-year-old man with hyponatremia.

How will you treat a patient with hyponatremia?

Obesity

December 2020

Over the years, there are many women who visit your OP who are overweight or obese. (2+2+4+2)

What are the definitions of obesity?

Obesity is a risk factor for many diseases, name four.

What are the personal measures you would suggest to reduce weight? What are the community measures you would suggest to reduce obesity?

June 2020

Explain various indices or tools to define obesity.

What preventive measures you would like to take at individual level and at community level to prevent obesity? 5+5

December

2014

Describe the complications of obesity .

June 2012

Enumerate complications of obesity.

Describe management of a patient with morbid obesity.

Weight Loss

June 2021

A 75-year-old man is brought to you by his family as he has lost about 5 kilograms in the past 1 month.

Define significant weight loss in elderly over 1 month,3 months & 6 months. [1]

What history will you elicit to find the cause of weight loss? [2]

What clinical features will you examine for? [4]

Write short notes on investigations to assess the loss of weight. [3]

December 2014

Describe how you will manage a patient with significant weight loss by discussing history, physical examination and investigations.

Osteoporosis

June 2021

A 70-year-old presents to you with severe backache after a fall and her X-ray showed a compression fracture of L4 vertebra.

Discuss the risk factors, prevention, diagnosis and management of osteoporosis. [2+2+3+3]

December 2012

What is osteoporosis?

What are the diagnostic approaches for it?

What is management for it?

How will you monitor the response?

Balanced diet & Vitamin deficiency

June 2022

Describe briefly on Vit.D metabolism, clinical features and management of Vit.D deficiency? [5+3+2]

June 2021

Write short notes on the aetiology, clinical features, investigations and treatment of

Vitamin B-12 deficiency. [2+2+2+4 ]

June 2012

Write short note on balanced diet.

Describe briefly the clinical features, diagnosis and treatment of Vitamin D deficiency in an adult.

Protein calorie malnutrition

June 2022

Enumerate skin, mucosal, and systemic manifestations of protein calorie malnutrition. [4+3+3]









General topics





Drug interaction

December 2018

Explain the mechanisms of interactions between the following pairs of drugs.

a) Warfarin and phenytoin.	b) Rifampicin and oral contraceptives.

c) Salbutamol and atenolol.	d) Iron supplements and antacids.

Health Check up

June 2018

Lokesh is a 50 -year -old businessman with a BMI of 35. He has come to you for a health checkup.

How will you assess the health of this patient? Mention the rationale for the investigations you would ask for.

What complications of obesity would you expect in him and explain to him?

What advise will you give him to lose weight?

December 2015

Mr. Naveen is a 55 year old business man presenting with tiredness for the past one month, physical examination is normal.

List 4 likely causes in order of priority.

Discuss further history and examinations findings you will elicit for each of the above causes.

List the basic investigations you will order with reasons.	4+4+2

Health care team

June 2018

Role of Family Physician as the leader of the health care team. (10)

Adult Immunization

June 2018

Write short note on the following vaccines for the adult population:

Influenza vaccine

Pneumococcal vaccine

Hepatitis B vaccine

Human papilloma virus vaccine

Varicella vaccine	2+2+ 2 + 2+2

JUNE 2017

A 75 year old comes to you to discuss about adult immunization.

What advice would you give him?

Pneumococcal vaccination in adults.	5+5

Heat Illness

December 2020

A 25-year-old labourer who was working in the field in the hot sun was brought to you with altered behaviour. His core temperature was found to be 1050 F.

What is the differential diagnosis?

How will you investigate and manage this patient? 10

June 2020

A 25-year-old labourer who was working in the field in the hot sun was brought to you with altered behaviour. His core temperature was found to be 1050 F.

What is the differential diagnosis?

How will you investigate and manage this patient? 4+2+4

Polypharmacy

JUNE 2017

Mr. Gobul is an 80 year old businessman who is living alone in an apartment in a city. His wife passed away a month ago and his children live abroad. He is on medications for diabetes mellitus, hypertension, dyslipidemia, ischaemic heart disease and cardiac failure:	7+3

Social issues in the elderly and use of medications for Mr. Gobul.

What advice will you give him for the safe use of medications?





Occupational Hazard

June 2018

Pradeep is a 40 -year -old construction worker. His work involves lifting heavy objects, carrying cement bags and bending steel rods. He works from 8 am till 5 pm, most of which is in the outdoors. The work area is also very dusty and noisy and there are heavy machinery and sharp tools being used in the site.

What are the occupational hazard risks that Pradeep faces?

Write briefly on how to reduce the risk of harm to him due to his work.

5 + 5

December 2015

A 28 year old labourer presents to you with backache. Describe briefly the physical, mental, social, financial and occupational aspects of his illness.

2+2+2+2+2

Tiredness

June 2019

A 55-year-old woman presents to you with history of fatigue, weight gain and day-time drowsiness for the past 3 months.

List 3 possible causes for her symptoms giving reasons.

Describe in detail the clinical approach to this patient in the light of the above possibilities.

Generalized aches and pains

JUNE 2017

A 50 year old lady presents to you with history of generalized aches and pains for past 3 months. 3+7

List the possible causes for these.

Outline appropriate history, physical examination and investigations to assess this patient.

Patient vs disease centered

JUNE

2017

Patient centred versus disease-centred medicine.	10

Smoking

December 2020

You have a 45-year-old patient whose spirometry showed features of COPD. Discuss how you will help him to quit smoking

December 2016

Sooraj is a 45 year old office worker who also has diabetes and hypertension. During the consultation for management of his health, you raise the issue of his smoking.

List the adverse effects of smoking that you would discuss with him.

What practical advice will you give him to quit smoking?

List the withdrawal effects of quitting smoking.

Pharmacological treatment to help quit smoking.	2+2+2+4

December 2015

A 50 year old smoker presents to you with cough for the past 1 month.

Outline the differential diagnosis with history and physical examination findings for each.

List the investigations you would ask for.

Principles of smoking cessation programme.	4+1+5

June 2015

List the medical and social consequences of tobacco smoking.

Principles of smoking cessation programmes.

Role of the family physician in smoking cessation.	4+4+2





General Statistics

December 2016

Give briefly the interpretation of the following values in research studies.

Comparision of heights in same age groups in school children rural Vs urban p<0.01, 95% CI 0.1 – 1.8

Number needed to treat (NNT) 20/1000 in a trial of new lipid lowering agent.

Odds ratio of 1 (one) in a Randomized Control Trial (RCT) of mortality in sepsis patients receiving a new antibiotic.	4+4+2

General-Patient doctor relation

June 2014

What are the principles of doctor-patient relationship (Rapport)? Describe P-SPIKES approach for breaking bad news.

General Anaphyllaxis

June 2013

Define anaphylaxis. Enumerate various causes of anaphylaxis. Which is the most useful drug for its management? Describe the steps of management of anaphylaxis.

General-Pretravel Consultation

December 2017

An 18-year old boy is brought to you by his parents for a health check. He is about to go out of the country for studies.

What clinical evaluation will you do and why?

What investigation will you do and why?

Immunization advice for him.

What behavioral counseling will you do?









Critical Care



BLS /ACLS

June 2012

Discuss the steps of basic and advanced cardiac life support.









Geriatrics and Palliative medicine



Geriatrics

June 2013

What are the common health problems faced by older people? Can life style modification prevent them? Explain. What are the other preventive steps to

be taken to modify these problems.

Palliative medicine

June 2019

Describe the common symptoms and their management in a terminally ill patient

suffering from breast cancer.

December 2017

Draw the WHO pain management ladder, mentioning the groups of drugs used with examples and their common side effects.

How will you manage bladder pain in a patient with advanced urinary bladder carcinoma?

JUNE 2017

Mr. Raju is a 65 year old patient who was diagnosed to have bronchogenic carcinoma with secondaries. He is on palliative care now.

List the medical problems Mr. Raju could develop and how you would manage them?

What are the social issues related to his survival that you as his family physician would discuss with him? 7+3





EOLC

December 2022

A 48-year-old Mrs.Lata has been diagnosed with end stage Breast cancer and her oncologist told her that there is no further treatment. She wants to discuss with you about her feelings and about the events which may follow:

End of life care. [5]

Advanced directives.in the light of indian laws and guidelines. [5]

Falls in elderly

June 2022

Enumerate the causes of falls in the elderly.

How would you assess the risks of fall in elderly? How can we prevent falls in elderly? [4+3+3]

December 2022

Mrs. Pratibha 73-years-old, staying with her spouse presents to Outpatient department with history of fall 2 days back in her home. Six months ago also, she had a simillar complaint and she sustained a Colle’s fracture of the right hand. Her first fall was one year ago when she sutained minor abrasions.

What is the pathophysiology of Falls? [2]

What are the risk factors? [2]

How will you do the OPD assessment of falls? [4]

How are you going to prevent further falls in Mrs Pratibha? [2]

December 2021

A 80-year-old male strict vegetarian, with history of giddiness, loss of balance and fall with transient loss of consciousness which recovered promptly is brought to you. He has similar history one month before too.

Mention the factors that contribute to fall in an elderly like him. [3]

How will you evaluate this gentleman with history of recurrent falls. [4]

What steps you would take in prevention of fall in him? [3]

June 2018

Mrs Rajini is an 80 -year -old lady on treatment for diabetes mellitus and hypertension. She has come with her daughter who is concerned that her mother fell the previous day. She was not hurt as she fell on to a soft bed. The daughter would like you to assess the risk for falls for her mother and wants you to visit their house also as part of the assessment. Describe briefly how you would make an assessment of the risk of falls for Mrs Rajini:

History and physical examination b) Assessment at home 6 + 4

December 2015

Mrs. Rao is a 75 year old lady with history of recurrent falls.

Outline the likely causes.

Role of the family physician in assessment and management.	5+5

Bedsore Management

June 2022

A-78-year old lady with right sided hemiplegia is being discharged from hospital. Relatives are taking her to her home at a remote village. She is bedridden and is on indwelling catheter and Ryle’s tube feeding:

What are the problems that you can anticipate in this patient? [2]

What advice will you give to prevent bed sores in this patient? [3]

How will you classify bedsores? [3]

Family physician’s role in managing bed sores. [2]

























DERMATOLOGY





Acne

December 2020

A 17-year-old girl is concerned about her acne. What are the various presentations of acne? What are the treatments available? How would you counsel her? 3+5+2

December 2017

A 15-year-old boy is brought by his mother, as he is upset because of his ‘pimple on the face’ problem:

Mention the life style modifications with regard to acne.

How will you treat various forms of acne according to severity?

List four systemic causes of acne.

December 2014

Describe briefly the pathology, clinical features and management of

acne.

June 2012

Describe the etiopathogenesis, clinical features and management acne vulgaris.

Psoriasis

December 2022

48-year-old lady, known case of diabetes, hypertension, dyslipidemia, presented to outpatient department with skin lesions over her elbows, knee, which has increased over past 3 weeks. Earlier she had small lesion for which she used moisturizer which didn’t bother her much. These lesions are well defined, erythematous plaques, with irregular borders and silvery scales.

What is the most probable final diagnosis? And how will you confirm your diagnosis? [2]

How will you manage this condition? [4]

What are the complications of this condition? [3]

When will you refer this patient to a specialist? [1]

December 2019

Describe the clinical features and management of chronic plaque psoriasis.

June 2018

Clinical features and management of chronic plaque psoriasis. 5+5

JUNE 2017

Clinical features of psoriasis.	5+2+3

What aspects of the disease will you discuss with a patient who has psoriasis?

Management of psoriasis.

December 2012

Describe the skin lesion of psoriasis.

What are the other manifestations of psoriasis?

What is the treatment of psoriasis?

Recent advances in treatment of psoriasis?

Leprosy

December 2019

Enumerate the reactional states in leprosy. Describe their clinical features and management.

June 2014

Describe clinical and immunological classification of leprosy. What are the type of reactions and treatment of Multi-bacillary leprosy?





Pruritus

December 2021

A 40-year-old female is brought with pruritic, dry, scaly hyperpigmented plaques with erythematous edges, present over the scalp, buttock, back, and extensor aspects of forearms bilaterally associated with arthritis involving symmetrical small and large joints for past 2 months. Her nails are dystrophic.

What diagnostic possibility will you consider and why? [2]

How will you manage the skin lesions? [3]

How will you manage the polyarthritis? [3]

Mention the causes of generalized pruritus. [2]

June 2019

A 40-year-old labourer in the local market presents to you with history of generalised pruritus for the past 1 week.

Discuss the approach to this patient including significant history, physical examination, investigations and management.

December 2018

A 45-year-old diabetic lady presents with generalized pruritis. A thorough examination of the skin reveals no abnormality.

List 6 possible causes and explain how to investigate for them.

If the history starts in young age and skin shows dryness and lichenification especially in the flexures, state the most likely diagnosis.

What systemic drugs are used for pruritus and state the side effects?

December 2016

A 1 year old child presents with itching of face and hands for 3 months, preventing sleep and feeding.

What is the most likely diagnosis? Mention the differentials.

How will you manage the child?

When will you consider specialist referral?	4+4+2

Infection in Dermatology

December 2011

Describe	briefly	the	etiopathogenesis	clinical	features	and management of a patient suffering from 'Scabies'

3+3+4

June 2020

Clinical features and management of following conditions in children:

Scabies

Head louse infestation 5+5

June 2015

Clinical features and treatment of the following skin diseases:

Atopic dermatitis in children and adults

Tinea corporis

Lichen planus

Impetigo	4+2+2+2

Dermatology Skin lesions

June 2013

Describe primary and secondary skin lesions.

Discuss the various diagnostic techniques for skin disorders.









Compiled by Dr.Vishnu B S Family Medicine Specialist Trivandrum

PSYCHIATRY

47







Anxiety disorders

June 2020

Many of the students and adults, because of Covid-19 pandemic, are having anxiety disorder:

How will you clinically diagnose, investigate and manage such anxiety disorders in this group?

When you would like to refer such cases to a psychiatrist?

(3+2+3)+2

December 2019

Describe the classification, clinical features and treatment of anxiety

disorders.

June 2015

Clinical features and management of generalized anxiety disorder.

5+5

Depression

December 2021

How will you classify depression? [3]

Mention the signs and symptoms of depression. [3]

Mention the management options of depression and what steps will you take to prevent suicide in a depressed patient. [4]

June 2019

Clinical features, investigations and management of depression in family practice.

List the indications for referral to a psychiatrist.

December 2017

Mr. Ram, an Executive Chairman of a multi-national company, is brought to you by his wife with complain of ‘Low-mood’ for the past few weeks.

Mention the key features in diagnosis of depression.

How will you assess severity of his depression?

What are the risk factors for suicide in a depressed person?

List criteria for referral to a psychiatrist in a case of depression.

December 2014

List the DSM-IV(TR) diagnostic criteria for major depression.

List 5 organic causes for depression.

Describe briefly medical management of major depression.

Mania

December 2012

What is mania?

How does it differ from depression?

What is the treatment of mania?

What are the side effects of drugs used for the treatment of mania?



June 2020

A 45-year-old woman, is seen in the streets, poorly dressed, dirty clothes, hairs unkempt. She has been like this for the last 10-15 years. She leaves home in the mornings, takes tea at the local tea shop and returns home in the evenings. She does not take any responsibilities at home. She stays awake throughout the night and occasionally passes urine in her room. Her husband has taken their children to another village. Her widowed mother takes care of her. The latter is known to be using alcohol occasionally.

What are your differential diagnoses? How would you manage her?

What supports or referrals would you like to give her in a rural area with limited health facilities? 2+6+2





Schizophrenia

June 2015

A 75 year old man has hallucinations, neglects personal hygiene and gets lost after wandering from his home unattended.

State the diagnosis and its clinical confirmation.

List the relevant laboratory tests with reason.

List the management principles.	4+2+4

December 2014

A 75 year old man, was brought to you with history of abnormal behavior for a month:

List the conditions that can cause this.

List the investigations you will advise for this patient.

Briefly describe management of each condition.







December 2018

A 75-year-old man develops over 6 months abnormal behaviour at night, starts talking to his deceased wife, and is unable to recognize his family members.

What is the likely diagnosis? How can this be clinically assessed?

Describe the age-related changes in the brain.

List 4 other neurological diseases commonly seen in the elderly, with the pathogen



June 2019

A 24-year-old bus driver is brought to you by his family with history of episodes of sudden and unexplained behaviour lasting for a few hours after which he is normal.

State the likely differential diagnosis you would consider.

What historical points will you elicit to substantiate your diagnosis?

Discuss the role of investigations to establish the diagnosis.



December 2011

Classify psychiatric disorders. 5+5

Describe briefly various treatment modalities used in Psychiatry.



December 2018

Discuss briefly on the following sleep disorders:

Excessive daytime sleepiness.

Terminal insomnia.

Parasomnia.

Narcolepsy.

Drug-induced insomnia

Alcohol Withdrawal Syndrome

June 2012

What are the clinical presentation, diagnostic evaluation and treatment

of Alcohol Withdrawal Syndrome?

June 2021

A 28-year-old labourer who was brought to you by his family to the community health centre where you are working with history of generalized seizures. He is an alcoholic and was not able to drink for 2 days due to the lockdown. He is conscious and oriented now but is wearing dirty clothes and looks as if he has not taken a bath for few days.

Write briefly the differential diagnosis for seizures in this man. [3]

Symptoms, signs and management of alcohol withdrawal. [7]







December 2022

38-year-old Mr. Ravi was brought to the casualty with the history of first episode of seizures lasting for one minute. There was up rolling of eyes and drooling of saliva with loss of consciousness, regained consciousness after 2 minutes. There was no post ictal phase. The entire episode lasted for 5 min. Wife of Mr. Ravi gives history of alcohol intake by him of 180ml for past 20 years. His last drink was 3 days back – since he didn’t have work and didn’t have money. His BP is 130/80, PR- 92/min, SpO2- 100 %, GRBS- 110, He is oriented to time, place, person.

What is your differential diagnosis? [2]

What is your approach for above mentioned scenario? [5]

If GRBS- 50mg%. How will you treat immediately? [1]

How will you manage Alcohol related complications? [2]

Alcohol intoxication

December 2011

Describe briefly the clinical features, diagnostic evaluation and management of acute alcoholic intoxication.

3+3+4

Delirium

June 2022

What is delirium?

How is it different from dementia?

Enumerate the causes, differential diagnosis and management of delirium? [1+1+3+3+2]

Panic Attacks

December 2022

A 45-year-old woman - P3L3 - is accompanied by her daughter for episodes of fear and palpitations. She is a known hypertensive and is on telmisartan - thiazide 40/12.5mg OD. Since January, following a marital conflict, she has experienced multiple episodes of sudden onset of palpitations, sweating and dizziness. She is fearful of similar recurrence of such episodes. Her multiple visits to hospitals during those episodes showed a BP- 220/120 mmHg with negative cardiology work-up. Her vital signs now - BP- 160/90 mmHg, P-90/min, no elevated JVP or pedal oedema.

Describe the diagnostic criteria of panic attacks. [3]

List the possible medical conditions that mimic a panic attack. [2]

Describe the options of pharmacotherapy for this patient. [3]

What are the non-pharmacological treatment options for this patient? [2]





Compiled by Dr.Vishnu B S Family Medicine Specialist Trivandrum

51





SURGERY



Surgery



Abdominal Pain

December 2022

18-year-old married lady, presents with pain in the right side of the abdomen for the past one day. On examination, she has tenderness in the right iliac fossa.

What is your differential diagnosis? [3]

What relevant history and examination will you perform? [3]

How will you manage this condition if the patient is in shock? [4]

June 2022

A 30 years old male presented with severe epigastric pain since one day. His PR-110 bpm, BP-100/60 mm hg, RR-25/min.

Write 4 diagnostic possibilities you would consider in this patient. Describe	in	detail	about	clinical	features,	investigations	and

management of each. [4+6]

December 2021

A 21-year-old married female presented to emergency room with history of right sided lower abdominal pain since yesterday morning.

What are your differential diagnosis? [3]

How will you confirm your diagnosis and manage this lady with right sided abdominal pain? [4]

What are the indications for surgical management in this patient? [3]

June 2021

A 45-year-old lady presents with pain of the right upper quadrant of the abdomen. She has been getting episodes of pain in that site but it has become severe now and with feverishness.

Write short note on the aetiology, differential diagnosis, clinical features, investigations and initial management of acute cholecystitis. [2+2+2+2+2]

June 2020

A 40 years old lady, presents with abdominal pain since 2 days which is gradually increasing. Her vitals- BP 100/60mmHg, pulse 110/min, RR 25/min. Abdomen has generalized tenderness and guarding.

Write 4 differential diagnosis you would consider with common clinical findings in each. b) What initial management would you start for this patient? 6+4

June 2019

Lekha is a 23-year-old lady who has come to you with pain and tenderness of the right lower quadrant of the abdomen from the morning.

Discuss the differential diagnosis.

How would you rapidly investigate for each of the above diagnosis?

When and why should this patient be referred to a surgeon?

December 2018

A 45-year-old lady sees the family physician for vomiting and moderately severe pain in the right upper quadrant for 3 days.

List the 2 most important diagnosis.

What points in the history and physical examination will help to distinguish between the two?

What is the management plan?





Abdominal Pain

June 2018

A 45-year-old man presents with moderate to severe abdominal pain for the past 4 hours.

List the differential diagnosis.

Outline the aspects of the history of the pain that you would elicit with implications for the diagnosis.

List the clinical features that will make you suspect a surgical emergency that needs referral.

Investigations and management of ureteric calculus.

June 2015

A 30 year old lady comes to you with pain of the right lower quadrant of the abdomen since the previous night.

Enumerate the possible causes for the pain.

Clinical findings and investigations for each of the possible causes.

4+6

June 2013

A 35 years old male patient presented in emergency with acute onset, severe pain in epigastrium that became generalized all over the abdomen. On examination, he was in shock with board like abdominal rigidity. Enumerate possible causes of his problem. How will you investigate and treat him?

December 2011

Causes of pain in Right lliac fossa in 20 years old girl 3+4+3

Investigatory findings to confirm exact diagnosis

Treatment of acute appendicitis.

Antiseptics

April 2016

Enumerate antiseptics commonly used in general surgical practice. Briefly describe their usage. Give steps of skin preparation before excision of a lipoma on shoulder. 3+3+4

Bleeding PR

December 2020

A 35-year-old man complains of passing blood in his stools. Defecation is painful as well.

How would you assess this case?

What are the steps in the management of this case? 5+5

June 2018

55-year-old man comes to you with bleeding per rectum for the past 2 weeks.

List the differential diagnoses.

What further questions will you ask him for assessing him? Mention the rationale for each.

What clinical features will you look for?

Outline the management of fissure-in-ano

December 2015

Sheela is a 60 year old lady who presents with anal pain and bleeding per rectum for the past one month.

Outline differential diagnosis with history and physical examination findings for each.

Management in primary care.

Which cases should be referred, giving reasons?	4+4+2

June 2013

A 40 years old male patient presented with bleeding per rectum for the last six months. Enumerate possible causes of his bleeding. How will you investigate him? How will you treat him in case he has bleeding

piles?





Bleeding (Coagulation Disorders)

December 2018

A 15-year-old boy has an abscess in the calf and the family doctor performs an incision and drainage. The bleeding continues for hours despite pressure.

List the likely causes related to common inherited blood coagulation disorders.

Which drugs should be routinely discontinued prior to major surgical interventions, stating reason.

What treatment should be given for patients who bleed spontaneously while using the above drugs?

Blood Transfusion

December 2020

Mrs. Satya aged 40 years, presented to outpatient department with history of tiredness and fatigue, she gives history of heavy menstrual bleeding for 5 days, and on examination she is pale.

What are the indications of blood transfusion? [2]

What are the risks and complications of blood transfusion? [3]

What tests will you do on the donor blood before transfusion? [2]

What measures will you take before, during and after the transfusion in the ward? [3]

April 2016

What are the indications of blood transfusion? Briefly describe principles of blood grouping and cross matching. Enumerate complications of blood transfusion.	3+4+3

December 2011

Enumerate various blood products available for transfusion. 4+2+4

Indications of fresh frozen plasma transfusion.

Complications of blood transfusion

Breast Lump

December 2022

51-year-old female presents with palpable swelling in her left breast of 3 months duration. She is post-menopausal for three years. She has no medical comorbidities. Menarche was at 11 years of age. She has 2 children with her first pregnancy at 29 years of age.

How will you investigate this patient? [2]

What are the current recommendations for screening for breast cancer? [3]

Discuss the possible risk factors associated with malignancy of breast. [2]

Outline the long term management of this patient by you as her family doctor. [3]

December 2021

A 42-year-old female patient presented to you with right sided breast lump of two months duration.

What are your differential diagnosis? [2]

How will you evaluate this patient? [3]

What are the relevant investigation needed in this patient? [2]

Explain steps in self-examination of breast. [3]

June 2022

A 40 years old lady came with a 3 cm size lump in the left breast.

Enumerate differential diagnosis and management of each. [4+6]





Breast Lump

December 2017

A 40-year-old lady comes to you for routine breast examination. You find a lump in her right breast.

List the criteria for urgent referral for her.

Mention the features of any benign breast disease.

What are the other clinical examinations you will do in her for a preventive health visit?

December 2016

Rani is a 50 year old lady who presents to you with a lump in her left breast.

History and clinical features you would elicit on her.

What are the clinical features suggestive of a malignant breast lump?

Health education you would give to your patients about breast cancer, including early detection and screening.

June 2014

b) Describe risk evaluation and risk reduction strategies in cancer breast

management.

December 2012

Clinical sign of carcinoma breast.

Investigations of a case of metastatic breast carcinoma.

Counseling for chemotherapy in metastatic breast carcinoma.

December 2011

Triple assessment of breast lump. 3+2+5

Investigations and treatment of 50 years old female having bloody discharge right nipple.

Breast abscess

June 2021

A 26-year-old lady who is 2 weeks postpartum, presents with pain of the left breast.

Describe the clinical features, investigations and management of breast

abscess in a lactating mother. [3+2+5]

December 2014

Describe clinical features and management of breast abscess in a

lactating mother



Burns

December 2022

A 35-year-old lady accidentally suffered burns over the upper thighs upto the knee joints on both

sides and below the umbilicus on the anterior surface of the abdomen.

How will you assess burns in an adult? [2]

How will you monitor the patient for complications? [3]

Discuss the burns management of this lady. [5]

December 2021

A 25-year-old recently married female is brought with burns after an alleged suicidal attempt.

How do you classify the severity of burns? [3]

How do you evaluate this patient? [2]

How will you management this patient if she has 25% burns? [2]

Discuss fluid therapy in a burns patient. [3]

April 2016

A 20 year old male has suffered deep burns involving front and back of his chest and abdomen 6 hours ago. His weight is 60 kgs.

What is the percentage of his burns?

Give outline of fluid resuscitation for this patient.

Management of his burn wounds.	4+2+4

Compiled by Dr.Vishnu B S Family Medicine Specialist Trivandrum

55





Burns

June 2014

Classify burn injuries

How will you manage a patient with:

Inhalational burns

Electrical burns

June 2013

A 20 years old female presented in emergency with accidental burns six hours ago. Her whole body except both lower limbs and perineum are burnt. Surprisingly she has minimal pain and burnt area is hard and leathery to feel. Briefly describe the methods of assessment of area and depth of burns and calculate her burns. Give outlines of emergency treatment of her burns.

June 2012

A 7 year old child is admitted with 25% scalds on face, neck & chest. How will you manage this case?

Ca Colon

December 2019

Prevention, screening ,clinical features and diagnosis of carcinoma of the colon.

Carcinogen

June 2014

Name any five chemical carcinogens and the predominant tumour associated with each

Cervical lymph-adenopathy

April 2016

A 20 years female presented with cervical lymphadenopathy of six month duration. What are the differential diagnoses? Give outline of relevant investigations. How will you treat the case if diagnosis is tuberculosis?

3+3+4

DVT

June 2020

A 65-year-old female patient presents with pain and swelling in the left thigh since 5 days. There is some local warmth, peripheral pulses are normal.

What are your differential diagnosis in such case?

What investigations would you request, with reasons?

How would you manage deep vein thrombosis? 2+2+6

December 2019

A 25-year -old man presents with pain and swelling of the right lower limb for a day .List the differential diagnosis for his condition. Describe your approach to the evaluation, investigations, diagnosis and management of this

patient.

December 2017

A 50-year-old man comes to you with history of painful swelling of left lower limbs for 4 days duration.

List the differential diagnosis with specific clinical features.

List risk factors of deep vein thrombosis (DVT).

How will you investigate and treat a person with DVT?

Mention how you can prevent DVT

December 2016

A 50 year old man has a confirmed deep vein thrombosis of the right calf after a long flight.

Outline management in detail.

Venous leg ulcer and its management.	5+5





DVT





June 2015

History, physical findings, investigations, management and prevention of deep vein thrombosis.

1+2+2+3+2

December 2014

List the differential diagnosis for unilateral pain and redness of the

leg. Describe risk factors, clinical features, investigations and management of each cause

June 2013

A 25 years old male patient sustained crush injury in his right lower limb. Next day, he developed sudden swelling of the limb, sero-sanguinous discharge from the wound and crepitations in the subcutaneous tissue. Discuss etiopathology of his lesion. How will you investigate him? Give brief outlines of his treatment.

Diabetic ulcer

December 2022

48-year-old Mr. Raman has Type II DM for 2 years, He is on a routine follow up visit to you. You are counselling him with regards to DM.

What are the macrovascular complications of diabetes? [2]

What are the risk factors to develop Diabetic foot? [2]

What relevant foot examination should be performed? [2]

How will you manage diabetic foot ulcers? [2]

How will you prevent foot complications in a diabetic patient? [2]

June 2018

Ravi is a 45-year-old farmer with diabetes mellitus. He has developed an ulcer on his right leg which has persisted over the past one month.

Mention the possible causes of non-healing ulcer in this patient, highlighting the factors that will influence the healing of an ulcer

How will you clinically assess the ulcer?

How can a Family Physician prevent foot ulcers in a diabetic patient?

Role of antibiotics in the management of chronic ulcers.

JUNE 2017

Principles of wound healing. 5+5

How will you improve healing of a foot ulcer in a diabetic patient?

June 2015

A 60 year old diabetic patient presents with ulcer of 2 weeks duration on the left foot, second toe.

Relevant local examination.

Detailed comprehensive management plans for the present visit and at follow up.	4+6

December 2013

A 60 year old diabetic patient has non-healing ulcer on dorsum of right foot.

Discuss pathogenesis of non-healing of ulcer.

How will you treat him?

Dyspepsia

JUNE 2017

A 40 year old man presents to you with dyspepsia for the past 1 month:

List the differential diagnosis and briefly describe clinical features of each.

How will you investigate?

What are the indications for an upper GI scopy for him?	5+3+2





Erectile Dysfunction

December 2017

List the causes of erectile dysfunction (ED).

Mention the clinical and investigatory work-up for ED.

Medical management of ED.

JUNE 2017

Mr. prakash is a 45 year old who complains of erectile dysfunction for the past 2 months.	5+5

How will you assess Mr. Prakash with appropriate history, physical examination and investigations?

Medical management of erectile dysfunction.

Inguinoscrotal swelling

December 2021

A 45-year-old male presented to your clinic with swelling in the right side of scrotum for the past one month. It is associated with occasional dragging pain at the site. There is no change in size of the swelling on lying down.

What are your differential diagnosis? [2]

What are the relevant questions in the history that you will ask? [2]

What are the findings you are going to look for? [2]

How will you investigate this patient? [2]

Briefly describe the management of this patient. [2]

JUNE 2017

A 30 year old labourer presents with a swelling of the left side of the scrotum for the past 2 months.	6+2+2

List the differential diagnosis for this and write briefly on the clinical features of each.

How will you investigate him and what findings are you looking for in the investigations?

Different issues he will face after surgery for hernia repair.

June 2013

What are the inguino-scrotal disorders in a child?

Describe the diagnosis,  differential diagnosis and management of a

case with “Acute Scrotum" in a child.

Hernia

December 2020

A 45-year-old man presents with the history of a swelling in the inguinal region which becomes larger when he coughs or sneezes. a) How would you assess this case? b) What are the steps in the management of this case? 5+5

June 2020

A 65-year-old man needs to undergo a hernia repair. What conditions would you look for in preparation for the anaesthesia? What investigations would you require, with reasons? He has diabetes, hypertension & COPD. How would you prepare him for surgery? 4+3+3

December 2018

A 65-year-old diabetic and hypertensive lady with a BMI of 35 and a HbA1c of 9%, needs elective surgery for incisional hernia in the abdomen.

What advice will you give regarding her co-morbidities prior to undergoing surgery and why?

While trying to achieve the targets above, she develops chest pain which

was diagnosed and treated as an NSTEMI. What advice should be given regarding surgery?





Infections

December 2018

Describe the clinical features, pathogenesis and infecting organism in the following infections:

Fournier’s gangrene.

Gas gangrene.

Necrotizing fasciitis.

Long-standing filarial leg with sudden swelling and redness.

Infection in a laparoscopic port site.

June 2014

Define the following terms:

Infection

SIRS

Sepsis

Severe Sepsis

Septic shock

b) Describe the management outline of septic shock .

December 2011

Enumerate causes of lung abscess. 3+3+4

Give its clinical features and investigation outline.

Drug treatment (dosage and duration) of amoebic liver abscess.

Intercostal Drainage

June 2015

Indications and the procedure of inserting an intercostal chest tube.

2+8

Intestinal obstruction.

April 2016

Plain x-ray findings in a case of intestinal obstruction.

Enumerate causes of paralytic ileus.

Give outlines of management of a case of paralytic ileus.

3+3+4

Jaundice

June 2019

Describe the differentiating clinical features in the different types of jaundice.

How does the ultrasound examination contribute in evaluating jaundiced patients?

What is the role of alkaline phosphatase in evaluating jaundice?

December 2011

Draw diagram depicting causes of obstructive jaundice. 3+3+4

Briefly discuss findings of various investigations suggesting malignant obstructive jaundice.

Outline conservative treatment of benign obstructive jaundice.

Neck Swelling

December 2020

A young man presents to you with a history of a swelling on the left side of his neck. This has been growing in size over the past few days. He says he feels feverish off and on.

a) What is your differential diagnosis? b) How would you assess this case? c) What are the steps in the management of such a swelling? 5+5

December 2017

A 20-year-old girl comes to you with a history of swelling in the anterior neck.

List differential diagnosis with specific clinical features.

What are the red-flags in history and examination? List with reasons.

As a family physician, how will you manage her if she has a solitary nodule in her thyroid gland?





Malena

June 2012

A 60 year old female is admitted with history of malaena:

Enumerate possible causes of malaena at this age.

Discuss clinical approach to diagnosis.

Role of imaging in making diagnosis

Oral lesions

December 2016

Causes and clinical features of:

Oral ulceration

Halitosis

Leukoplakia	6+2+2

Neurosurgery

June 2021

A 60-year-old man who was found unconscious on the road is brought to the community health center that you are working,

Discuss how you will assess him initially and provide the initial care. [7+3]

December 2020

A teenager met with a cycling accident. Bystanders rushed to his aid and found him unresponsive but in a few minutes he recovered and was well enough to take a cab back home. Displaying abundant precaution, his parents have brought him to you.

How would you assess this case? b) What are the steps in the management of head injury in this teenager? 5+5

June 2020

A young man met with an accident. He is opening eyes to painful stimuli, withdraws from pain and makes gurgling sounds. His vitals are as follows: Pulse: 110/min, BP 90/60 mmHg, RR 40/min.

How would you assess this case? b) How would you manage this case now? 5+5

December 2018

A 25-year-old man had sustained a concussion head injury 4 months ago after a motor cycle accident.

List 3 long term problems he could have.

How is consciousness evaluated in a case of acute head injury?

June 2018

A 4-year-old boy is brought by his parents after he hit his head while playing. He slipped and fell on the ground while running following which he had loss of consciousness for less than 30 seconds.

What further history would you ask to assess the child?

What clinical features would you look for?

What are the indications for neuroimaging?

The child is active and otherwise well now. What will you advise the parents?

December 2015

Risk factors, history, physical examination findings, investigations and management of sub-dural hematoma.

2x5

June 2014

Describe the clinical tests used to diagnose brainstem death.

Enumerate strategies employed to overcome the shortage of organs for transplantation.





Paronychia

December 2020

A 50-year-old presents to you with severe pain of his right thumb. On examination, you notice a small dark patch below the nail. He vaguely remembers injuring himself while doing some work in his garden.

What is your differential diagnosis?

What are the steps in the management of this case?

What options of anesthesia are available in case a surgical intervention is required? 2+5+3

June 2018

Clinical features of paronychia.

Outline how you would treat it, including steps of appropriate anaesthesia.

December 2015

List the causes of acute painful lesions of the distal part of the fingers.

How are these managed in primary care?	5+5

June 2015

Clinical features and management of acute paronychia.

Procedure of digital nerve block.	6+4

Nutrition

June 2013

What are the methods of artificial nutritional support by “Enteral Feeding"?

What are the complications of enteral feeding?

Briefly describe the steps of insertion of a nasogastric tube in an adult patient.

Paraumbilical hernia

December 2020

Discuss the management of the Paraumbilical hernia in children (5)

Pilonidal

sinus

June 2020

Pilonidal sinus

Phimosis

December

2020

Discuss the management of Phimosis in children (5)

Paraphimosis

June 2020

Paraphimosis

Perianal Pain

June 2021

A 30-year-old man presents with perianal pain for a day. He also has mild fever. There is no bleeding per rectum or change in bowels. On examination, his BP is 120/ 74 mmHg, pulse rate 104 per minute.

What is the differential diagnosis? [2]

Write briefly on the risk factors, clinical features, investigations and management of perianal abscess. [8]

POVD

December 2012

A 30 year old male with chronic smoking presents with gangrene right big toe.

Enumerate possible physical signs that are likely to be present in this case.

Proposed list of diagnostic investigations.

Various operative options for this patient.





Thyroid

June 2020

A 28-year-old female presents with diffuse swelling in the mid line of neck which moves with deglutition. She also has bilateral prominent eyes.

a) Discuss the differential diagnosis in such case. b) What investigations will you do and what do you expect in her? c) What are all the various treatment options available to her? 3+3+4

December 2019

A 40- year-old woman presents with a long standing goiter of 10 years duration. She has recently noticed an increase in size and some difficulty in swallowing. How will you evaluate and investigate this patient? How will you

plan the treatment for this patient?

December 2018

A 65-year-old man is found to have a 2X2 cm asymptomatic lump in the right lobe of the thyroid.

What is the approach to his management?

What is the diagnosis and management if there are multiple nodules in a 45-year-old lady who has atrial fibrillation and is losing weight.?

December 2015

A 14 year old girl is brought by her mother for a thyroid swelling noticed by her 2 weeks ago. Discuss your approach in the following situations:

Smooth diffuse thyroid enlargement	b) Solitary nodule.	5+5

December 2013

A 25 year lady having bilateral prominent eyes with a diffuse swelling in midline of neck which moves on deglutition.

Discuss differential diagnosis of this case.

Suggest investigations for diagnosing the case.

What treatment options are available?

December 2012

A 35 year old pregnant female presents with symptoms of hyperthyroidism.

What investigations are proposed?

Discuss plan of management.

Scrotal Pain

December 2014

A 15 year old boy is brought to you with acute onset of pain and tenderness of the right testis. Discuss the differential diagnosis and their management.

December 2018

A 10-year-old boy is brought by his mother because of severe scrotal pain.

List 4 possible causes.

What action will you take and why?

Scrotal Swelling

June 2012

Differential diagnosis of acutely swollen scrotum.

Appropriate investigations with possible findings of investigation.

Management approach of such cases.





Trauma

June 2014

What are the “ ABCs” of primary survey in a patient who has sustained trauma in a road side accident?

Enumerate the immediately life-threatening injuries to be identified during a primary survey .

December 2013

A 40 year old male is brought in a state of shock after sustaining road traffic injury.

How will you manage shock?

Investigations to establish exact injury.

Suppose spleen is shattered, what is the treatment?

Complications of splenectomy

June 2012

Glasgow Coma Scale

Triage

Golden hour

Black eye

December 2011

What is Glasgow Coma Index( GCl)? 4+3+3

Indications of CT scan in head injury.

Briefly discuss bilateral black eye.

December 2011

First Aid in: 2+2+2+2+2

Suspected fracture of cervical spine

Tension pneumothorax

Flail chest

Compound fracture- Right leg(both bones)

What is Golden hour?

June 2019

A 20-year-old man is brought unconscious to your CHC after he was allegedly hit by a truck. His blood pressure is 90/70 mm Hg.

How will you rapidly assess the patient?

What management will you institute immediately?

What precautions should be taken during transportation of this patient?

JUNE 2017

You happen to be near the site of a road traffic accident where a cyclist was hit by a car. The cyclist is lying injured on the road. How you will assess the patient, provide first aid and transfer the patient to a hospital?

4+4+2

Surgical Complications

June 2014

Enumerate the complications of :

Cholecystectomy

Bariatric surgery

Groin hernia repair

PCNL (Percutaneous Nephrolithotomy)

Circumcision





Ulcer

June 2020

A 62-year-old man, a known diabetic for the past 15 years, presents to you with a non-healing ulcer over dorsum of left foot for the past 2 months.

a) What are all the various tests you will do on this patient? b) How will you manage his wound? c) As a Family Physician, how will you prevent occurrence of another ulcer in the future. 3+4+3

December 2017

Differentiate between arterial, venous and neuropathic ulcers.

How will you investigate a person with ulcers in the lower leg?

List the principles of management of bed sores.

December 2015

A 45 year old farmer presents to you with an ulcer on his foot for 2 weeks.

Outline the factors that affect the healing of ulcer.

Clinical features and management of venous ulcers.	3+3+4

Prostate

June 2020

A 60-year-old man presents with a history of inability to pass urine. On examination you find that he has unbearable supra-pubic tenderness.

What is your differential diagnosis?

How would you assess this case?

What are the steps in the management of this case? 2+4+4

June 2019

Clinical  features,  investigations  and  management  of  benign  prostatic

hypertrophy.

December 2016

A 55 year old asymptomatic man was discovered to have gross prostatomegaly with post-void residue of 45ml on routine ultrasound abdomen at a master health check up.

What is the pathophysiology?

What is the best management at this stage and when should referral be made?

Pros and cons of routine PSA testing

December 2014

Describe history, clinical features, investigations and management of benign prostate hypertrophy at the primary care level. Indicate reasons

for referral.

December 2012

Signs and symptoms of benign enlargement of the prostate (BEP).

Diagnostic investigations of BEP.

Drug treatment of BEP.

June 2012

Drug treatment of BEP (Benign Enlargement of Prostate).

Preoperative preparation of a diabetic patient (45 years male, type II) proposed for laparoscopic cholecystectomy.

Urology-Hematuria

December 2017

A 45-year-old peri-menopause lady comes to you with history of brown coloured urine. Her urine dipstick examination shows presence of ‘4+’ blood.

List the causes of hematuria.

What are the red-flags you will elicit in her?

How will you manage her with appropriate referral after preliminary investigations?





Urinary retension

December 2020

A 60-year-old man presents with a history of inability to pass urine. On examination you find that he has unbearable supra-pubic tenderness.

What is your differential diagnosis?

How would you assess this case?

What are the steps in the management of this case? 2+4+4

December 2019

A 65-year-old man presents with urinary retention to the emergency room. What are the differential diagnoses ? How will you proceed with the evaluation and management of this patient?

April 2016

Enumerate causes of acute retention of urine.

Steps of urethral catheterization in a 60 year old male.

Enumerate complications of urethral catheterization.	3+4+3

December 2013

A 30 year young male has difficulty in urination. The urinary stream is weak and improves on exertion. There is past history of pus discharge per urethra 1!4 years ago.

What is the etiopathogenesis of the case?

What investigations are required to be done for him?

What is the complete treatment?

Urinary Incontinence

June 2022

70 years old female, diabetic, strict vegetarian who is a mother of 5 children presented with history of dribbling of urine:

Mention the types of urinary incontinence. [3]

What are the possible aetiological factors in the case scenario given above? [3]

As a family physician, how will you manage this case. [4]

Varicose Veins

June 2022

A 40 year old lady came with dilated and tortuous veins over lower portion of her left leg. Discuss the following:

Anatomy of venous system of lower limb. [3]

Clinical features of varicose vein. [3]

Prevention and management of varicose vein. [4]

December 2020

A 55-year-old bus conductor presents to you with a history of heaviness of the legs, pain while walking and itching above the left ankle.

How would you assess this case?

What are the steps in the management of varicose ulcer? 5+5

















ORTHOPEDICS





ACL tear

December 2014

Describe history, clinical features, investigations and management of anterior cruciate ligament rupture of the knee.

Backache

December 2022

23-year-old Sweta presented to your Outpatient department with history of lowback ache, and more recently with right leg pain, this is her fourth visit in last 8 weeks.

What is the etiopathology of lumbosacral radiculopathy? [2]

What are your differential diagnosis and patients with what diagnosis need urgent diagnostic evaluation? [3]

What is the clinical presentation according to level of nerve root involvement? [2]

What will be your approach to the management of this patient? [3]

December 2020

A middle aged tailor working in a factory presents with a history of low backache.

How would you assess the case?

How can low backache due to such occupations be prevented?

How can this patient be managed? 3+3+4

December 2019

A 70-year-old lady presents with low backache for the past 3 days. List the red flags you would seek in the history.

Write briefly on the physical examination and investigations with reason for each, to assess her .

Clavicle

Fracture

December 2012

Describe briefly on Fracture clavicle

Colles

Fracture

December 2021

What are the components of injury in a patient who sustained Colle’s fracture?

Describe the clinical features. [5]

Discuss the immediate and long-term management of a 70 year old post-menopausal woman with Colle's fracture. [5]

June 2019

A 65-year-old lady is brought to you with history of pain and swelling of the left wrist after falling in the bathroom.

Describe briefly the clinical features, investigations and management.

Discuss the further assessment and management to prevent recurrences.

December 2014

Define Colle’s fracture.

Describe its clinical features and management

Carpal Tunnel Syndrome

December 2015

Clinical features, risk factors, investigations and management of carpal tunnel syndrome.	3+2+2+3



A 40-year-old autorikshaw driver presents to you with tingling, numbness and ache of the right wrist and palm.

Write short notes on the risk factors for carpal tunnel syndrome. What are its clinical features?

What investigations would be considered in this patient? How is this condition treated? [2+4+2+2]





Elbow Pain

June 2018

A 35-year-old car mechanic has come to you with pain of the right elbow for the past 10 days. He does not have history of any trauma. You suspect that he has lateral epicondylitis.

Discuss the cause, history and clinical features of lateral epicondylitis.

How will you manage this patient?

Write briefly on the causes and management of aches and pains in a patient like him.

June 2015

Aetiology, relevant signs and treatment of pain of 10 days duration in the elbow.	4+4+2

Entrapment Neuropathy

June 2019

What are the symptoms of entrapment neuropathies?

What are the predisposing causes of entrapment at the wrist?

List the medical and surgical management.

Foot pain

December 2015

History, physical examination findings and management of chronic pain in different parts of the foot.	3+3+4

Frozen Shoulder

April 2016

What are the causes of frozen shoulder?	2+(3+2+3)

Clinical features, investigations and treatment of frozen shoulder

Ganglion cyst

June 2021

Clinical features and management of ganglion cyst. [10]

Heel pain

JUNE 2017

A 42 year old executive presents with pain of the right heel for the past 2 weeks.

List the differential diagnoses.

History, physical examination findings and management of plantar fasciitis.	2+8



December 2021

A 60-year-old woman has come to you with complaints of pain and swelling of her right knee joint for past one week. She has difficulty in walking and in her activities of daily life. Other joints are not involved.

What are the possible causes of her knee joint pain and swelling? How will you confirm your diagnosis? [4]

What are indications of referring this lady for surgical management? [2]

Discuss the management of Osteoarthritis of the knee joint. [4]

Knee Pain

December 2020

A 70-year-old lady presents to you with history of a fall. She complains of radiating pain to the knee and the inability to put her foot down.

How would you assess this case?

What are the steps in the management of this case? 5+5

June 2020

A 64-year-old man presents to you with complaints of bilateral knee pain for last few years. He is increasingly incapacitated now because of the pain and difficulty walking.

What are your differential diagnosis?

What medicines would you give for pain relief?

What other modalities of pain relief would you suggest?

In osteoarthritis knee, what are the indications for surgery? 2.5x4

Compiled by Dr.Vishnu B S Family Medicine Specialist Trivandrum

69





Neck of Femur Fracture

December 2022

Mrs. Varalakshmi had a fall in the bathroom and is unable to move her right leg and not able to bear weight. She has tenderness over the right leg anterior aspect.

Describe the principles in management of fractures with a special mention about fracture of the lower limbs. [6]

What are the early and late complications? [4]

December 2013

A 60 year old male has sustained fracture neck femur.

What is the first aid treatment?

Discuss various treatment options.

Neck Pain

June 2019

Prakash is a 55-year-old labourer who presents with neck pain and right arm pain for 1 week.

State the differential diagnosis, with clinical features for each.

Investigations to assess his condition.

Role of physical therapy modalities in each diagnosis.

June 2018

A 25-year-old headload worker is brought to your clinic as the heavy sack that he was carrying on his head slipped and hit his neck causing him to have severe pain of the neck

List the causes of neck pain that you would consider.

What history and clinical signs would you elicit?

You elicit severe tenderness of the cervical vertebrae. How will you manage this patient?

JUNE 2017

A 45 year old man comes to you with neck pain after going to the gym in the morning. Outline clinical features and management of cervical disc prolapse.	5+5

Non Union

June 2012

Non-union of fracture of humerus bone

Osteo-arthritis Knee

June 2022

What is the pathogenesis of osteo-arthritis (OA)?

What are the common joints involved, their symptoms, clinical features of osteo-arthritis?

Outline the relevant investigations and management of OA. [2+4+4]

JUNE 2017

Non-surgical management of osteoarthritis of the knee.

10

June 2015

History, physical findings, investigations and management of osteoarthritis of the knee.	2+2+2+4

Osteo-myelitis

December 2019

A 35-year-old man gives a history of penetrating trauma to the right leg with a piece of wood about 6 months back. This was followed a few weeks later by a small wound which has failed to heal and continues to have recurrent discharge. The overlying skin shows scarring and fixity to the underlying bone. What is your presumptive diagnosis ? What investigations will you do to confirm your diagnosis? How will you treat this patient?

Compiled by Dr.Vishnu B S Family Medicine Specialist Trivandrum

70





Osteoporosis

December 2016

How is osteoporosis diagnosed?

State the risk factors for osteoporosis.

Management of osteoporosis.	4+4+2

Pathological Fracture

June 2014

Define pathological fracture.

Give an outline of diagnosis and management of pathological fractures.

Plaster of Paris

December 2012

Describe briefly on Plaster of Paris

Septic Arthritis

December 2016

Clinical features, differential diagnosis, investigations and management of septic arthritis of the hip in children.

3+2+2+3

Shoulder pain

June 2021

A 55-year-old man with history of diabetes presents to you with pain of this left shoulder for the past 2 months.

List the differential diagnosis. [2]

Outline the clinical features, investigations and management of periarthritis of shoulder. [8]

December 2019

A 45-year-old labourer presents with pain of the left shoulder for the past few days.

List the differential diagnosis.

Write briefly on the clinical features, Investigations and management of periarthritis of shoulder.

December 2017

A 35-year-old male presents to you with a history of shoulder pain for the last one week.

What are the red-flags in history and in examination with reasons?

How will you manage a person with adhesive capsulitis?

December 2014

List the causes for unilateral shoulder pain. State the treatment for each.

Splints

December 2013

Discuss various splints and their uses .

December 2012

Describe various splints and their role in emergency room in orthopedic

trauma .

Sports Injuies

December 2016

Diagnostic features and management of the following sports related injuries:

Ankle sprain

Achilles tendon rupture.	5+5

Volkmann

ischaemic contracture

June 2012

Volkmann ischaemic contracture.

Plantar Fasciitis

June 2022

Describe the anatomy, clinical features and management of plantar fasciitis. How can plantar fasciitis be prevented? [(3+3)+4]

















ENT





Acute otitis Externa

June 2021

Write short notes on otitis externa. [10]

June 2019

Clinical features and management of acute otitis externa.

June 2015

Clinical features and management of otitis externa.

3+7

December

2014

Describe etiology, clinical features and management of otitis externa.

Acute otitis media

June 2022

10-year-old girl presented with purulent right ear discharge for last 3 days. She had similar complaints in the past on the same side.

Describe in detail about clinical features, examination findings, investigations, treatment and complications of this condition. [2+2+2+2+2]

December 2021

A 30-year-old male comes with purulent discharge from left ear for the past two months.

Mention the types of otitis media and the causes for it. [3]

How would you manage this patient immediately and on long-term? [3]

What are the complications of otitis media? [2]

What are the indications of referral for surgical management in this patient? [2]

June 2018

History, clinical features and management of acute otitis media in children

JUNE 2017

Clinical features and management of acute otitis media in children.

10

Allergic Rhinitis

JUNE 2017

Clinical features and management of allergic rhinitis.	5+5

Bell’s Palsy

December 2021

A 50-year-old male with uncontrolled diabetes comes with severe pain in right ear associated with lower motor neuron (LMN) facial palsy on that side.

Mention the possible causes and clinical features of LMN facial palsy in this patient. [4]

How do you manage this patient? [4]

Explain anatomy and functions of facial nerve. [2]

June 2014

a ) What is Bell’s palsy? What findings are you likely to get on doing an otological examination in a patient of Bell’s palsy? What is the management?

b) Describe the clinical features suggestive of malignant change in a benign parotid tumour.

Ear pain

December 2016

List the causes of ear pain with otorrhoea.	5

Foreign body ear

June 2012

Management of impacted foreign body in ear canal of a 2 year old child.





Chronic Ear discharge

December 2022

15-year-old Sridhar presented to your OPD with history of profuse right ear discharge for 6 weeks?

What is your diagnosis? What are the salient features? [2]

What are the risk factors? Mention four common pathogens causing this condition? [3]

What are the complications of this condition? [3]

How will you manage this condition? [2]

June 2020

You have diagnosed a 10-year-old girl to have safe chronic suppurative otitis media.

Write the clinical features, examination findings, investigations, treatment and complications of CSOM in such case. 2+2+2+2+2

December 2018

An 18-year-old boy has been seeing the family physician for several years for chronic ear discharge, with no serious complications.

State the likely diagnosis, and what are the otoscopic findings likely to be?

Another patient with ear discharge develops high fever, headache and loss of consciousness.

What type of ear infection is he likely to have?

Describe the otoscopic findings and the complication seen.

June 2015

History, physical examination findings and management of safe chronic supportive otitis media 2+3+5

Hearing Loss

June 2019

A 30-year-old man comes to you with reduced hearing of his right ear. Examination reveals wax in the ear.

Discuss the management.

Vertigo

December 2019

A 20- year-old man is brought with acute onset of vertigo.

Write briefly on the differential diagnosis and assessment including history and physical examination.

How will you manage benign paroxysmal positional vertigo?

December 2017

A 55-year-old female labourer comes to you with complaints of giddiness.

What are the red-flags you will elicit from her and why?

How will you investigate her?

How will you diagnose and treat benign positional vertigo?

December 2014

Describe the history, clinical features and management of benign paroxysmal positional vertigo

Foregn body nose

June 2013

A 10 years old child presents with history of accidental inhalation of foreign body.

Enumerate various foreign bodies commonly inhaled by a child. How will you diagnose and manage this child?





Epistaxis

December 2018

List the causes of epistaxis.

What points in the history and physical examination will be helpful in diagnosis?

December 2016

Management of epistaxis in a 50 year old man with blood pressure 220/100mmHg. (5)

December 2015

A 6 year old child is brought to you with episodes of epistaxis from his right nostril.

Describe briefly the history, physical examination, investigations and management of this child.

Management of acute epistaxis in Family Practice.	5+5

December 2011

Discuss causes investigations and treatment of Epistaxis 3+ 2+5

December 2013

A 30 year old male presents in ENT OPD with recurrent massive bleeding through nose.

Discuss differential diagnosis.

What investigations are required?

Discuss complete treatment.

June 2013

What is epistaxis?

What are the causes of epistaxis in a 60 years old man? How you will investigate him and manage?

December 2012

A 60 year old male presents with epistaxis (bleeding nose).

Enumerate possible causes for this.

Investigations proposed to establish cause of bleeding

Emergency measures to control bleeding in this patient.

June 2012

Differential diagnosis of epistaxis.

Mucormycosis

June 2021

Write short note on the risk factors, clinical features, investigations and management of rhino-orbital mucormycosis. [2+3+2+3]

Nasal Bone #

December 2012

Nasal fracture sustained after fall.

Nasal Discharge

June 2018

A 6-year-old child is brought to you with history of nasal discharge for the past 2 weeks. What would be the clinical features for:

Allergic rhinitis

Sinusitis

Foreign body in the nose

CSF rhinorrhea

How will you manage moderate to severe allergic rhinitis in this child?

Nasal polyps.

June 2012

Nasal polyps.





Dysphagia

December 2013

A 56 year old male has difficulty in swallowing food for last 6 month which is progressively worsening. He gives history of significant loss of weight.

Discuss the differential diagnosis.

Discuss investigations and various treatment options.

Pharyngitis

December 2015

5 year child is brought to you with history of high grade fever and sore throat for one day.

Differential diagnosis with clinical findings for each.

What will you suspect if inspiratory stridor is noted? Discuss the management.	7+3

Tonsils

April 2016

Define quinsy.

Enumerate indications of tonsillectomy.

Give outlines of complications of tonsillectomy and their management.	2+3+5

December

2012

Quinsy

Tracheostomy

December 2011

Indications care and complications of tracheostomy. 3+3+4



















OPHTHALMOLOGY





Cataract

December 2013

A relatively young patient of 40 years presents with cataract right eye.

Discuss differential diagnosis.

What are various treatment options?

June 2012

What are the various types of cataract?

How will you differentiate these cataracts?

What are the steps involved in mature cataract surgery?

Corneal Ulcer

June 2022

35-year-old Devi, an agricultural worker, mother of two children, has come to the out-patient clinic with history of pain and discharge from Right eye associated with blurring of vision since she returned from the field. The right eye is red, and the cornea has haziness.

List any THREE possible differential diagnosis. [3]

How will you manage Mrs. Devi, if she refuses referral to eye doctor in the next town, as she need to take care of the two children? [7]

June 2015

Symptoms, signs and management of bacterial infective corneal ulcer.	2+2+6

Eyeball

June 2012

Eye signs in Grave’s disease

Proptosis of eye ball

Iridectomy.

Eyelid swelling

December 2018

A 25-year-old lady notices a small smooth painless lump under the upper eyelid.

State the diagnosis and pathogenesis and treatment.

State the diagnosis of a painful acute swelling at the free border of the eyelid and the treatment.

What is the likely diagnosis of a swelling on the lateral upper aspect of the orbit? What are the causes?

December 2012

Write short notes on:

Chalazion

Stye

Narrow angle glaucoma

June 2018

Classification, clinical features and management of blepharitis.

JUNE 2017

A 20 year old lady presents to you with swelling of the right eyelid for the past 2 days.

List the differential diagnosis and write briefly on the clinical features of each.

Management of blepharitis.	7+3





Diabetic Retinopathy

June 2022

Describe the possible ophthalmic complications of diabetes. Explain about stages of diabetic retinopathy and its management options available to the ophthalmologist. [5+(3+2)]

December 2019

Describe the clinical features of diabetic retinopathy.

What is the role of the family physician for prevention and management ? What is the significance of diagnosing retinopathy in a diabetic patient?

December 2016

State the guidelines for screening for eye involvement in diabetes mellitus.

Stages of diabetic retinopathy and management at each stage.

6+4

Glaucoma

December 2012

Write short notes on: Narrow angle glaucoma

Red eye

December 2021

A 30-year-old female comes with redness, pain and watering in the right eye. She has weight loss and polyarthralgia on enquiry.

Mention two possible causes of red eye in this patient. [2]

Mention the differential diagnosis of red eye. [2]

How do you evaluate a patient with red eye? [3]

Write briefly on acute viral conjunctivitis and bacterial conjunctivitis. [3]

June 2019

Discuss the differential diagnosis for a patient presenting to you with unilateral painful red eye.

Outline briefly the clinical features and management of each.

December 2017

List the causes of a person presenting with a ‘red-eye’.

What are the red-flags and their causes for urgent referral to an ophthalmologist?

Describe briefly management of corneal ulcer

December 2014

Describe the causes for unilateral red eye

June 2014

What is the clinical significance of a painful eye with IIIrd nerve palsy ?

Enumerate the causes of acute red eye.

What are the presenting features of acute glaucoma? Describe the treatment strategies in managing acute glaucoma.

June 2013

Acute red eye - Its causes and treatment.

Inflammatory diseases - eyelids.

December 2015

Clinical features and management of inflammatory diseases of the eyelids.	5+5





Lasers

June 2013

Lasers in ophthalmology.

Periorbital Swelling

April 2016

Enumerate causes of periorbital swelling.

Clinical features, diagnosis and treatment of external angular dermoid.	3+(3+2+2)

Retinal vein occlusion

June 2021

Risk factors, clinical features, differential diagnosis, investigations and management of central retinal vein occlusion. [2+2+2+2+2]

Trachoma

December 2011

Etiology, clinical features, treatment and complications of Trachoma 2+2+3+3

Vision loss

December 2016

Causes of sudden onset unilateral blindness in a 30 year old lady.

List visual field defects and state the causes.

June 2013

Painless loss of vision and its causes.

















ANAESTHESIA





Pre Anaesthetic Check up

December 2017

You have been requested to do a pre-anesthetic work-up of a 60-year-old patient going for a hernioplasty.

Mention the clinical and investigatory work-up you will do with reasons.

What are the complications of spinal anesthesia? How can you prevent them?

Post op Anaesthesia

December 2013

Post-operative care after right adrenelectomy for Pheochromocytoma

Post Op pain

June 2014

What are the various techniques of pain relief management in the post-operative period?

Enumerate the advantages of using local anaesthetic techniques for pain relief in a post-operative patient

Types of Anaesthesia

Anaesthesia December 2016

Definition and role of the following forms of anaesthesia in surgery:

Conscious sedation.

Spinal anaesthesia

Epidural analgesia

Nerve block

Local Anaesthesia

April 2016

Enumerate commonly used local anaesthesia techniques.

Enumerate various local anaesthetic drugs.

How will you manage pain following multiple rib fractures due to chest trauma in a young male? 3+2+5

December 2013

Local anaesthesia for right inguinal hernia operation in a 50 year old male

June 2013

Enumerate various local anesthetic drugs. Briefly describe the dose limit, concentration and complications of lignocaine used for local anesthesia. What are the advantages and contraindications of adding adrenaline to local anesthetic drug?

Spinal Anaesthesia

December 2022

A 23-year-old Mrs. Renuka is being posted for emergency section for failed induction.

Explain the clinical anatomy for spinal anesthesia with a diagram. [3]

Discuss the pharmacological features of Bupivacaine used for spinal anesthesia. [3]

What are the indications, contraindications, and complications of spinal anesthesia? [4]

Regional Anaesthesia

June 2020

A 41-year-old man presents with history of trauma in the palm after a road traffic accident. He has no other injuries.

What first aid would you give him?

What regional anaesthesia would you like to give? What nerves and where would you block them, if he requires minor surgery?

What are the local anaesthetic drugs you can use for a peripheral nerve block?

What precautions would you take while doing a peripheral nerve block?

2+3+2+3





Anaesthesia

December 2012

Write brief notes on:

Caudal anesthesia

Succinylcholine

Ketamine Anaesthesia

December 2019

Describe the indications and use of ketamine anaesthesia. What are the common complication and how can they be prevented or managed?

Muscle relaxants

June 2012

Muscle relaxants in anaesthesia.

Xylocaine toxicity.

Nerve Block

December 2021

Mention the types of peripheral nerve block. [4]

Mention the contraindications& complications of peripheral nerve block. [3]

Explain the relevant anatomy and procedure of ankle block. [3]

Ankle Block

June 2022

Describe briefly the clinical anatomy, indications, contra-indications and complications of ankle block. How will you do the procedure? [8+2]









OBSTETRICS &

GYNECOLOGY

Compiled by Dr.Vishnu B S Family Medicine Specialist Trivandrum

87







Adolescent health

December 2020

A 16-year-old girl visits your clinic and confides in you that she and her boyfriend have indulged in penetrative sex a few times.

What are the possible consequences of sexual contact at this age?

How and what would be the content of your advice to the young girl? 5+5

April 2016

Enumerate the health problems in adolescent girls.

Management of menorrhagia in an adolescent of 16 years.	2+8

June 2013

Enumerate the various health problems faced by the adolescents.

As a Family Physician, how will you address health issues of adolescent attending your clinic.

Name some Government programs that are initiated to help the adolescents and the benefits they get out of them

Abortion

December 2021

A 20 year old lady, married 6 months back, now came with amenorrhea of 2 months duration and bleeding per vaginum since morning.

Mention the possible differential diagnoses? [2]

Mention the clinical findings and investigations needed for evaluation of this lady to confirm the diagnosis. [3]

Briefly describe the management of each of your differential diagnoses? [3]

How will you counsel and follow-up this woman after treatment? [2]

December 2019

Describe the causes, evaluation, and management of bleeding in the first trimester of pregnancy.

December 2017

Mrs. Rani, a 31-year-old, gravida 4, Para 0, Abortion 3, Live 0, has come for evaluation. She has no reported medical problems and no surgeries. All her abortions were in the second trimester.

What are the causes of second trimester abortion?

If her abortions have been painless and with live foetus, what is the likely cause?

How can we confirm the diagnosis?

How can we treat this condition?

June 2014

Enlist common causes of haemorrhage in early pregnancy.

How will you differentiate between threatened and inevitable abortion?

Discuss the management of threatened abortion in first trimester.

June 2012

Define abortion.

Briefly describe emergency contraception.

Discuss salient features of MTP Act

Antenatal screening

December 2015

The role of the Family Physician in antenatal screening.	10





Anaemia in Pregnancy

June 2018

Prevention, complications and management of anaemia in pregnancy.

3+4+3

JUNE 2017

Causes, prevention, complications and management of anaemia in pregnancy.

2+2+3+3

June 2013

How do you classify anemia?

Discuss the laboratory evaluation of anemia.

How will you manage iron deficiency anemia in pregnancy?

December 2012

What is anemia of pregnancy? Enumerate its common causes.

Discuss domiciliary management of mild to moderate anemia.

Cancers in women.

June 2012

Enumerate common cancers in women.

Write in brief about the guidelines for conducting Pap smear examination.

Classify cervical cancer.

CA Cervix Screening

June 2022

Enumerate prevention and screening for cervical cancer. [10]

June 2021

Discuss the methods of cervical cancer screening. [10]

December 2011

How a case of cervical cancer can be diagnosed? 3+3+4

What are risk factors for cervical cancer?

How can you prevent and control cancer cervix in India?

Dysmenorrhoea

June 2020

A 35-year-old lady presents with dysmenorrhea for the past 3 months. What could be causes of primary and secondary dysmenorrhea?

Discuss the diagnosis and the initial management of dysmenorrhoea in this lady.

December 2014

Classify dysmenorrhea.

Discuss its clinical features, investigations and management .

June 2013

What is dysmenorrhoea?

Discuss its etiology, clinical features and management.

Drugs in Pregnancy

June 2015

General principles of prescribing medicines in pregnant women.

Write at least one drug you can use safety in first trimester of pregnancy and one drug to be avoided for the following conditions:

Urinary tract infection

Mechanical low back pain

Acute bronchitis

Hyperemesis gravidarum	6+4





Abnormal Uterine Bleeding.

December 2022

A 45 year old School teacher presented with history of irregular bleeding per vaginum for the past two months. She also expressed her concern regarding need for frequent change of sanitary napkins.

What are the possible causes for her problems? [2]

Explain the clinical evaluation of abnormal uterine bleeding in a woman of her age? [5]

How will you manage abnormal uterine bleeding in her? [3]

June 2022

45-year-old Mrs. Geetha presented to outpatient department with history of heavy menstrual bleed for past 3 months during her cycles, occasionally she gave history of intermenstrual bleeding also:

What are the causes of abnormal uterine bleeding? [2]

What other history will you take and examination will you perform in Mrs. Geetha? [2]

How will you manage Abnormal uterine bleed (Investigation and treatment)? [4]

When will you refer her to a specialist? [2]

June 2018

A 45-year-old lady comes to consult you for heavy menstrual bleeding.

List the conditions that can cause this.

How will you arrive at a clinical diagnosis, evaluate her and manage her? 3+7

December 2016

Rekha is a 45 year old lady who presents with intermenstrual bleeding for the past few months. Write the relevant clinical history, physical examination and investigations to assess her.	3+3+4

June 2012

Define dysfunctional uterine bleeding.

Write in brief clinical and laboratory examination needed to be done for a case of dysfunction uterine bleeding (DUB).

What are its treatment modalities?

Contraception

December 2022

Various methods of temporary contraception. [5]

Emergency contraception. [5]

December 2020

A newly married couple comes to you for advice on delaying pregnancy.

Discuss the options that you will provide them.?

Describe Natural Family Planning methods. 6+4

June 2020

Name the broad groups of contraceptives available and give examples.

What are the advantages and disadvantages of intrauterine contraceptive devices.

What are the advantages and disadvantages or contraindications of combined oral contraceptive pills?

December 2019

A 19-year-old college student comes to your clinic as she had unprotected sex the previous night and is worried that she would get pregnant.

How can pregnancy be prevented in this patient? What advice would you give with regard to safe sex?

Compiled by Dr.Vishnu B S Family Medicine Specialist Trivandrum

90





Contraception

June 2019

Describe the mode of action of intra-uterine contraceptive devices (IUCD).

Discuss the optimum timing of insertion of IUCD.

June 2018

A 23-year-old newly married lady comes to you to discuss about the use of oral contraceptive pills. Describe briefly how you would explain to her about the use of the pill including the:

Mechanism of action

Pros and cons of using the pill

Dosage schedule

Contraindications

Complications.	1+3+2+2+2

December 2016

List the various types of oral contraceptives.

Which is the most suitable oral contraceptive for a 40 year old woman who smokes?

List major drug interactions which will alter efficacy of oral contraceptives.

3+3+4

June 2015

25 year old working woman with a pervious history of dysmenorrhea and menorrhagia seeks contraceptive advice before her marriage in 2 month time.

List all contraceptive methods available.	6+4

Which method is suitable / to be avoided in this patient? Give reasons.

December 2015

18 year old student comes to you after having unprotected sex the previous right. She is concerned that she would become pregnant. Last menstrual period was 15 days ago.

Describe briefly emergency contraception giving an outline of indications and methods.

What advice would you give her about unprotected sex?	6+4

December 2014

Describe the advantages, contraindications and complications of intra-uterine contraceptive devices.

June 2013

What is a contraceptive method?

Give the broad groups of contraceptives. Enumerate second generation lUDs.

What is the mechanism of action of lUDs? Discuss the effectiveness of lUDs.

What is emergency contraception?

December 2012

Define contraceptives.

List and classify contraceptives used in family welfare programme in India. Write and discuss the options available for a nursing mother with a 5 month old infant.





Antenatal care

December 2013

Briefly describe the objectives of antenatal care .

What advice and preventive services need to be provided to a pregnant female?

What specific health protection measures are provided to such a female ?

December 2012

What do you understand by antenatal care?

List domains of care that must be provided in sub-centre settings. What health education would you provide to such a lady?

Acute

Abdomen in pregnancy

June 2021

A 27-year-old lady who is 8 weeks pregnant, presents to you with acute

pain of the abdomen. a) Discuss the differential diagnosis. [7] b) How will you investigate the cause of the pain? [3]

IUGR

December 2013

Define intra -uterine growth restriction (IUGR). What are the causes of

IUGR? What is the management protocol?

Dyspareunia

December 2021

Aetiology and assessment of dyspareunia. [5+5]

Bartholin’s

Cyst

December 2021

Clinical features and management of Bartholin’s cyst. [5+5]

Ectopic Pregnancy

June 2013

What are the common sites of tubal pregnancy? What are its risk factors?

Discuss the clinical features and management of tubal pregnancy?

Essential obstetric care

June 2013

Discuss the components of essential and emergency obstetric care. What is Janani-Shishu Suraksha Karyakram (JSSK)?

What facilities are provided under JSSK?

December 2011

What is essential obstetric care? 3+3+4

Enumerate components of FRUs.

How it is helpful in reducing maternal mortality?

Hazards in pregnancy

December 2016

Hazards of the following in pregnancy:

Smoking

Alcohol consumption

Asymptomatic bacteriuria	4+2+4

Health information

December 2013

What are the health information needs of a newlywed working woman?

How would you counsel a newlywed working woman who reports domestic violence ?

How can domestic violence be prevented?

High risk pregnancy

JUNE 2017

High risk pregnancy and the role of the family physician in early detection and management of high risk pregnancy.	5+5

Hyperemesis gravidarum

December 2012

What is hyperemesis gravidarum?

How would you differentiate it from morning sickness? Discuss the management of hyperemesis gravidarum.





Infections in a women

Vaginal discharge

June 2022

35-year old sexually active lady presents to you with vaginal discharge.

Briefly describe the differential diagnosis with their clinical features. [5]

WHO syndromic approach to sexually acquired infections. [5]

December 2021

A 55-year-old lady comes with vaginal discharge.

Describe the procedure of doing Pap’s test. [5]

Cervical cancer screening. [5]

June 2020

35-year-old married woman has come to you with history of profuse vaginal discharge. (2+2+2)+(2+2)

How will you take history, do examination and investigate her?

Name 2 common conditions that causes pathological vaginal discharge and how will you treat them.

June 2019

A 24-year-old sexually active lady complaints of white discharge per vaginum.

Describe the WHO syndromic approach in this patient.

Investigations to assess her problem.

Management of the condition.

December 2017

Mrs. Pooja, a 20 year old came to the OPD with intense pruritic vaginal discharge and dysuria.

What details of history will you ask in your diagnostic work-up? Mention reasons for each.

What investigation will you perform?

How will you treat:  i. Trichomonas vaginitis.	ii. Candidal vaginitis

April 2016

What is syndromic approach in reproduction tract infection management?

Merits and demerits of this approach.	6+4

December 2015

A 30 year old sexually active lady presents to you with vaginal discharge.

Describe briefly the differential diagnosis with their clinical features.

WHO syndromic approach to sexually acquired infections.	5+5

June 2014

What is syndromic approach in management of reproductive tract infections?

Discuss the merits and demerits of this approach.

June 2013

A woman reports with purulent vaginal discharge.

What are the causes of such a discharge?

What relevant history, examination and investigations are required for this patient?

Discuss the management of such a case.

June 2012

Define Reproductive Tract Infections(RTIs).

Write in brief syndromic management of RTIs.

December 2011

What is syndromic approach? 2+4+4

What are its merits and demerits?

How it is implemented in health care set up?





HIV

December 2011

What are the objectives of PMTCT in HIV/AIDS? 3+3+4

What are its components?

How is it implemented?

PID

June 2018

Clinical features and management of pelvic inflammatory disease.	5+5

JUNE 2017

A 30 year old lady presents with pain of the right iliac fossa for the past few hours:

Outline the differential diagnosis.

Assessment of this patient with appropriate history, physical examination and investigations. 5+5

December 2015

30 year old woman presents to you with acute pain of the right iliac fossa.

List the differential diagnosis.

Relevant history and physical examination to assess her.

List the investigations you would ask for with justification for each.

If the vaginal examination reveals tenderness and cervical discharge, what is the diagnosis and management?	2+2+2+4

December 2014

Describe clinical features, investigations and management of pelvic inflammatory disease

UTI

December 2022

Pregnancy is one of the risk factors for UTI:

Explain why a pregnant lady is at risk for UTI. [4]

How would you manage a pregnant lady with UTI at various stages of pregnancy? [6]

June 2021

A 50-year-old lady who attained menopause 2 years ago, has been coming to you for recurrent urinary tract infections.

Outline the risk factors, clinical examination, investigations and management of recurrent UTI in this lady. [2+2+2+4]

December 2019

A 48-year-old post-menopausal lady has been getting recurrent UTI for the past few months. Write briefly on the clinical features, investigations and management of

this lady.

June 2019

Define asymptomatic bacteriuria in pregnancy.

Why is active treatment for this advocated in pregnancy?

June 2018

Investigations and management of recurrent urinary tract infection in a woman (both young and old). 4+6

Maternal Health

April 2016

Enumerate the causes of maternal mortality in India.

How human resource deficiency is affecting maternal health care services?

Role of skill labs to develop capacity.	2+4+4

June 2013

How do you calculate maternal mortality ratio? How do you get estimates of maternal mortality?

What are various causes of maternal mortality in our country? Outline steps to reduce maternal mortality?





Infertility

JUNE 2017

Kumar and Soumya have been married for the past 2 years. They have come to discuss with you the concern that she has not conceived till now.

List common causes of infertility.

How will you assess the couple with appropriate history, physical examination and investigations?

How will you differentiate ovulatory and anovulatory cycles from the history?	3+4+3

December 2015

Razeya and Imran have been married for a year and have come to consult you as she has not conceived yet.	3+7

What advice will you give them with regard to normal fertility?

History, physical examination and investigations to assess an infertile couple in the Family Practice setting.

June 2014

Enlist the causes of infertility in women.

How will you investigate a case of primary infertility at district level hospital?

Elder abuse

December 2020

Elder abuse is becoming a common phenomenon:

What are the warning signs of this problem that you are likely to see in your practice?

What are the preventive measures to prevent this issue?

What are the legal remedies that are available to the elderly in such situations? 5+3+2

Menstrual irregularities

December 2020

A 24-year-old worker in an apparel manufacturing factory complains of irregular periods:

What are the causes for this condition?

Describe the preventive steps that can be taken.

Discuss the treatment modalities that are available. 2+3+5

December 2019

A 50-year-old lady presents to you with irregular periods for the past 6 months. Write briefly on the possible causes, history, physical examination and investigations to assess her,

December 2018

An 18-year-old girl is brought with irregular menstrual periods. She is overweight and is worried because of extra hair growth.

What is the most likely diagnosis?

What is the pathogenesis?

What is the management plan?

PCOD

June 2015

Diagnostic criteria, clinical features, investigations and management of polycystic ovarian syndrome.	2+2+2+4

Medical Illness in Pregnancy

Epilepsy and Malaria

December 2016

Principles of management of a patient with epilepsy who conceives.

Medical issues of malaria complicating pregnancy and its appropriate management.	5+5

Mental health

in pregnancy

December 2016

Mental health problem associated with pregnancy and their management

6+4

Compiled by Dr.Vishnu B S Family Medicine Specialist Trivandrum

95





Hypertension in pregnancy

December 2022

Mrs. Rajani, primigravida, 38 weeks of gestation, admitted in the labor room of secondary care setting. She was induced for high blood pressure. Her BP at admission was recorded to be 164/112, Urine Albumin ++:

Define preeclampsia and severe preeclampsia. [4]

Discuss the management of this patient. [6]

June 2022

22-year old primigravida presented to you with bilateral pedal edema. On examination, her BP was 150/90 mm Hg:

How will you manage this patient? [5]

What are the complications you expect in this patient? [5]

December 2021

A 38-year-old primigravida, married for 10 years, presented at 32 weeks of gestation. She developed moderate dyspnoea of sudden onset two days ago. Examination revealed pallor, bilateral pitting pedal oedema and her blood pressure was 160/100 mm Hg. Cardiorespiratory system examination revealed no obvious abnormalities.

List the possible causes for the symptoms and signs and the problems to be addressed in this patient. [2]

What investigations you will order for? [2]

What will be your plan of management? [3]

What are the maternal & foetal complications you are anticipating? [3]

December 2019

A 24-year-old term primigravida patient is brought to the casualty with a history of altered mental status. She is found to be hypertensive and throws a seizure while you are examining her.

Describe your evaluation and management of this patient.

December 2017

Mrs. Nalini a 23-year-old primigravida presented at 32 weeks of pregnancy with elevated blood pressure since two weeks, headache and epigastric pain. On examination, blood pressure is 180/110 mmHg, and urine protein is 4+.

Mention the diagnosis with reason.

How will you evaluate this patient?

What complication will you anticipate?

List the steps of managing her

April 2016

Pregnancy induced hypertension:

Definition, classification, clinical features & management of severe pre-eclampsia.

1+2+3+4

December 2014

Define pregnancy induced hypertension.

Describe clinical features and management of severe pre-eclampsia

June 2012

Define Pregnancy Induced Hypertension (PIH).

Briefly describe the management of severe pre-eclampsia.

How will you prevent PIH?

December 2011

What is pregnancy induced hypertension? 2+3+5

Enumerate its clinical features.

How will you manage a case of severe pre-eclampsia?





Heart disease

December 2018

A 32-year-old woman known to have mitral stenosis seeks advice about getting pregnant for the 2nd child.

What are the problems associated with valvular heart disease during pregnancy,labour and pueperium?

If the cardiologist advises against pregnancy, what contraception advice will you give her?

Which heart diseases are well tolerated during pregnancy?

Gestational Diabetes Mellitus

December 2022

Mrs. Rubina G3P2L1IUD presented at 24 weeks of gestational age for follow up. Her Glucose tolerance test results were as follows: 106, 194 and 176mg% at fasting, 1 hour and 2 hours respectively. She gives history of having gestational diabetes toward the later part in previous pregnancy and was on medical nutrition therapy:

What is a high risk pregnancy? [2]

What other relevant history and risk factors you will explore? [3]

How will you follow up and manage this lady? [5]

December 2020

A 25-year-old woman presents to you in the 24th week of pregnancy with history of increased frequency of micturition.

What is your approach to making a diagnosis in this case?

How do you manage gestational diabetes? (5+5)

June 2020

A 34-year-old married woman has come for antenatal checkup. You suspect that she may be having gestational diabetes.

Define gestational diabetes.

How will you screen/ investigate for gestational diabetes in this lady?

If she is found to have gestational diabetes, how will you manage her?

June 2019

List the patients who are high risk for gestational diabetes.

Describe the screening strategies for detecting gestational diabetes.

What is the long term outcome of carbohydrate tolerance in a woman with gestational diabetes?

June 2015

Risk factors, complications and management of gestational diabetes.

3+3+4

December 2013

Define gestational diabetes .

How will you investigate and manage a case of gestational diabetes?

National Policy

April 2016

National Policy for the Empowerment of Women, 2001.	10

Pap smear

April 2016

Guidelines for conducting pap smear in women.	4+6

When and how will you manage abnormal changes found in Pap smear?

December 2014

Describe the steps involved in taking a pap smear.





Perimenopause

December 2018

A 52-year-old woman complains of sudden feelings of coldness followed by severe sweating.

What is the most likely diagnosis, and the pathogenesis?

How will you manage her?

How should she be followed up?



December 2013

What is perimenopause?

Describe the features of menopausal syndrome and management.

Pre-conceptional counseling

June 2022

What is pre-conceptional counseling?

How will you advice a couple married an year ago, now planning for pregnancy? [2+8]

Prenatal screening

December 2018

A 30-year-old lady had a miscarriage at 2 months a year ago. She has heard about pre-natal genetic screening and comes to you for advice before conceiving.

Which types of women should be screened for possible genetic abnormalities? Does this woman qualify for detailed testing?

If the lady is married to her maternal uncle, what type of diseases, if present in the family, can be passed on to the child and in what frequency?

Post-menopausal bleeding

December 2020

A 48-year-old woman has been complaining of post-menopausal bleeding.

What is your approach to dealing with this case?

What are the diagnosis and treatment modalities available for the treatment of cervical carcinoma? 3+7

Preterm Delivery

June 2018

List the risk factors for preterm delivery.

How can the neonatal outcome be improved when preterm labour is confirmed?

What are the clinical features of a preterm baby?

Kangaroo method to care for a preterm baby.	3+2+3+2

Peurperium

June 2022

Define puerperium.

What are the common problems of puerperium? [2+8]

Post Natal Visit

December 2021

A recently delivered lady came for routine check up.

Define what is puerperium? [1]

What are the common problems in puerperium and their treatment? [6]

During 6 weeks post-natal visit, how will you utilise the opportunity to educate the mother? [3]

PNDT Act

June 2014

What is PNDT Act and its objectives?

Describe the various provisions under this Act.

Discuss how the Act can be implemented effectively.

December 2011

What is PNDT Act? 2+4+4

Enumerate objectives of PNDT Act.

Discuss various provisions under this Act.





Post partum haemorrhage (PPH).

December 2022

A multigravida delivered half an hour back. She was found to have a heavy gush of vaginal bleed:

Define PPH. [2]

What are the risk factors for PPH? [3]

How will you manage this patient? [5]

June 2019

A 35-year-old lady who is G4P2L2A1 at 38 weeks, has just delivered at the CHC you are working. She develops profuse bleeding.

How will you assess the patient?

Management of postpartum hemorrhage at the CHC.

JUNE 2017

A 25 year old lady who delivered in the community health centre where you work, develops post partum haemorrhage (PPH).

List the risk factors for PPH.

How you will assess this patient?

How will you manage this patient with atonic PPH?	2+4+4

June 2015

Risk factors, clinical features and management of atonic post partum hemorrhage.	3+2+5

December 2012

Enumerate the causes of maternal mortality in India.

Discuss briefly the management of Post Partum Hemorrhage (PPH) at PHC level.

List identifications of referral to a First Referral Unit (FRU).

Urinary incontinence

December 2020

A 25-year-old woman presents to you in the 24th week of pregnancy with history of increased frequency of micturition.

What is your approach to making a diagnosis in this case?

How do you manage gestational diabetes? 5+5

Uterine prolapse

June 2020

A 40-year-old lady who has 3 children presents with history of urinary incontinence. She has urinary loss while coughing or sneezing, which is embarrassing her. Her deliveries were all vaginal, but prolonged. Discuss the diagnosis and management

of her problem.

December 2018

A 35-year-old lady who had 2 normal vaginal deliveries complains of urinary leakage on coughing and sneezing.

What is the diagnosis? What is the pathogenesis?

What is the conservative management?

If conservative management fails, what other treatment is available?

December 2017

A 25-year-old lady has presented to you with history of a mass in her vagina.

List the differential diagnosis with reasons.

What are the risk factors for uterine prolapse? How will you prevent them? What are the complications of uterine prolapse?

Mention briefly the steps of pelvic-floor exercises.











































Paediatrics & Neonatology





Adolescent health

December 2021

A 14-year-old school going girl has been brought to you with upper respiratory infection by the mother.

Describe briefly the possible physical, behavioural and social problems faced by adolescents of her age. [4]

How will you manage these problems of adolesence as a family physician. [4]

Mention the vaccinations recommended for an adolescent girl. [2]

June 2020

Enumerate the various health problems faced by the adolescents.

As a Family Physician, how will you address health issues of adolescent attending your clinic.

Name some Government programs that are initiated to help the adolescents and the benefits they get out of them

3+4+3

Anemia

December 2020

A 13-year-old girl is brought to you with a history of tiredness. On examination, you find that she is pale and undernourished.

What are the investigations that you will conduct?

What are the prevention and treatment modalities for anemia in adolescents? 5+5

June 2019

How is asthma severity classified in children?

List the medications and dosages in each grade of severity.

JUNE 2017

A 3 year old boy is brought to you by his parents with episodes of wheezing over the past 1 year.

List the risk factors for childhood asthma.

How you will manage asthma in this boy?

How you will explain the concept of preventer and reliever inhalers to the parents? 3+4+3

December 2016

Asha is a 1 year old girl who has been brought to you with acute onset of breathlessness.

Outline the differential diagnosis

Management of acute asthma attack in a child.	5+5

December 2015

Ramya is a 1 year old child with history of cough, and wheezing for a day.

Describe briefly the differential diagnosis with clinical features for each.

Investigation and management of each diagnosis. 5+5

June 2015

A 5 year old child with history of asthma is brought to you by his parents.

What aspects of history would you ask?

Stepwise management of asthma in this child.

Use of metered dose inhalers in children. 2+5+3





Atrial septal defect

June 2021

A 6-month-old child was found to have a significant cardiac murmur when you saw her for an upper respiratory infection. An echocardiogram showed an atrial septal defect.

Discuss the management of this condition. [10]

Absence seizures

June 2021

A 5-year-old girl is brought to you by her parents with the complaint that she has been dropping things lately.

What history will you elicit if you suspect that the child has absence seizures? [3]

Briefly	discuss	the	clinical	examination,	investigation	and management of absence seizures. [3+2+2]

Breast feeding

June 2022

What are the benefits of breast feeding?

Mother of a one-month-old baby came to you with complaint of decreased breast milk. How can this issue be addressed? [5+5]

December 2021

A 22 year old anxious mother presented in your OPD with her 1 month old baby complaining of inadequate breast milk.

How will you assess adequacy of breast milk? [2]

How will you counsel her regarding proper feeding technique? [4]

What are the benefits of breast milk? [4]

June 2019

Discuss the problems associated with breast-feeding a newborn child and their management.

Describe how breast milk is expressed and fed to a baby whose mother is working outside the home or is unwell.

December 2016

List the common problem mothers express while breast feeding. How can these be addressed?

What nutrients are deficient in breast milk and how is this managed?

List some important drugs which are secreted in breast milk and the caution required in their usage

December 2015

Common breast feeding problems and their management.

5+5

June 2014

What is exclusive breastfeeding?

Discuss the common problems associated with breast feeding.

How will you manage these problems?

June 2012

Enumerate common problems associated with breast feeding.

Write in brief the management of at least 3 such problems.

Define exclusive breast feeding.





Behavioral Disorders

December 2018

A mother brings her 4-year-old child because of difficulty in retaining him in nursery school. The teacher complains he sits in a corner and refuses to interact with other children.

What are the possible diagnosis? What other behavioral features you will enquire about?

What is the pathogenesis?

What would the diagnosis be if the child was disruptive, indisciplined and has poor scholastic performance? How is it managed?

Breath holding spells.

December 2018

Worried parents bring a 5-year-old child who has spells in which he cries, followed by cessation of breathing.

Explain these spells.

How can they be differentiated form syncopal attacks?

List other conditions which may mimic epilepsy in a child.

December 2014

Discuss briefly the clinical features and management of breath

holding spells.

Breathing difficulty in a child

December 2014

A 1 year old child is brought to you with breathing difficulty from the morning. Describe the differential diagnosis with clinical features and investigations.

Child abuse

June 2020

Child abuse is being more commonly seen in the newspapers. How would you screen for child abuse in your clinic?

What are the available laws, systems to help victims of child abuse? 4+6

December 2017

A 4-year-old girl is brought to your OPD by her mother as she noticed vaginal bleeding an hour ago. She was concerned if the child has a serious illness or cancer.

How will you assess this child for sexual abuse?

Enumerate the child protection services in our country.

What other causes should you evaluate for and how will you do that?

December 2016

What clinical features will raise the suspicion of child being abused?

List the types of child abuse.

List the risk factors for child abuse.

Cold chain

June 2014

Define cold chain.

What is reverse cold chain?

Name the equipments of cold chain and describe the process of cold chain maintenance from grass root level to state level.

December 2011

Define cold chain. 2+2+3+3

What is reverse cold chain?

Name the equipments of cold chain

What are the vaccines kept in these equipments of cold chain?





Croup

June 2021

A 2-year-old child is brought to you by his mother with a barky cough and shortness of breath from morning.

List the differential diagnosis. [2]

Discuss the clinical features, investigations, and management of croup. [3+2+3]

Diarrhea

December 2022

9-months-old baby of Esther has presented in the OPD with history of 5 episodes of loose stools, associated with vomiting for one day. The child is weighing 6 kg, with the birth weight of 3.2 kg. Child is lethargic, with sunken eyes and low skin turgor. There was no urine output since today morning:

What is the diagnosis? [3]

How will you manage Baby of Esther? [4]

What advise you will give to the mother at the time of discharge about the long-term plan of managing this child? [3]

December 2021

4-year-old boy is brought to you with history of loose stools since two days. He was drinking fluids normally and on examination, he is alert and there are no signs of dehydration.

How will you advice the mother regarding home management? [3]

Describe Plan C management in acute diarrheal disease. [3]

Describe nutritional management of diarrhoea in children. [4]

June 2018

IMNCI classification and management of a child with acute diarrhea. (10)

December 2017

A 7-year-old is brought to you by his parents with history of loose stool for the past 3 weeks duration.

What is the differential diagnosis?

How will you clinically evaluate the child?

How will you treat this child?

What is the role of anti-microbials in this child?

June 2015

IMNCI guidelines for managing a 4 year old child with acute diarrhea.

Management of a child with severe dehydration. 5+5

June 2013

What is persistent diarrhea? What are its causes?

How will you assess the degree of dehydration?

How will you manage such a case?

June 2012

Define persistent diarrhea.

Enumerate the causes of persistent diarrhea.

How will you manage a 5 year old child with persistent diarrhea at Community Health Centre?

December 2011

What is persistent diarrhea? 2+3+5

What are its causes?

How will you manage a case of persistent diarrhea?





Constipation

June 2021

4-year-old child is brought to you by his parents since he has been opening his bowels only once in 3 to 4 days.

What further history would you elicit? What clinical signs would you look for?

How will you manage constipation in this child? [3+2+5]

Dentition Rickets

June 2013

What is the age of completion of primary dentition? What is delayed dentition?

What are its various causes?

Describe treatment of nutritional rickets.

Dog bites

December 2019

A 5-year-old child is brought to the casualty with a history of unprovoked bite by a stray dog. The dog was reported to have bitten several other people also over the last few days.

How will you manage this child?

Down’s

syndrome

December 2014

Describe clinical features of Down’s syndrome and its complications. What will be the role ot the family physician in managing a child with Down’s syndrome?

Enteric fever

June 2014

Discuss the clinical features, diagnosis and treatment of enteric fever in a five year old child.

Epiglottitis

June 2018

Clinical features, investigations and management of acute epiglottitis.

4+3+3

Febrile seizures

June 2022

A one-year-old girl child was brought to you with history of convulsions. She had history of fever since one day:

What are the differential diagnosis? [2]

How will you manage? [4]

How will you advice the parents regarding prevention and management of further episodes? [4]

December 2016

Define febrile convulsion. How is it differentiated from serious causes

of seizures? How will you support the anxious parents?	(1+7)+2

June 2015

Clinical features and management of simple febrile convulsions.

4+6

December 2014

An 18 month old child has fever of 2 days duration and develops generalized seizures. What are the possible causes? How will you

manage the child?

Development in a child

December 2021

One year old child is brought for check up with history poor development as compared to their previous child.

Define Development? What are the Rules of Development? [3]

What are the Red flag signs in child development? [3]

As a Family Physician how will you prevent developmental delay and how will you help the family to cope up with the situation? [4]





Failure to thrive

JUNE 2017

Use of height and weight charts for children.

Assessment and management of a child of 5 year with failure to thrive. 2+8

IMNCI

December 2013

Briefly describe IMNCI & FIMNCI. What services need to be developed at PHC , CHC and district Hospitals to manage the sick new borns and children?

December 2012

Define acute respiratory infections (ARI). Discuss the approach of

IMNCI for classification and management of a 2 year old child having cold and cough

Incessant Cry

June 2018

A 30-day old infant is brought to you with incessant cry. Outline the management of this infant.	(10)

JUNE 2017

A mother brings her 3 day old child with incessant cry.

List the causes of incessant cry in a new born.

History, physical examination and investigations with justification to assess this child.	3+7

December 2015

What are the causes for and assessment of an infant with incessant cry?	5+5

Infant Mortality Rate

April 2016

Define Infant Mortality Rate (IMR).

b) Enumerate causes of IMR and how will you prevent IMR in your area of practice.	1+(3+6)

June 2014

Define Infant Mortality Rate (IMR).

Enlist the causes of IMR in India.

Discuss the measures to be taken to reduce IMR in the country.

December 2013

Enlist the commonly used mortality indicators of MCH care . Discuss the factors that affect infant mortality. Describe the

measures needed to reduce infant mortality .

December 2011

Define infant mortality rate. 2+3+5

What are its causes?

How it can be effectively reduced in India?

Infantile

eczema

June 2018

Clinical features and management of infantile eczema. 5+5

Infections

AOM

June 2021

Discuss the clinical features and management of acute otitis media in a 10 month old otherwise healthy child.

Outline the role of delayed antibiotic therapy in this condition.

[3+4+3]

CSOM

December 2020

The mother of a 4-year-old girl says that her daughter has been suffering from repeated attacks of cold and cough over the past 6 months:

List the steps in the treatment of this case.

Discuss the management of chronic suppurative otitis media. 5+5





Acute Rheumatic Fever

December 2022

The pathogenesis of Acute Rheumatic Fever. [2]

The Criteria used for the diagnosis of Rheumatic Fever. [3]

How will you treat a 13-year-old School going girl Lakshmi, who presented with Acute Rheumatic fever? [3]

How will you prevent the recurrence of this conditon? [2]

December 2019

An 8-year-old child comes to the OPD with a history of fever for the last 10 days. This was followed by development of pain and swelling in the right ankle joint which subsided and was followed by similar involvement of the left knee joint.

Write your approach to the diagnosis and management of this child. What are Jones criteria?

What steps will you take for the primary prevention of this condition?

Dengue Fever

December 2018

A 10-year-old girl develops high fever, retro-orbital pain and in a few days collapses with bleeding gums. There are many other patients with similar illness.

What is the diagnosis, the etiology and pathogenesis?

What is the reason for the collapse and bleeding?

How is the definitive diagnosis made?

Fever in a child

December 2017

A five-year old is brought to you by her grand parents with history of fever for one-day duration.

Mention the clinical symptoms and signs you will elicit on this child.

The child has no other features than fever. What investigation will you seek and why?

On the third day, the parents bring the child, with urine report of uncentrifuged urine sample with 70 WBC’s.

How will you manage the child?

Fever with rash

June 2020

A 4-year-old girl is brought to you with fever and rashes. Discuss the differential diagnosis.

Write short note on how you will manage a child with measles. 4+6

H1N1

influenza.

June 2015

Clinical diagnosis and laboratory confirmation of H1N1 influenza.

Management of a confirmed case of H1N1 influenza.

How will you educate the family and community regarding prevention of spread of H1N1 influenza?

HIV

December 2012

List out the clinical staging for HIV infection in children as recommended by WHO. Discuss briefly the diagnosis and anti-

retroviral therapy of HIV infection in children.

HIV- Varicella

December 2016

Management of a newborn exposed to:

Varicella infection stating rationale.

Principles of management of a HIV +ve pregnant mother. 5+5





TB

December 2022

A 5-year-old child was brought by his mother with cough, and mild fever for past 2 weeks. His weight is 13 kg (Birth wt-2.9kg). His father was treated for pulmonary TB 3 months back:

Discuss diagnosis of TB in this child. [2]

Discuss the treatment of pediatric TB as per National TB elimination program. [4]

What measures could have prevented the child from being infected by his father? [2]

What advice will you give to the anganwadi that the child is attending? [2]

TB

June 2012

What new changes have been incorporated in strategies under Revised National TB Control Program (RNTCP)?

Write briefly on treatment guidelines for category II patient under DOTS.

What is multi-drug resistance tuberculosis?

Juvenile Justice Act

April 2016

Salient features of the Juvenile Justice (Care and Protection of Children) Act, 2000.	10

Micronutrients Iodine def disorders

December 2012

Enlist micronutrients of public health importance. What are iodine deficiency disorders (IDD)?

Discuss steps taken by Government of India for its prevention and control.

Nappy rash.

December 2015

Risk factors, differential diagnosis and management of nappy rash.

2+3+5

Nephritic syndrome-PSGN

June 2015

History & physical findings, investigations and management of post streptococcal glomerular nephritis.

3+2+5

Nephrotic syndrome

December

2019

Diagnosis and treatment of nephrotic syndrome in children

December 2012

What is nephrotic syndrome?

Discuss briefly its diagnosis and management in a 10 year old child.

Nocturnal eneuresis

JUNE 2017

Nocturnal eneuresis – causes & management.

4+6

December

2014

Describe management of a 10 year old child who has bed wetting.

Oral thrush

December 2013

What is oral thrush? What are its causes? How it should be treated? How it can be prevented?





Malnutrition in a child

June 2022

Define Severe Acute Malnutrition (SAM). [2]

How will you manage a child with uncomplicated SAM? [3]

What are the serious complications faced by children with SAM and how will you manage them? [5]

December 2020

A mother of a 5-year-old boy, complains that her son is not gaining weight.

How would you assess the nutritional status of this boy?

What are the steps in the management of severe acute malnutrition? 5+5

June 2020

Define Severe Acute Malnutrition (SAM).

How will you manage a child with uncomplicated SAM?

What are the serious complications faced by children with SAM and how will you manage them? 2+3+5

December 2018

The family doctor notes that one of the patients is noted to be below the 5th percentile in the growth chart for weight for height.

What is the approach to this child?

What is the importance of checking body proportions in a child?

How is malnutrition graded?

December 2015

An 8 month old girl child has only 60% of the expected weight.

Describe briefly the possible causes of malnutrition in this child.

Outline the history, physical examination and investigations to assess the child.	4+(2+2+2)

June 2014

What is Protein Energy Malnutrition (PEM)?

Describe the causes, manifestations and management of severe PEM in children.

December 2013

Enumerate various nutritional problems in India . Briefly discuss protein energy malnutrition (PEM). Describe the various classifications for PEM. What actions are needed for prevention of PEM in community?

December 2012

Define malnutrition. List classifications used for grading protein-energy malnutrition. How would you manage a child of moderate PEM?

December 2011

How do you assess protein energy malnutrition? 3+3+4

What are the causes of PEM?

What measures are being taken by Govt.of lndia?

Problems of school children

December 2013

Enumerate the various health problems of school children. What are the objectives of school health services?

Describe briefly the various aspects of school health services . How these services are administered in India?





RCH

April 2016

Role of ASHA in implementation of RCH services under National Health Mission.	10

Skin infections in childhood.

June 2019

List 4 common skin infections in childhood.

Describe clinical features and management of each of the above.

Stridor in a child

June 2022

Mother of a one-year-old girl child brought the child with history of fever, breathing difficulty and stridor of one day duration. [5+5]

Outline the differential diagnosis of stridor and fever in this baby.

Management of each of these conditions.

Vaccination

June 2022

Describe the national immunization schedule. [4]

A 4 year old boy is brought to you for a wound in the lower limb after a fall. He is unimmunized till now. How will you plan the immunization in this boy? [6]

Dec 2020

Optional vaccines in childhood.

Adverse effects following vaccination.  5+5

December 2019

Pneumococcal vaccine in children.

Vaccination in a child with history of seizures.

Chicken pox vaccine.

JUNE 2017

Newer vaccines introduced in National Immunization Schedule.

10

June 2019

Human papilloma virus vaccination in children.

Vaginal discharge

December 2017

A 5-year-old girl is brought to you by her mother with history of itching in her vulva and vaginal discharge.

How will you manage her?

What preventive advice can you give this girl at her lifestage?

Vitamin A deficiency

April 2016

Classify changes in eyes in Vitamin A deficiency according to WHO.

What are the other changes in body and how will you manage the deficiency?	4+(3+3)

June 2014

Manifestations, classification and management of Vitamin A deficiency according to WHO .

Verbal Autopsy.

June 2012

Write vitamin A deficiency classification according to WHO.

How will you manage a case of Vitamin A deficiency at your clinic?

What will you do to prevent Vitamin A deficiency in you community?

Worm infestations

June 2012

Enumerate common worm infestations in children.

Formulate a plan to prevent and control worm infestation in school children.





Neonatology

Seizure in newborn

December 2017

A 3-day old child is brought to your OPD with history of seizures since last night.

What are the etiological factors for seizures in this age group?

How will you treat this child?

The same child is brought to you at 8-month of age with fever and seizures. How will you manage this child now?

Health check - post natal visit

June 2019

A mother has brought her 6-week old child for a health check to you. Describe briefly the history and physical examination to assess this child.

Preterm & Low Birth Weight baby

June 2020

Define low birth weight.?

Name 3 major problems faced by:

Preterm babies

IUGR (Intra-Uterine Growth Retardation) babies

What is Kangaroo Mother Care (KMC)?

What are all advantages of KMC? 2+3+2+3

Deccember 2020

Define low birth weight.

Mention the causes of low birth weight.

What are the various ways in which you can prevent low birth weight?

[2+3+5]

Management of new born

December 2019

A 2 kg baby delivered at home by a Dai is brought to your CHC with a history of refusal to feed. The baby is also cold to touch. Describe your approach to the diagnosis and management of this child.

Neonatal problems

December 2021

Describe common neonatal problems. How to diagnose and manage each?

As a Family Physician how will you educate mothers regarding new born care? [3+3+4]

Jaundice in Newborn

December 2022

Baby born 17 hours ago, was found to be icteric on examination. Baby is feeding well:

Explain the bilirubin metabolism. [3]

Write briefly on pathophysiology of neonatal hyperbilirubinemia. [3]

How will you manage this baby? [4]

December 2018

A 4-day old child discharged 48 hours ago from the PHC as normal, is noted to be jaundiced by the mother. The child had a cephalohematoma after delivery but was otherwise normal.

How will the family doctor manage this child if no pediatrician is available?

What would be the approach if jaundice was noted at birth?

June 2013

What is physiological jaundice of newborn?

Enumerate causes of breast milk jaundice, physiological jaundice of newborn and prolonged physiological jaundice.

What is kernicterus?













Compiled by Dr.Vishnu B S Family Medicine Specialist Trivandrum

FAMILY MEDICINE

AND PSM

115

















Accidents

December 2013

What is an accident?

Enumerate various types of accidents.

Briefly describe the risk factors involved in Road Traffic Accidents (RTAs) .

How RTAs can be prevented?

Alcoholism

December

2022

Steps in de-adiciton of alcohol. [5]

December

2018

What are the social and public health effects of alcohol consumption by the public?

Anaemia

June 2019

Describe what measures should be taken to prevent and treat anemia in adolescent girls.

Adolescent

Health

June 2022

Discuss briefly regarding problems of adolescence.

What are the government schemes for adolescents? [6+4]

Audit

December 2022

The cesarean section rate in your hospital is 25%:

How will you conduct an audit of the caserean sections being conduced in your hospital? [4]

What are the principles of evidence based medicine that will help you to identify good practices? [4]

How will you remedy the situation in your hospital? [2]

Biomedical Waste management

December 2022

Discuss the importance of:

Biomedical waste seggregation in family practice. [5]

December

2021

Biomedical waste management. [10]

June 2020

Recent Bio-medical waste management guidelines.

December 2013

What is biomedical waste?

Enumerate the various categories of biomedical waste in India . Briefly describe the treatment & disposal technologies for such wastes

June 2012

Biomedical Waste (Management and Handling) Rules.

Cancer screening

December 2019

Enumerate the commonest types of cancers in men and women in India. Describe the methods for cancer screening in a community.

As a family physician, how will you carry out screening for cancer cervix for women presenting to your clinic?

December 2018

What is the importance and pitfalls of screening for cancers?

Which cancers should be actively screened for in India and why?

Describe the most cost-effective methods of screening of common cancers in India.





Child health

December 2019

What is the home based newborn care (HBNC)? Explain the rationale behind HBNC.

How is HBNC provided in the community?

December 2012

What do you understand by Baby Friendly Hospital Initiative(BFHI)? List the criteria to be fulfilled for recognition of a hospital as BFHI. How would you manage a case of failure of lactation?

Demography

December 2018

What is meant by the term “demographic dividend”?

What is the significance of it?

What is meant by life expectancy at birth? What is the figure for India in the 21st century, and what determines it?

December 2012

Define demography. Discuss in brief how and which of the demographic trends are monitored in India.

PNDT Act

June 2012

b) Pre-conception and pre-natal diagnostic tests (PNDT) Act.

Dietary Fibers in Food

December 2012

Classify carbohydrates of physiologic importance. Discuss role of dietary fiber on our foods.

Enlist foods high in fibers that you would recommend for your patients.

Disaster management

June 2022

What is disaster cycle?

How will you prepare the people in your CHC area for an anticipated flood?

What is disaster mitigation? [2+6+2]

December 2021

You are working in a PHC and the area has been hit by floods.

What are the post flood activities that you will undertake so as to prevent the spread of diseases? [5]

Write short notes on disaster preparedness. [5]

December 2020

What are the different levels of disasters in India?

Discuss the activities undertaken in National School Safety Project. 4+6

June 2019

The area where you have been working in a CHC was damaged heavily by a cyclone the previous day.

Describe the role of the doctor as part of the disaster response team.

Environment health

Climate Change impact

June 2021

Discuss climate change and its impact on the social and environmental determinants of health. [10]

Pollution

December 2022

Discuss the importance of:

Air pollution on health of the individual. [5]





Pollution

December 2020

Effects of air pollution.

Occupational hazards of agricultural workers. 5+5

June 2019

Sources, effects and control of air pollution in a rural setting.

Water Quality

December 2012

What is safe and wholesome water?

List water-borne diseases specifying the agent and vector, if applicable.

Discuss in brief household methods of water purification suitable for rural communities.

December 2020

Discuss surveillance of drinking water quality.

Describe various methods for household purification of water. 5+5

Maternal and child mortality/ morbidity

indicators

December 2019

What are the common causes of under – 5 mortality in India?

Maternal mortality/ morbidity indicators

June 2012

Enumerate the causes of maternal mortality.

What strategies are adopted by the Government of India to decrease maternal mortality in India?

Critically comment on success or failure of these strategies.

December 2011

Enumerate morbidity indicators. 3+3+4

How do you calculate them?

What are their uses?

December 2019

Define maternal mortality.

Discuss the various causes of maternal mortality .

Enumerate the various measures under the National Health Mission to reduce maternal mortality .

December 2018

Discuss the public health measures which have improved the under-5 mortality rate in India in the last 30 years.

Discuss the factors which are known to improve infant mortality rates.

Infant Mortality Rate

June 2020

Define infant mortality rate (IMR).	2+1+3+4

What is the current IMR in India?

What are the causes of high IMR in India?

As a Family Physician, how will you plan in helping district health authorities to reduce IMR in your district?



December 2022

Infant mortality rate:

Define infant mortality rate. [2]

What are the determinants of infant mortality in India? [3]

How will you prevent infant mortality in your community? [5]

Fertility

June 2020

Enlist various indicators of fertility. Define Net Reproduction Rate.

Outline the plan for evaluation of Family Planning Services. 3+2+5





Epidemiology

Epidemiology basics

June 2012

Epidemiological triad.

Briefly describe various levels of prevention with suitable examples.

Epidemiology and Statistics

December 2019

a) Case control studies	b) Chi square test

c) Sampling	d) Confidence interval

Epidemic Investigation

December 2022

There has been a cholera outbreak in the locality where you practice. You have been asked by the local administration to investigate this. How will you proceed to ascertain the existing situation of outbreak?

Briefly describe the study design, objective, methodology and associated factors. [4+6]

June 2022

You have diagnosed 15 cases of Dengue fever infection in your area. How will you investigate and control this epidemic? [5+5]

December 2021

You as a family physician notice an outbreak of fever with loose stools among children in your locality where you practice. The local administration has requested you to join a committee formed to look into this.

Design a study to describe the factors associated with outbreak of this problem. [10]

June 2021

You decide to study the effectiveness of a vaccine against COVID-19 infection in the adult population covered by your community health centre. Discuss the study design you would use to investigate this. [10]

December 2020

Define & explain the application & steps of Meta-analysis in Medical Research. 10

June 2020

Many people of various age groups are reporting with fever, jaundice and other abdominal symptoms from a village under the PHC where you are working as in-charge Medical Officer.

How will you investigate this outbreak?

Describe the steps you would undertake to prevent and control this outbreak in your PHC area.	5+5

December 2019

As a family physician in charge of your CHC, it is brought to your notice that several people in a nearby village have developed severe dehydrating diarrhoea, including a 5-year-old child who has died.

Enumerate the steps that you will take in investigating this epidemic.

What preventive measures will you take in controlling the spread of this infection?

June 2019

You want to investigate the effectiveness of a single high dose of azithromycin as compared to the usual treatment for outpatient management of community acquired pneumonia, using a randomized controlled trial. Write briefly on the steps involved in this.

Compiled by Dr.Vishnu B S Family Medicine Specialist Trivandrum

119





Epidemiology-Child sex ratio

December 2013

What is child sex ratio? What are the causes of declining sex ratio in India ? Discuss the various steps taken by Government to improve the sex ratio.

Family planning

December 2018

What is the role of the family doctor in family planning, giving examples of when and how such advice should be given to couples in the reproductive age group?

What is the emergency contraceptive pill and what role does it have in family planning?

December 2011

What are various contraceptive measures used in National Family Welfare Programme?	4+6

Briefly describe different types of pills used in the programme.

General -Self Medication

June 2013

What is self medication?

Why do people indulge in self medication? What are its disadvantages?

How can it be prevented?

Geriatrics

December 2020

Discuss health problems of the elderly.

Discuss the role of lifestyle in healthy ageing. 5+5

June 2013

What is disability?

What are the new concepts in dealing with disabled people? How can a home be made disabled friendly?

Behaviour Change Communication

June 2012

What is Behaviour Change Communication (BCC)?

Plan a BCC package for community to improve immunization coverage among under five children.

Communication

June 2013

Briefly discuss various types of communications and barriers of communications.

Describe the various functions of health communication.

Enumerate commonly used audio visual aids in the practice of health education.

Communication - GIS

December 2020

Discuss the use of Geographic Information System(GIS) in public health. 10

Communication - HMIS

December 2011

What is HMIS? 2+3+5

What are its uses?

How it is implemented by Govt.of India?

Communication - HMIS

June 2013

What are the components of a health information system? What are the various uses of health information?

Describe briefly the various sources of health information.

Communication-IEC

December 2011

What is IEC? 2+4+4

What materials are used and activities undertaken under IEC campaign?

What are the steps in planning of communication activities?





Communication-Interview

December 2013

What is an interview?

What are the aims of interview ?

Briefly describe the various kinds of interviews. Discuss the various steps for conducting an interview.

Genetic counseling

December 2013

What is prospective genetic counseling? What are its indications?

Give examples of its potential use in India.

Genetic counseling and disorders

June 2013

Classify genetic disorders. Enumerate chromosomal disorders.

What is the role of genetic predisposition in common disorders? Describe the various preventive and social measures relating to genetic disorders

Health and its various aspects

Disease prevention

December 2013

What is natural history of disease ?

Describe briefly the various levels of prevention.

Discuss the various modes of intervention to arrest the development of disease in man.

Family health

June 2013

What is a family?

Describe the various types of families. What is a problem family?

What is the role of family in health?

Health - Basics

June 2022

What is meant by health and well-being? What all are essential for healthy living? How will you measure the quality of life?

What are the social determinants of health? [2+2+2+4]

December 2013

What is WHO definition of health?

Briefly describe various determinants of health.

What is individual , community , state and international responsibility in relation to health

June 2012

Define the following terms:

Reproductive Health

Public Health	c) Social Medicine

d) Human Ecology	e) Net Reproduction Rate

Health education

June 2019

You are planning a new group health education initiative for antenatal women in your CHC.

Describe briefly the components of health education for this group.

Health Management

December 2020

What is SWOT analysis?

Explain with the help of an example the steps of conducting SWOT analysis in health.3+7





Health-Public health

June 2019

Describe the public health measures to be taken at the start of a dengue outbreak.

What measures are helpful to reduce the incidence of filariasis?

Social health

December 2020

What is social marketing?

Discuss social marketing in health. 2+8

December 2013

What is social marketing?

Enumerate five successful examples of social marketing campaigns in India.

What is the role of social media in health- promotion?

December 2011

Define social mobilization. 2+3+5

What is its importance?

What are various steps in its process?

Communicable and Non Communicable Diseases and related National Health Programs

Chronic Diarrhoea

December 2018

A 35-year-old man has chronic diarrhoea, low grade fever and has lost considerable weight over the last 4 weeks. Most of the lab tests and multiple treatments for fever and diarrhoea have been tried.

What is the most likely diagnosis, giving reasons?

What tests are done for establishing the diagnosis?

List the classes of drugs used in the treatment of this disease.

Fever

December 2012

Define fever. Enlist types of fever and write briefly on them.

Discuss management of a 10 year old child suffering from high grade fever.

HIV/NACO

December 2019

Describe the vertical transmission of HIV infection.

What are the strategies to prevent the vertical transmission of HIV under the national AIDS control program?

IMNCI ARI



How will you diagnose and manage a 10-month old child presenting with acute respiratory infection under the IMNCI?

Infections -STDs and Syndromic approach

December 2018

A 28-year-old man comes to you with urethral discharge. He admits to multiple hetero-sexual partners.

Using the WHO syndromic approach, what STD is he likely to have and describe the management.

How can the family practitioner prevent further dissemination of the STD from this case?

Discuss the syndromic management of a woman with vaginal discharge

.

Rabies

December 2012

What is Post Exposure Prophylaxis (PEP) for rabies?

Discuss briefly local wound care and immunization for a category III street dog bite.





Malaria NVBDCP

December 2012

Classify anti-malarial drugs used under the National Vector Borne Disease Control Program (NVBDCP) in India. Discuss the treatment of uncomplicated Plasmodium vivax malaria in a 10 year old child.

Enumerate preventive measures for other families in the locality

December 2011

How will you investigate a case of fever in a 20 years old male in a village?

What is the drug schedule for treatment of malaria in NVBDCP? 6+4

Tuberculosis RNTCP/NTEP

June 2022

What are the aims and objectives of Revised National TB Control Programme of India (elimination program 2020)?

How does this programme help to achieve elimination of TB from India?

With regard to HIV infection, what are the recommendations by the program? [3+5+2]

December 2021

What are the recent changes in Revised National Tuberculosis programme?

What advice will you give to a patient who has been initiated on anti-tuberculous treatment. [5+5]

June 2020

A 45-year male had been diagnosed to have TB and started on antitubercular treatment (ATT). He returns in two weeks to say that his fever is persisting.

What are the common causes of discontinuation of ATT? What measures can you take to ensure compliance?

What are the common side effects and adverse effects of the first line ATT?	3+3+4

December 2019

Describe the objectives of the RNTCP and the strategy for the elimination of TB in India,

December 2011

How will you diagnose a case of Pulmonary TB? 3+2+5

What are its various categories?

What are the treatment regimens followed under DOTS?

UTI

December 2018

A 75-year-old patient approaches his family physician because of fever, 10 days after discharge from hospital where he was admitted for prostate surgery.

What is the likely cause of fever and what is it known as?

Could it be a “super bug”? Discuss what this means and its significance for the community.

How do such hospital acquired infections occur and how can they be prevented?

Lifestyle disorders

December 2019

Enumerate the strategies to control life style disorders at the legal, individual and community levels





National Health Programs

School health services

December 2021

What are the common health problems faced by school children? [4]

List the objectives of school health services. [2]

Explain how will you implement the diffrerent aspects of school health services as a family doctor. [4]

June 2021

Objectives and services under the School Health Program of Ayushman Bharat. [10]

Ayushman Bharat

December 2022

The beneficiaries and benefits of Ayushman Bharat yojana. [5]

Discuss Janani suraksha yogana (JSY) of the Government. [5]

NRHM

June 2013

What are the National Health Programmes adopted by Government of India?

What are the components of NRHM? Describe the role of ASHA.

June 2012

Write components of National Rural Health Mission.

Enumerate the job responsibilities of Accredited Social Health Activist (ASHA).

MCH

June 2012

Define Mother Non-Governmental Organizations (NGO).

What are their roles in reproductive and Child Health Program?

Write briefly about Mamta Scheme.

June 2012

Explain the role of the following in maternal and child health:

Quality of care

Public private partnership

Mental Health

June 2020

What are the key features of the National Mental Health Program? What is the role of the family physician to integrate mental health with primary health care and provide access to mental health services in the community?   5+5

Nutrition and Osteoporosis

December 2018

A 75-year-old lady has been discharged from hospital after hemi-arthroplasty for fragility fracture of the hip.

What nutritional advice should be given to such patients to improve bone health?

What screening measure can detect osteoporosis in the elderly? Give details of timing of screening and method.

What life-style measures can prevent osteoporosis?

Nutrition-Malnutrition

December 2019

Enumerate the criteria for diagnosing severe acute malnutrition (SAM) in a child.

How is screening for SAM done in the community ?

What are the criteria for admitting a child with SAM to the hospital?





Occupational hazards

June 2019

Occupational hazards due to cement for a construction worker and methods to prevent them.

December 2018

Health hazards of being a farmer.

List the occupational lung diseases.

Pandemic

June 2020

Define Pandemic.

Enlist the diseases which occurred in pandemic form.

Write on preventive measures for COVID-19 Pandemic being undertaken in our country.	2+2+6

Patient centered approach

June 2019

A 45-year-old diabetic requires insulin for control of diabetes, but is refusing insulin. What is the best patient-centered ethical approach?

List the measures which can help to improve compliance in taking 6 tablets in a 70-year-old illiterate widow who lives alone.

Planning

December 2021

Define planning.

Describe the steps in planning for a program to control water borne diseases in your ward. [3+7]

June 2013

What is planning and management?

Describe briefly the various steps involved in planning cycle. Enumerate management techniques based on quantitative methods. Describe briefly the network analysis.

Problems in elderly

December 2013

What are the health problems faced by bed ridden people? What are their causes ?

How can these be treated?

How they can be prevented?

Primary Health Care

First referral Unit

December 2012

What is First Referral unit (FRU)?

Enlist the specialists who must be posted in an FRU and the services they would provide.

Write in brief services to be provided at nori-FRU community health centers.

June 2012

What are the components of antenatal care?

Write in brief about First Referral Unit (FRU).

How will you manage transverse lie at FRU?

Primary Health care

June 2013

What is primary health care?

Enumerate the elements of primary health care?

Briefly describe the elements of primary health care with suitable examples.

December 2011

What is primary health care? 2+2+3+3

Enumerate the principles of health care.

Name its elements.

Describe briefly appropriate technology.





Prolapse Uterus

December 2012

Name important ligaments of female pelvis.

Discuss their applied anatomy with a brief outline of management of uterine prolapses.

Screening of disease and Levels of Prevention

Screening of disease Cancer

December 2022

Discuss the criteria for screening. [5]

Describe the different methods of screening for cervical cancer. [5]

June 2020

How will you carry out screening of breast cancer in females, in community as well as at clinic level?

Name the programme for cancer prevention in India.

Write on the role of Cancer Registry in prevention of cancers.

(2+2)+1+5

Screening of disease

December 2013

What is screening?

What is the difference between a screening test and a diagnostic test? Describe briefly various types of screening. What are the uses of screening?

June 2012

. a) Describe the concept of iceberg phenomenon of disease.

What is the role of screening in prevention and control of disease?

Describe briefly about screening for breast cancer

December 2011

What is surveillance?	2+3+3+2

What are its elements?

Enumerate the methods of surveillance.

Briefly describe active surveillance.

December 2011

What are various levels of prevention? 3+7

What are the strategies used for implementation of various levels of prevention?

Smoking cessation

June 2019

Describe the intervention to be adopted in a school where several boys have been caught smoking.

December 2018

What are the principles of helping smokers to quit smoking and the role of the family physician?

Social Life

June 2021

A 30-year-old headload worker who is the only earning member in the family is admitted in your community health centre following severe low back pain which he developed while lifting a heavy load. He is married with two children and lives in a rented house. You have diagnosed him to have intervertebral disc prolapse clinically and he is being managed conservatively.

Discuss the impact of his context on the disease and its management and the impact of his disease on the various aspects of his life. [10]





Statistics

December 2022

A family practitioner wants to establish a relationship between arreca nut chewing and oral cancer:

What tests of association must he apply to identify the association? [5]

How will confidence interval help to interpret the results? [5]

December 2020

Define sampling.

Describe the various methods of sampling with the help of suitable examples. 2+8

June 2020

Define the following and give their formulae:

The mean deviation.

The standard deviation.

Urban Health

June 2022

Define urban health.

What are the major health issues seen in urban areas of India?

How does National Urban Health Mission of India address these issues? [1+4+5]

June 2021

Describe the health problems of the urban poor. [10]

Vaccination and various aspects

December

2022

Adult vaccination. [5]

June 2020

Adult vaccination. [5]

June 2022

Discuss the various types of pneumococal vaccines that are available for immunisation in our country.

Discuss the indications for this vaccine in adults.

What is the schedule of the vaccination in children? [4+3+3]

December 2021

Briefly describe the need for Covid 19 vaccination in India. [2]

What are the challenges and issues in implementation of covid vaccine in India? [4]

How will you overcome the challenges and implement covid vaccination in your area as a medical officer working in a Primary Health Centre? [4]

June 2021

Discuss vaccine hesitancy and its implications for public health. [10]

December 2020

Discuss the various COVID-19 candidate vaccines in India. Discuss the ethical issues in COVID-19 vaccine trials. 7+3

June 2019

Rota virus infection and vaccination.

December 2012

What is primary immunization?

Make a list of vaccines recommended under Universal Immunization Programme (UIP) including their dose, age of administration and route.

Enumerate vaccines recommended by Pediatricians over and above those of UIP.

Compiled by Dr.Vishnu B S Family Medicine Specialist Trivandrum

127





Travel Medicine

June 2022

48 year old man came to see you to get advice regarding a trip to USA for 3 months. He is diabetic on insulin and OHA, and is having bronchial asthma controlled with inhalers. He is under your follow up. What immunisation will you advice? What medical documents will you provide for the patient? He wants to carry his medications for the trip. What advice will you provide?

[3+3+4]

June 2019

What advice would you give to a family which is planning a 10-day visit to

Kenya for a wild life safari holiday?

Antimicrobial resisitance

June 2020

The role of the family physician in prevention of drug resistance in the community. (5)





Family Medicine

Consultation process

December 2021

A young couple who are migrant labourers have moved into your locality from another part of the country and the lady is 5 months pregnant. They have come to your health centre for your advice regarding what to plan and be ready for receiving the child.

Describe the consultation process. What questions you would ask and mention the reason for the questions? [4]

What are the essential antenatal care recommended for this woman? [4]

If you were to do a home visit, what would you look for regarding health and safety issues for the mother and baby? [2]

EMR in Practice

June 2021

Discuss the advantages and challenges of using electronic medical records in family practice. [10]

Family Medicine and its various aspects

June 2013

What is family medicine and what is a family physician?

How does the approach of a family physician differ from a public health expert?

Explain with examples.

Family Medicine and its various aspects

June 2021

A 45-year-old business man comes to see you with insomnia and anxiety for the past 2 weeks. The pandemic has affected his business badly and he is fearful of contracting the disease.

Discuss the role of the family physician as a counselor. [10]

ICE

June 2021

Briefly discuss eliciting the ideas, concerns, and expectations of the patient in a consultation and its significance. [10]

Patient and Disease Centered

Care

June 2021

Describe the difference between patient-centred medicine and disease-centred medicine. [10]

Referral System

June 2022

What is the difference between 'referral of a patient' to a specialist and 'consultation by a specialist' when you send your patients for a second opinion?

What are the legal implication for family practitioner when he sends a patient for consultation or referral?

Discuss the referral system available in the public health institutions in our country. [3+2+5]

December 2021

Discuss the importance of referral system in Family practice and how will you follow up a referred patient. [5+5]

Telemedicine

June 2020

Telemedicine and its use in family practice.





Three stage assessment & Principles of FM

December 2022

Discuss the principles of Family medicine. Write briefly on three stage assessment. [6+4]

June 2022

50 year old man presented to you with a non-healing ulcer on his right foot.

How will you assess him according to three stage assessment model? [10]

December 2021

Describe the concept of "three stage assessment" of a person in family medicine clinical practice with an example. [10]





`}];export{e as SOURCE_DOCUMENTS};